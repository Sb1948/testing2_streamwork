export default function toggleDropdown(event: any) {
	console.info(event.target.nextSibling.classList.add('show'))
	addEventListener('mouseup', (e) => {
		console.info(e)
		event.target.nextSibling.classList.remove('show')

	}, { once: true });

}

export function formatDate(date: Date) {

	const d = new Date(date)
	const now = new Date()
	if (now.getFullYear() === d.getFullYear()) {
		if (now.getMonth() === d.getMonth()) {
			if (now.getDate() === d.getDate()) {
				return 'Today, ' + d.getHours() + ":" + d.getMinutes()
			} else if (now.getDate() === d.getDate() + 1) {
				return 'Yesterday, ' + d.getHours() + ":" + d.getMinutes()
			}


		}
	}
	let month = d.getMonth().toString()
	let day = d.getDate().toString()
	if (month.length == 1) {
		month = '0' + month
	}
	if (day.length == 1) {
		day = '0' + day
	}


	return day + '/' + month + '/' + d.getFullYear().toString().substring(2, 4)

}

export function formatNumber(number: number) {
	let temp = number.toString()
	let out = ''
	temp.length / 3
	let cycles = Math.ceil(temp.length / 3)
	for (let i = 0; i < cycles; i++) {

		out = `${temp.substring(temp.length - (3 * i), temp.length - (3 * (i - 1)))}` + out
		if (i > 0) {
			out = ',' + out
		}
	}

	out = `${temp.substring(0, temp.length - (3 * (cycles - 1)))}${out}`
	return out
}