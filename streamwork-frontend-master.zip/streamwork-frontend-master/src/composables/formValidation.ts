export type ValidationRule = {
    required: boolean
}



export function validateField(field: string, rules: ValidationRule) {
    if (rules.required) {
        if (field.length>0) {
            return { isValid: true,message:'' }

        } else {
            return { isValid: false, message: 'This field is required' }
        }

    }
    return { isValid: true,message:'' }
}


export class formFieldRule {
    required = false
    constructor(required: boolean) {
        this.required = required
    }

}