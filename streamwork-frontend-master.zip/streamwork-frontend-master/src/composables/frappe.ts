export default class Frappe {
	baseURL: string = import.meta.env.VITE_API_HOST_URL


	async getFormDoc(doctype: string, docname: string | null, filters?: object) {

		const method = 'frappe.desk.form.load.getdoc?doctype=' + doctype.replace(' ', '+') + '&name=' + docname?.replace(' ', '+')
		const response = await this.frappeCall('GET', method)
		return response

		//return this.frappeRest('get', doctype, docname, filters)
	}
	getDoc(doctype: string, docname: string | null, filters?: object) {

		if (docname) {
			return this.frappeRest('get', doctype, docname, filters)

		} else {
			return this.frappeRest('get', doctype)
		}
	}
	createDoc(doctype: string, docname: string, filters?: object) {
		return this.frappeRest('post', doctype, docname, filters)
	}
	getList(doctype: string, fields?: string[], filters?: object, order_by?: string, limit?: number) {
		return this.frappeRest('get', doctype, '', filters, fields, undefined, limit)
	}

	createProject(project_name: string, customer_id: string | undefined, template_id?: string, from_scratch?: boolean) {
		const body = {
			project_name: project_name,
			customer_id: customer_id,
			template_id: template_id
		}
		if (from_scratch) {
			return this.frappeCall('POST', 'streamwork.project_tools.create_project_from_scratch', { project_name: project_name, customer_id: customer_id })
		} else {
			return this.frappeCall('POST', 'streamwork.project_tools.create_project_from_template', body)
		}
	}

	getLoggedUser() {

		return this.frappeCall('GET', 'frappe.auth.get_logged_user')

	}
	login(email: string, password: string) {
		let loginInfo = { usr: email, pwd: password, device: 'desktop' }
		if (import.meta.env.DEV) {
			//workaround for SameSite=Lax header in dev mode
			loginInfo.device = "mobile"
		}
		return this.frappeCall('POST', 'login', loginInfo)
	}
	logout() {
		return this.frappeCall('GET', 'logout')
	}
	uploadFile() {


	}

	async frappeCall(type: 'GET' | 'POST' = 'GET', method: string = '', body?: object) {


		//console.info(headers)
		const res = await fetch(this.baseURL + '/method/' + method, {
			credentials: 'include',
			headers: { "Content-Type": "application/json" },
			//headers: headers,
			method: type,
			body: JSON.stringify(body)
		})
		if (!res.ok) {
			return 'error'
		}
		const data = await res.json();
		return data;
		/* const res = await fetch(this.baseURL + '/method/' + method, {
			credentials: 'include',
			headers: { "Content-Type": "application/json" },
			//headers: headers,
			method: type,
			body: JSON.stringify(body)
		}).then(response => {
			if (!response.ok) {
				const error = response.statusText;
				return Promise.reject(error);
			}
			return response.json()
		}).catch(err => {
			console.log('Request Failed', err)
			return 'error'
		}); // Catch errors
		if (res != 'error') {
			return res.message
		} else {
			return 'error'
		} */

	}
	async frappeRest(
		type: 'get' | 'post' | 'put' | 'delete',
		doctype: string,
		docname?: string | null,
		filters?: {} | null,
		fields?: string[] | null,
		body?: object,
		limit?: number) {
		//const config = useRuntimeConfig()

		let url = doctype
		if (docname) {
			url += "/" + docname
		} else {
			url += "?"
			if (filters) {
				url += "filters=" + JSON.stringify(filters)
				if (fields) {
					url += "&fields=" + JSON.stringify(fields)
				}
				if (limit) {
					url += "&limit_page_length=" + limit.toString()
				}
			} else if (fields) {
				url += "fields=" + JSON.stringify(fields)
				if (limit) {
					url += "&limit_page_length=" + limit.toString()
				}
			} else if (limit) {

				url += "limit_page_length=" + limit.toString()

			}
		}

		const res = await fetch(this.baseURL + '/resource/' + url, {
			credentials: 'include',
			headers: { "Content-Type": "application/json" },
			//baseURL: config.apiHost,
			//headers: useRequestHeaders(['cookie']),
			method: type,
			body: JSON.stringify(body)

		}).then(response => {
			//console.info('response', response)
			if (!response.ok) {
				const error = response.statusText;
				return Promise.reject(error);
			}
			return response.json()
		}).catch(err => {
			console.log('Request Failed', err)
			return 'error'
		}); // Catch errors
		if (res != 'error') {
			return res.data
		} else {
			return res
		}

	}
}

export const serverApi = new Frappe