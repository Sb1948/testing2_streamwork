

export function embedBlueSnapSdk(sandbox = true) {
    let baseURL = 'https://sandbox.bluesnap.com'
    if (!sandbox) {
        baseURL = 'https://ws.bluesnap.com'
    }
    let bluesnap = document.createElement('script')
      bluesnap.setAttribute('src', baseURL + '/web-sdk/4/bluesnap.js')
      document.body.appendChild(bluesnap)
}