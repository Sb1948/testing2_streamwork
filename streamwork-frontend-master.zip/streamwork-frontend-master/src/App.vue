<script async setup lang="ts">
import { onBeforeRouteLeave, onBeforeRouteUpdate, RouterLink, RouterView, useRoute, useRouter } from 'vue-router'

import NavBar from './components/NavBar.vue'
import Login from '@/components/Login.vue'
import { useStore } from './stores/stores'

import { onBeforeUnmount, onMounted, watch } from 'vue';
import { serverApi } from './composables/frappe';
import { useTheme } from './stores/theme';
import Loader from './components/Loader.vue';
import Footer from './components/Footer.vue';


const app = useStore()
const router = useRouter()
const route = useRoute()

onMounted(async () => {
	const response = await serverApi.frappeCall('GET', 'frappe.auth.get_logged_user')

	if (response == 'error') {
		if (router.currentRoute.value.name == 'View') {

			app.loadGuestProject(route.params.id.toString())
		} else {
			router.push('/')
		}
		app.email = ''
		app.isLoggedIn = false
		app.isLoading = false

	} else {

		app.isLoggedIn = true
		app.email = response.message
		await app.loadSessionData()

		// app.setProjectTheme()
		console.info(router.currentRoute)
		if (router.currentRoute.value.name == 'Edit') {
			app.isProjectLoading = true
			app.loadActiveProject(route.params.id.toString())
		} else if (router.currentRoute.value.name == 'View') {
			app.isProjectLoading = true
			app.loadGuestProject(route.params.id.toString())

		}
		app.isLoading = false



	}










})


// set up watcher to load active project on nav to edit url

watch(
	() => route.params.id,
	async newId => {

		if (typeof (newId) == 'string') {
			if (router.currentRoute.value.name == 'Edit') {
				app.isProjectLoading = true
				app.loadActiveProject(newId)
			} else if (router.currentRoute.value.name == 'View') {
				app.isProjectLoading = true
				app.loadGuestProject(newId)
			}
		}

	}

)
watch(
	() => route.name,
	async routeName => {
		if (routeName == 'View') {
			app.isViewing = true
		}
	}



)


</script>

<template>


	<NavBar />


	<div v-if="!app.isLoading">
		<div class="container-fluid main-container pt-2">

			<router-view v-slot="{ Component }">
				<Transition name="fade"
										appear
										mode="out-in">
					<div v-if="app.isLoggedIn">




						<Transition name="slide-fade"
												mode="out-in">
							<component :is="Component" />

						</Transition>

					</div>
					<div v-else-if="router.currentRoute.value.name == 'View'">
						<component :is="Component" />

					</div>
					<div v-else>
						<Login />

					</div>


				</Transition>
			</router-view>



		</div>


	</div>
	<div v-else
			 class="vh-100">

		<Loader></Loader>

	</div>
</template>

<style lang="scss">
@import '@/assets/fonts.scss';
@import '@/assets/style.scss';
</style>

<style scoped>
.main-container {
	height: calc(100vh - var(--header-height) - (var(--main-container-padding)*2))
}
</style>