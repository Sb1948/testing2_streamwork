import Trash from './Trash.svg?component'

export const Trash = Trash