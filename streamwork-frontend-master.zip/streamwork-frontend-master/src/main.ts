import { createApp } from 'vue'

import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'
import { VueDraggableNext } from 'vue-draggable-next'

import FloatingInput from './components/FloatingInput.vue'



/* import the fontawesome core */
import { library } from '@fortawesome/fontawesome-svg-core'

/* import font awesome icon component */
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

/* import specific icons */
import {
	faCircleUser,
	faArrowRightFromBracket,
	faPlus,
	faCircleXmark,
	faRightLong,
	faAngleRight,
	faHandPointer,
	faPalette,
	faPlaneDeparture,
	faCaretRight,
	faCaretLeft,
	faDollarSign,
	faArrowsRotate,
	faTrash,
	faLink,
	faFile,
	faPaperclip,
	faXmark,
	faCheck,
	faPencil,
	faPallet,
	faFloppyDisk,
	faWifi,
	faArrowDown,
	faArrowUp,
	faArrowRight,
	faArrowAltCircleRight,
	faArrowCircleRight,
	faArrowCircleLeft,
	faChevronRight,
	faChevronDown,
	faAngleDown,
	faUpload,
	faObjectGroup,
	faObjectUngroup,
faToolbox,
faAngleUp


} from '@fortawesome/free-solid-svg-icons'
import { faCcMastercard, faCcVisa, faCcAmex, faCcDinersClub } from '@fortawesome/free-brands-svg-icons'

import {faPenToSquare} from '@fortawesome/free-regular-svg-icons'
/* add icons to the library */

library.add(
	faCircleUser,
	faArrowRightFromBracket,
	faPlus,
	faCircleXmark,
	faRightLong,
	faAngleRight,
	faHandPointer,
	faPalette,
	faPlaneDeparture,
	faCaretRight,
	faCaretLeft,
	faDollarSign,
	faArrowsRotate,
	faTrash,
	faLink,
	faFile,
	faPaperclip,
	faXmark,
	faCheck,
	faPencil,
	faPalette,
	faFloppyDisk,
	faCcAmex,
	faCcVisa,
	faCcDinersClub,
	faCcMastercard,
	faWifi,
	faArrowDown,
	faArrowUp,
	faPalette,
	faArrowRightFromBracket,
	faArrowRight,
	faArrowAltCircleRight,
	faArrowCircleRight,
	faArrowCircleLeft,
	faAngleRight,
	faChevronRight,
	faChevronDown,
	faAngleDown,
	faAngleUp,
	faUpload,
	faObjectGroup,
	faObjectUngroup,
	faToolbox,
	faPenToSquare,

)





const app = createApp(App)


/* add font awesome icon component */
app.component('font-awesome-icon', FontAwesomeIcon)
app.component('floating-input', FloatingInput)
app.component('draggable', VueDraggableNext)

/* add frappe class instance */



app.use(createPinia())
app.use(router)


app.mount('#app')
