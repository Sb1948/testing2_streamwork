import { serverApi } from "@/composables/frappe"
import { defineStore } from "pinia"
import type { Category, FileUploadState } from "../types/localTypes"
import type { ColorPalette, CustomerAccount, DocType, Font, FormResponse, TemplateIcon, ProjectLink, ProjectStep, StreamWorkCategory, StreamWorkProject, StreamWorkTemplate, User, StreamBoardSettings } from "@/types/docTypes"
import type { FilePondFile } from "filepond"
import { useTheme } from "./theme"
import router from "@/router"
import { formFieldRule, validateField } from "@/composables/formValidation"
import type { ValidationRule } from "@/composables/formValidation"
import { faSave } from "@fortawesome/free-solid-svg-icons"
import type { VaultedShopper } from "@/types/bluesnap"

export const useStore = defineStore('app_state', {
	state() {
		return {
			isMobile: false,
			isLoggedIn: false,
			isLoading: true,
			isViewing: false,
			isProjectLoading: false,
			isProjectCreating: false,
			hasVaultedShopper: false,
			showFooter: false,
			firstName: '',
			lastName: '',
			email: '',
			settings: {} as StreamBoardSettings,
			isAdmin: false,
			currencies: [] as { name: string, symbol: string }[],
			fonts: [] as Font[],
			userDoc: {} as User,
			vaultedShopper: {} as VaultedShopper,
			customerAccount: {} as CustomerAccount,
			userProjects: [] as StreamWorkProject[],
			templates: [],
			categories: [] as StreamWorkCategory[],
			colorPalettes: [] as ColorPalette[],
			activeProject: {
				fontChoicesActive: false,
				isSaving: false,
				doc: {} as StreamWorkProject,
				docInfo: {},
				activeStep: {} as ProjectStep,
				newLink: {
					name: '',
					parent: '',
					parenttype: 'StreamWork Project',
					parentfield: 'links',
					step: '',
					type: '' as 'URL' | 'FIle',
					url: '',
					idx: 0,
					"__islocal": 1,
					"__unsaved": 1,
					"__unedited": false
				} as ProjectLink,
				showNewLink: false,
				stepLinks: {} as { [key: string]: ProjectLink[] },
				isDirty: false,
				emptySteps: true,
				showProjectIcons: false,
				enableDrag: true,
				category: {} as StreamWorkCategory,
				activeEditor: 'ProjectInfo' as 'Steps' | 'ProjectInfo' | 'Payments' | 'Theme' | 'Template',
				stepLimit: '' as 'top' | 'bottom' | 'mid' | 'both',
				activeIcon: {},
				activeButtons: true,
				showPreviewImageUploader: false,
				iconSelectorActive: false,
				editHistory: [],
				icons: [] as TemplateIcon[],
				iconGroups: {} as {
					[key: string]: {
						template_name: string,
						icons: TemplateIcon[]
					}
				}
			},
			newProject: {
				step: 1 as 1 | 2 | 3,
				progress: 0,
				projectName: '',
				fromScratch: false,
				category: {} as StreamWorkCategory,
				template: {} as StreamWorkTemplate
			},
			staticHostUrl: import.meta.env.VITE_STATIC_HOST_URL
		}
	},
	actions: {
		async loadActiveProject(projectId: string, useCurrentActiveStep: boolean = false) {
			this.isProjectLoading = true
			if (!useCurrentActiveStep) {
				this.activeProject.stepLimit = 'top'
			}
			const response: FormResponse = await serverApi.getFormDoc('StreamWork Project', projectId)
			const doc = response.docs[0]
			if (typeof (doc.description) == 'string') {
				doc.description = JSON.parse(doc.description)
			}
			this.activeProject.doc = doc
			this.activeProject.docInfo = response.docinfo


			if (this.getStandardStepLength > 0) {
				this.activeProject.emptySteps = false
			} else {
				this.activeProject.emptySteps = true
			}
			if (doc.steps.length > 0) {


				this.setLinks()
				if (!this.activeProject.emptySteps) {


					this.activeProject.doc.steps.sort((a, b) => a.idx - b.idx)
					if (!useCurrentActiveStep) {
						for (let i = 0; this.activeProject.doc.steps.length; i++) {
							if (this.activeProject.doc.steps[i].step_type == 'Standard') {
								this.activeProject.activeStep = this.activeProject.doc.steps[i]
								break;
							}
						}


					} else {
						if (this.activeProject.activeStep?.idx) {
							this.activeProject.activeStep = this.activeProject.doc.steps[this.activeProject.activeStep.idx - 1]
						} else {
							this.activeProject.activeStep = this.activeProject.doc.steps[0]
						}

					}

				}
				this.sortSteps()
				this.validateStepButtons(this.activeProject.activeStep)
			} else {
				this.activeProject.emptySteps = true
			}
			//const template = await serverApi.getDoc('StreamWork Template', this.activeProject.doc.template)


			const iconResponse = await serverApi.frappeCall('GET', 'streamwork.project_tools.load_icon_groups')
			console.info(iconResponse.message)
			console.info(this.activeProject.doc.template)
			this.activeProject.iconGroups = iconResponse.message
			let templateId = ''
			if (this.activeProject.doc.is_template) {
				templateId = this.activeProject.doc.name
			} else if ('template' in this.activeProject.doc) {
				templateId = this.activeProject.doc.template
			}
			if (templateId in this.activeProject.iconGroups) {
				this.activeProject.icons = this.activeProject.iconGroups[templateId].icons
			} else {
				// this.activeProject.icons = []
			}

			this.setProjectTheme()
			this.isProjectLoading = false
			const style = 'background-color: darkblue; color: white; font-style: italic; border: 5px solid hotpink; font-size: 1em;'

			console.info('%cActive Project', style)
			console.info('ActivePRoject', this.activeProject)
			console.info('%cActive Project', style)
			this.activeProject.isDirty = false
			if ('category' in this.activeProject.doc) {
				this.activeProject.category = this.categories.filter((category) => {
					if (this.activeProject.doc.category == category.name) {
						return category
					}
				})[0]
			}

			this.isProjectLoading = false
		}, loadGuestProject(projectId: string) {
			serverApi.frappeCall('POST', 'streamwork.streamwork.doctype.streamwork_project.streamwork_project.get_guest_project', { project: projectId }).then((response: { message: { project: StreamWorkProject, palette: ColorPalette } }) => {
				console.info(response)
				this.activeProject.doc = response.message.project
				if (response.message.project.steps.length > 0) {
					this.setLinks()
					this.activeProject.doc.steps.sort((a, b) => a.idx - b.idx)
					this.set_steps_active_project()
					this.sortSteps()

				}
				const theme = useTheme()
				theme.setPalette(response.message.palette)

			})

			this.setProjectTheme()
			this.isProjectLoading = false

		},
		setProjectTheme() {
			const theme = useTheme()
			const paletteName = this.activeProject.doc?.color_palette
			theme.activeFont = this.activeProject.doc.font
			this.colorPalettes.forEach((palette: ColorPalette) => {

				if (palette.name == paletteName) {
					theme.setPalette(palette)
					return
				}
			})




		},
		setActiveStep(step: ProjectStep) {

			console.info({ step })
			this.activeProject.activeStep = step
			this.activeProject.activeEditor = 'Steps'
			if (step.step_type == 'Standard') {

				this.setLinks()
			}
			let stepEl = document.querySelector('#step-' + step.name)
			stepEl?.scrollIntoView({
				block: 'center',
				behavior: 'smooth'
			})
			// document.querySelectorAll('.marker').forEach((el) => {
			// 	el.classList.remove('show')
			// })

			// let el = document.querySelector('#mark-' + step.name)

			// if (el) {
			// 	el.classList.add('show')

			// }

			this.validateStepButtons(step)
			//console.info(event.source)

		},
		validateStepButtons(step: ProjectStep) {
			this.activeProject.stepLimit = 'mid'

			if (step.step_number == 1) {
				this.activeProject.stepLimit = 'top'
			}

			if (step.step_number == this.activeProject.doc.steps.filter(step => step.step_type == 'Standard').length) {
				this.activeProject.stepLimit = 'bottom'
			}
			if (this.getStandardStepLength == 1) {
				this.activeProject.stepLimit = 'both'
			}
		},
		setLinks() {

			this.activeProject.stepLinks = {}
			this.activeProject.doc.links.forEach((link) => {

				this.activeProject.doc.steps.forEach((step, index) => {

					if (step.name == link.step) {
						if (this.activeProject.stepLinks[step.name]) {
							this.activeProject.stepLinks[step.name].push(link)
						} else {
							this.activeProject.stepLinks[step.name] = [link]
						}
						//this.activeProject.activeStepLinks.push(link)
						// if (this.activeProject.doc?.steps[index].links) {
						// 	this.activeProject.doc.steps[index].links?.push(link)
						// } else {
						// 	if (this.activeProject.doc?.steps[index]) {
						// 		this.activeProject.doc.steps[index].links = []
						// 		this.activeProject.doc?.steps[index].links?.push(link)
						// 	}

						// }

					}
				})
			})
			console.info('steplinks', this.activeProject.stepLinks)
		},
		async addLink(link: ProjectLink) {
			return serverApi.frappeRest(
				'post', 'Project Link', null, null, null, link
			).then((response) => {
				if (this.activeProject.doc) {
					this.loadActiveProject(this.activeProject.doc.name, true)
				}

				return true
			})
		},
		deleteLink(link: ProjectLink, index: number) {

			console.info({ link })
			this.activeProject.doc.links.forEach((docLink, index) => {
				if (docLink.name == link.name) {
					this.activeProject.doc.links.splice(index, 1)
				}
			})
			this.activeProject.doc.links.forEach((docLink, index) => {

				this.activeProject.doc.links[index].idx = index

			})
			this.activeProject.stepLinks[this.activeProject.activeStep.name].splice(index, 1)
			this.activeProject.isDirty = true
			// this.setLinks()
			// serverApi.frappeRest('delete', 'Project Link', link.name).then((response) => {

			// 	if (this.activeProject.doc) {
			// 		this.loadActiveProject(this.activeProject.doc.name, true)
			// 	}
			// })
		},
		set_steps_active_project() {
			let left = true
			this.activeProject.doc?.steps.forEach((item, index) => {

				if (this.activeProject.doc?.steps[index]) {
					this.activeProject.doc.steps[index].idx = index + 1
					this.activeProject.doc.steps[index].left = left
				}

				left = !left
			})
		},
		async deleteProject(projectName: string) {
			const response = await serverApi.frappeRest('delete', 'StreamWork Project', projectName)
			console.info(await response.json())
		},
		logout() {
			serverApi.logout().then((res) => {

				this.$reset()
				this.isLoading = false
			})

		},
		login() {
			const form = useLoginForm()


			if (form.validateLogin()) {
				form.loading = true

				serverApi.login(form.email.value, form.password.value).then((response) => {
					if (response != 'error') {
						this.email = form.email.value
						form.formView = 'loggingIn'
						this.loadSessionData().then((response) => {
							this.isLoggedIn = true
							form.$reset()
						})


					} else {
						form.formView = 'login'
						form.loading = false
						form.error.hasError = true
						form.error.message = "Oops! There's and issue with your email and password."
						return false
					}
				})
			} else {
				form.loading = false
			}
		},
		register() {
			const form = useLoginForm()
			if (form.validateRegistration()) {

				form.formView = 'registering'
				serverApi.frappeCall("POST", 'streamwork.customer.register', {
					first_name: form.first_name.value,
					last_name: form.last_name.value,
					email: form.email.value,
					password: form.password.value
				}).then((response) => {
					if (response == 'success') {

						this.login()


					}
				})
			} else {
				form.loading = false
			}
		},
		async updateProject(load = true) {
			const activeStepName = this.activeProject.activeStep.name
			this.activeProject.isSaving = true
			const things = async () => {




				let sendDoc = this.activeProject.doc
				console.info(sendDoc)
				sendDoc.description = JSON.stringify(sendDoc.description)
				//const response = await serverApi.frappeCall('POST', 'frappe.desk.form.save.savedocs', { doc: sendDoc, action: 'Save' })
				const response = await serverApi.frappeCall('POST', 'streamwork.streamwork.doctype.streamwork_project.streamwork_project.update_project', { doc: this.activeProject.doc })
				let doc: StreamWorkProject = response.docs[0]
				doc.description = JSON.parse(doc.description)
				doc.steps.sort((a, b) => a.idx - b.idx)
				let left = true
				let stepCounter = 1
				doc.steps.forEach((step, index) => {


					if (step.step_type == 'Standard') {

						doc.steps[index].step_number = stepCounter
						stepCounter++

						doc.steps[index].left = left
						left = !left
					}

				})
				this.activeProject.docInfo = response.docinfo
				this.activeProject.doc = doc
			}
			await things()
			this.setLinks()
			this.activeProject.doc.steps.forEach((step, index) => {
				if (step.name == activeStepName) {
					this.activeProject.activeStep = this.activeProject.doc?.steps[index]

				}
			})
			this.activeProject.isDirty = false
			this.activeProject.isSaving = false


		},
		async deleteActiveStep(step?: ProjectStep) {
			this.activeProject.enableDrag = false
			if (step) {
				this.activeProject.activeStep = step
			}
			const delIndex = this.activeProject.activeStep.idx - 1
			const oldStepNumber = this.activeProject.activeStep?.step_number


			this.activeProject.doc?.steps.splice(delIndex, 1)

			this.sortSteps(true)
			const length = this.getStandardStepLength

			if (length == 0) {
				this.activeProject.emptySteps = true
			}
			const steps = this.activeProject.doc?.steps.filter((step) => {
				let shifted = oldStepNumber
				if (oldStepNumber == 1) {
					shifted = 1
				}
				if (oldStepNumber > 1) {
					shifted = oldStepNumber - 1
				}
				if (step.step_number == shifted) {
					this.setActiveStep(step)
					return step
				}
			})

			await this.updateProject()
			this.validateStepButtons(this.activeProject.activeStep)
			/* serverApi.frappeRest('delete', 'Project Step', this.activeProject.activeStep?.name).then((res) => {
				if (this.activeProject.doc) {
					//this.loadActiveProject(this.activeProject.doc.name)
				}

			}
			)*/


			//this.activeProject.enableDrag = true
		},
		sortSteps(isLocal = false) {
			let left = true
			let stepCounter = 1
			let newStepIndex = 0
			this.activeProject.doc?.steps.forEach((item, index) => {

				if (this.activeProject.doc) {


					this.activeProject.doc.steps[index].idx = index + 1

					if (this.activeProject.doc.steps[index].step_type == 'Standard') {

						this.activeProject.doc.steps[index].step_number = stepCounter
						stepCounter++

						this.activeProject.doc.steps[index].left = left
						left = !left
					}
				}
			})
			return newStepIndex

		},
		swapIcon(toIcon: {
			name: string,
			icon: string
		}, isCover: boolean = false, isFooter: boolean = false) {
			if (!isCover && !isFooter) {
				this.activeProject.activeStep.icon = toIcon.name
				this.activeProject.activeStep.icon_url = toIcon.icon
				this.activeProject.iconSelectorActive = false
			} else {


				if (isCover) {
					this.activeProject.doc.cover_image_url = toIcon.icon
					this.activeProject.doc.cover_image_link = toIcon.name
				}
				if (isFooter) {
					this.activeProject.doc.footer_image_url = toIcon.icon
					this.activeProject.doc.footer_image_link = toIcon.name
				}
				this.activeProject.showProjectIcons = false
			}
			this.updateProject()
		},
		setIconTriggerSourceIcon() {

		},
		async createProjectStepFile(args: { project: string, stepName: string, title: string, fileUrl: string }) {
			const res = await serverApi.frappeRest('post', 'Project Link', null, null, null, {
				parent: args.project,
				parenttype: 'StreamWork Project',
				parentfield: 'links',
				step: args.stepName,
				type: 'File',
				title: args.title,
				file: args.fileUrl,
			})
			if (this.activeProject.doc) {
				this.loadActiveProject(this.activeProject.doc.name, true)
			}

			this.activeProject.activeButtons = true
		}
		, setUserImageUrl() {
			if (this.userDoc.user_image) {


				let image = this.userDoc.user_image
				if (this.userDoc.user_image.indexOf('/files/')) {
					this.userDoc.user_image = this.staticHostUrl + this.userDoc.user_image
				}
			}
		},
		async loadSessionData() {

			this.userDoc = await serverApi.getDoc('User', this.email)
			this.settings = await serverApi.getDoc('StreamBoard Settings', 'StreamBoard Settings')
			this.userDoc.roles.forEach((role) => {
				if (role.role === 'StreamWork Admin') {
					this.isAdmin = true
				}
			})
			const accountResponse = await serverApi.frappeCall('GET', 'streamwork.customer.get_customer_account')
			this.customerAccount = accountResponse.message
			const categories: StreamWorkCategory[] = await serverApi.getList('StreamWork Category', ['name', 'category_name', 'category_icon', 'fontawesome_icon', 'template_count'])
			this.categories.splice(0, this.categories.length - 1)
			categories.forEach((category) => {
				category.templates = []
				this.categories.push(category)
			})
			this.userProjects = await serverApi.getList('StreamWork Project', ['*'], { 'customer_account': this.customerAccount?.name })
			let templateResponse = await serverApi.frappeCall("GET", 'streamwork.project_tools.get_templates')
			this.templates = templateResponse.message
			console.info(this.templates)
			this.colorPalettes = await serverApi.getList('Color Palette', ['*'])
			this.fonts = await serverApi.getList('Font')
			this.currencies = await serverApi.getList('Currency', ['name', 'symbol'], { enabled: 1 })


			this.templates.forEach((template: StreamWorkTemplate) => {
				this.categories.forEach((category, index) => {
					if (template.category == category.name) {

						this.categories[index].templates.push(template)


					}
				})
			})

			this.isLoading = false
			// console.info(this.$state)
			console.info(this)

		},
		getCurrency(currencyName: string) {
			let result = this.currencies.filter((currency) => {
				if (currency.name == currencyName) {
					return currency
				}
			})
			let out
			if (result.length == 0) {
				out = false
				return out
			}
			if (result[0].symbol) {

				out = result[0].symbol
			} else {

				out = result[0].name
			}
			return out
		},
		async addTemplateIcon(fileId: string, projectId: string) {
			serverApi.frappeCall("POST", "streamwork.project_tools.add_icon_to_template", { file_id: fileId, template_id: projectId }).then((response) => {
				console.info(response.message)
				this.activeProject.icons.push(JSON.parse(response.message))
			})
		},
		async deleteTemplateIcon(icon: Icon) {
			serverApi.frappeCall("POST", "streamwork.project_tools.delete_icon_from_template", { icon: icon }).then((response) => {
				console.info({ response })
				this.activeProject.icons.forEach((listIcon, index) => {
					if (icon.name == listIcon.name) {
						this.activeProject.icons.splice(index, 1)
					}
				})
			})
		}

	},

	getters: {
		getActiveStepImage(): string {
			return this.staticHostUrl + this.activeProject.activeStep.icon_url
		},
		getStandardStepLength(): number {

			let array: ProjectStep[] = this.activeProject.doc.steps.filter((step) => {
				if (step.step_type == 'Standard') {
					return step
				}
			})
			return array.length
		},
		getProjectLink(): string {
			return window.location.origin + "/view/" + this.activeProject.doc.name
		}
	}

})

export const useLoginForm = defineStore('loginForm', {
	state: () => {
		return {
			wasValidated: false,
			first_name: {
				value: '',
				rules: new formFieldRule(true),
				errorMessage: '',
				valid: false,
				validClass: ''
			},
			last_name: {
				value: '',
				rules: new formFieldRule(true),
				errorMessage: '',
				valid: false,
				validClass: ''
			},

			email: {
				value: '',
				rules: new formFieldRule(true),
				errorMessage: '',
				valid: false,
				validClass: ''
			},
			password: {
				value: '',
				rules: new formFieldRule(true),
				errorMessage: '',
				valid: false,
				validClass: ''
			},
			confirmPassword: {
				value: '',
				rules: new formFieldRule(true),
				errorMessage: '',
				valid: true,
				validClass: ''
			},
			signup: false,
			formView: 'login',
			loading: false,
			error: {
				hasError: false,
				message: ''
			},
			googleLogin: {
				auth_url: ''
			}
		}


	},
	actions: {

		change_state(formState: string) {
			this.error.hasError = false;
			this.error.message = ''
			this.formView = formState
			this.wasValidated = false
			this.email.validClass = ''
			this.password.validClass = ''
			this.first_name.validClass = ''
			this.last_name.validClass = ''
			this.confirmPassword.validClass = ''
		},
		validateLogin() {

			this.checkField(this.email)
			this.checkField(this.password)
			//  console.info(this.email.valid, this.password.valid)
			if (this.email.valid && this.password.valid) {
				return true
			}
			this.wasValidated = true
			return false
		}, validateRegistration() {

			this.checkField(this.email)
			this.checkField(this.password)
			this.checkField(this.first_name)
			this.checkField(this.last_name)
			//this.checkField(this.confirmPassword)

			//console.info(this.password.valid, this.confirmPassword.valid)
			if (this.password.valid) {
				if (this.password.value != this.confirmPassword.value) {
					this.confirmPassword.valid = false
					this.confirmPassword.validClass = 'is-invalid'
					if (!this.confirmPassword.value) {
						this.confirmPassword.errorMessage = 'This field is required'
					} else {
						this.confirmPassword.errorMessage = 'Passwords do not match'
					}

				} else {
					this.confirmPassword.valid = true
					this.confirmPassword.validClass = 'is-valid'
				}
			}
			if (this.email.valid && this.password.valid && this.first_name.valid && this.last_name.valid && this.confirmPassword.valid) {

				return true
			}
			this.wasValidated = true
			return false
		},
		checkField(field: { value: string, rules: ValidationRule, valid: boolean, errorMessage: string, validClass: string }) {
			let validation = validateField(field.value, field.rules)
			field.valid = validation.isValid
			if (!validation.isValid) {
				field.errorMessage = validation.message
				field.validClass = 'is-invalid'


			} else {
				field.validClass = 'is-valid'
			}
		},
		async getGoogleLogin() {
			const response = await serverApi.frappeCall('POST', 'streamwork.utils.get_google_login', {
				redirect_to: window.location.origin
			})
			console.info(response)
			this.googleLogin = await response.message

		}
	}
})

export const useModal = defineStore('modal', {
	state: () => {
		return {
			modalShown: false,
		}


	},
	actions: {
		open: (e: { modalShown: boolean }) => {
			e.modalShown = true
		},
		close(callback = () => { }) {
			this.modalShown = false

		}
	}

})
export const useFileUploader = defineStore('uploader', {
	state: () => {
		return {
			pond: {
				processFile: Function as Function
			},
			fileType: '',
			fileName: '',
			fileExtension: '',
			fileTitle: '',
			fileUrl: '',
			ready: false,
			active: false
		}


	},
	actions: {
		setFileDetails(file: FilePondFile) {

			this.fileType = file.fileType
			this.fileName = file.filename
			this.fileTitle = file.filename
			this.fileExtension = file.fileExtension

		},
		uploadFile() {
			if (!this.ready || this.fileTitle == '' || this.fileTitle == null) {
				return
			} else {

				this.pond.processFile()
			}
		}
	}

})

export const usePayment = defineStore('payment', {
	state: () => {
		return {
			isProcessing: false,
			validated: false,
			plans: {
				proPlanAnnual: {
					planId: null,
					planCost: null
				},
				proPlanMonthly: {
					planId: null,
					planCost: null,
				},
			},
			billingInfo: {
				firstName: '',
				lastName: '',
				company: '',
				address: '',
				city: '',
				country: {
					name: '',
					code: ''
				},
				state: {
					name: '',
					abbreviation: ''
				},
				zip: '',
			},
			formFields: {
				wasValidated: false,
				firstName: {
					value: '',
					rules: new formFieldRule(true),
					errorMessage: '',
					valid: false,
					validClass: ''
				}, lastName: {
					value: '',
					rules: new formFieldRule(true),
					errorMessage: '',
					valid: false,
					validClass: ''
				}, city: {
					value: '',
					rules: new formFieldRule(true),
					errorMessage: '',
					valid: false,
					validClass: ''
				},
				country: {
					value: '',
					rules: new formFieldRule(true),
					errorMessage: '',
					valid: false,
					validClass: ''
				},
			},
			token: '',
			cardData: {},
			statusCode: null,
			transactionFraudInfo: {},
			errorCodes: {
				ccn: {
					show: false,
					errorMessage: '',
					invalidInput: 'Please enter a valid credit card number',
					invalidCcNumber: 'The credit card number is invalid'
				},
				exp: {
					show: false,
					errorMessage: '',
					invalidInput: 'Please enter an expiration date',
					invalidExpDate: 'The date you entered is invalid'
				},
				cvv: {
					show: false,
					errorMessage: '',
					invalidInput: 'Please enter your cvv code',
					invalidCvv: 'The cvv code is invalid'
				}
			}
		}
	},
	actions: {
		getPlans() {
			serverApi.frappeRest('get', 'Subscription Settings', 'Subscription Settings').then((response) => {
				// console.info(response)
				this.plans.proPlanMonthly.planCost = response.pro_monthly_cost
				this.plans.proPlanMonthly.planId = response.pro_subscription_plan
				this.plans.proPlanAnnual.planCost = response.pro_annual_cost
				this.plans.proPlanAnnual.planId = response.pro_annual_plan
			})
		},
		getVaultedShopper(customer_id: string) {
			const app = useStore()
			serverApi.frappeCall('POST', 'streamwork.customer.get_vaulted_shopper', { customer_id: customer_id }).then((response) => {
				if (response) {
					app.vaultedShopper = response
					app.hasVaultedShopper = true
				}

				// console.info(response)

			})
		},
		validateBillingInfo() {

			this.checkField(this.billingInfo.firstName, this.formFields.firstName)
			this.checkField(this.billingInfo.lastName, this.formFields.lastName)
			this.checkField(this.billingInfo.city, this.formFields.city)
			this.checkField(this.billingInfo.country.name, this.formFields.country)
			if (this.formFields.firstName.valid && this.formFields.lastName.valid && this.formFields.city.valid && this.formFields.country.valid) {
				this.validated = true
			}
			this.formFields.wasValidated = true
		},
		submitPayment() {
			this.validateBillingInfo()

			if (this.validated) {


				this.isProcessing = true
				const app = useStore()
				let data = {
					plan: this.plans.proPlanMonthly.planId,
					customer_id: app.customerAccount?.name,
					has_vaulted_shopper: false,
					has_billing_address: false
				} as any
				if (app.customerAccount.billing_address) {
					data['has_billing_address'] = true
				}
				if (app.hasVaultedShopper) {
					data['has_vaulted_shopper'] = true
				} else {
					data = {
						...data,
						pf_token: this.token,
						card_data: this.cardData,
						billing_info: this.billingInfo,
						transaction_fraud_info: this.transactionFraudInfo
					}
				}

				console.info({ data })
				serverApi.frappeCall('POST', 'streamwork.customer.submit_subscription_payment', { data: data }).then((response) => {
					app.loadSessionData().then((data) => {
						this.isProcessing = false
					})
					console.info(response)
				})
			}
		},
		checkField(value: string, field: any) {
			let validation = validateField(value, field.rules)
			field.valid = validation.isValid
			if (!validation.isValid) {
				field.errorMessage = validation.message
				field.validClass = 'is-invalid'


			} else {
				field.validClass = 'is-valid'
			}
		}
	}
})
