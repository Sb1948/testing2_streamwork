import type { ColorPalette, Font } from "@/types/docTypes"
import { defineStore } from "pinia"
import type { StyleValue } from "vue"
import { useStore } from "./stores"
export type Style = StyleValue | undefined

export const useTheme = defineStore('streamboardTheme', {
	state: () => ({
		fonts: ['Georama', 'Open Sans', 'Rubik'],
		activeFont: '' as string,
		dark: false,
		colorPalette: {} as ColorPalette,
		path: {
			width: '12px',
			height: 'calc(100% + 4px)',
			position: 'absolute',
			left: 'calc(50% - 12px / 2)',
			top: '-2px',
			marginLeft: 'auto',
			marginRight: 'auto',
			backgroundColor: '#121212',
		} as StyleValue,
		stepNumber: {
			backgroundColor: '',
			color: ''
		} as StyleValue,
		stepTitle: {
			fontSize: '1.5rem',
			fontWeight: '700',
			color: '',
		},
		mainTitle: {
			fontStyle: 'italic',
			fontSize: '2rem',
			fontWeight: '700',
			color: '',
		},
		stepRow: {
			minHeight: '150px',
			padding: '20px 45px',
			backgroundColor: '',
			borderRadius: '3rem',
			position: 'relative',
			color: ''
		} as StyleValue,
		descriptionText: {
			color: '',
			fontFamily: '"Roboto", sans-serif,',
			letterSpacing: '.085em',
			fontSize: '0.8rem'

		} as StyleValue | unknown,
		horizontalLine: {
			backgroundColor: ''
		} as StyleValue | unknown,
		contactCard: {
			backgroundColor: '',
			color: ''
		} as StyleValue | unknown,
		links: {
			backgroundColor: '',
		} as StyleValue | unknown,
		payment: {
			backgroundColor: '',
			color: '',
			fontSize: '22px',
		} as Style

	} as any),
	actions: {
		setPalette(palette: ColorPalette, change: boolean = false) {

			this.colorPalette = palette
			this.path.backgroundColor = this.colorPalette.path
			this.stepTitle.color = this.colorPalette.primary
			this.stepRow.backgroundColor = this.colorPalette.step_background
			this.descriptionText.color = this.colorPalette.text
			this.mainTitle.color = this.colorPalette.primary
			this.stepNumber.backgroundColor = this.colorPalette.secondary
			this.stepNumber.color = this.colorPalette.background
			this.horizontalLine.backgroundColor = this.colorPalette.secondary + '80'
			this.contactCard.backgroundColor = this.colorPalette.contact
			this.contactCard.color = '#fff'
			this.links.backgroundColor = this.colorPalette.info
			this.payment.backgroundColor = this.colorPalette.secondary
			this.payment.color = this.colorPalette.background
			if (change) {
				const app = useStore()
				app.activeProject.doc.color_palette = palette.name
				app.updateProject()
			}
		},
		changeFont(font: Font) {
			const app = useStore()
			this.activeFont = font.name
			app.activeProject.doc.font = font.name
		}
	},
	getters: {
		getPrimaryColor: (state) => {
			return state.colorPalette.primary
		}
	}
})