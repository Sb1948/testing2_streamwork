<script lang="ts" setup>
import { useStore } from '@/stores/stores';
import { onMounted, onUnmounted, watch, ref } from 'vue';
import EditContainer from '../components/editor/EditContainer.vue';
import StreamBoard from '../components/streamboard/StreamBoard.vue';
import Loader from '../components/Loader.vue';
import CircleButton from '../components/icons/CircleButton.vue';
import { storeToRefs } from 'pinia'
import type { ProjectStep } from '@/types/docTypes';
import toggleDropdown from '@/composables/utils';


const app = useStore()
const { activeProject } = storeToRefs(app)
const stepButtonsOpen = ref(false)
const shareModal = ref(false)
const projectLinkText = ref('Copy Link')


watch(() => app.activeProject.doc, (doc, other) => {
	console.info('changed')
	app.activeProject.isDirty = true
}, { deep: true })

let saveInterval: number
onMounted(() => {
	saveInterval = setInterval(() => {
		console.info('checking')
		if (app.activeProject.isDirty && !app.activeProject.isSaving) {
			console.info('saving')
			app.updateProject()
		}

	}, 5000);
})
onUnmounted(() => {
	app.updateProject()
	clearInterval(saveInterval);
})

function openStepButtons() {
	stepButtonsOpen.value = true
	addEventListener('mouseup', () => {
		stepButtonsOpen.value = false
	})
}

function setStep(direction: 'down' | 'up', step: ProjectStep) {
	//console.info('Active Step Change', app.activeProject.activeStep)
	let move = direction == 'up' ? -1 : 1
	console.info(step.idx, step.idx + move)
	let newStep = app.activeProject.doc.steps.filter((arrStep) => {

		if (arrStep.idx == step.idx + move) {
			return step
		}
	})
	console.info({ newStep })
	if (newStep.length == 1) {
		app.setActiveStep(newStep[0])
	}
	if (newStep.length == 0) {
		app.activeProject.stepLimit = direction == 'down' ? 'bottom' : direction == 'up' ? 'top' : 'mid'
	}
}
function addStep(payment = false) {

	//Can change 7 to 2 for longer results.
	let r = app.activeProject.doc.name + (Math.random() + 1).toString(36).substring(7);

	app.activeProject.enableDrag = false
	let newStep: ProjectStep
	if (payment) {
		newStep = {
			name: r,
			title: "Step Title",
			doctype: "Project Step",
			parent: app.activeProject.doc.name,
			parentfield: "steps",
			parenttype: "StreamWork Project",
			//left: !app.activeProject.activeStep?.left,
			idx: !app.activeProject.emptySteps ? app.activeProject.activeStep.idx : 0,
			step_type: "Payment",
			show_date: 0,
			isNew: true,
			"__islocal": 1,
			"__unsaved": 1,
			"__unedited": false

		} as ProjectStep
	} else {

		newStep = {
			name: r,
			title: "Step Title",
			doctype: "Project Step",
			parent: app.activeProject.doc.name,
			parentfield: "steps",
			parenttype: "StreamWork Project",
			description: 'Add a brief description to the step here.',
			//left: !app.activeProject.activeStep?.left,
			idx: !app.activeProject.emptySteps ? app.activeProject.activeStep.idx : 0,
			step_number: app.activeProject.emptySteps ? 1 : app.activeProject.activeStep.step_number + 1,
			step_type: 'Standard',
			show_date: 0,
			date_type: 'Milestone',
			isNew: true,
			"__islocal": 1,
			"__unsaved": 1,
			"__unedited": false

		} as ProjectStep
	}
	if (!app.activeProject.emptySteps) {
		const idx = app.activeProject.activeStep?.idx

		app.activeProject.doc.steps.splice(app.activeProject.activeStep.idx, 0, newStep)
	} else {
		app.activeProject.doc.steps.push(newStep)
		app.activeProject.emptySteps = false
		app.setActiveStep(app.activeProject.doc.steps[app.activeProject.doc.steps.length - 1])
	}


	app.sortSteps(true)

	app.updateProject(false).then(() => {
		const step = app.activeProject.doc.steps.filter((step) => {
			if (step.name == r) {
				return step
			}
		})[0]
		console.info({ step })
		app.setActiveStep(step)
		app.activeProject.enableDrag = true

	})


}

function copyProjectLink() {
	let text = app.getProjectLink
	navigator.clipboard.writeText(text);
	projectLinkText.value = 'Copied to clipboard!'
}
</script>
<template>
	<div>
		<Transition name="fade"
								mode="out-in">


			<div v-if="app.isProjectLoading"
					 class="vh-100">

				<Loader></Loader>

			</div>
			<div v-else
					 class="container-fluid project-container">
				<div class="row justify-content-center">
					<div class="col-xl-4 col-lg-4 col-md-6 edit-container">



						<div class="sw-header">
							<div class="d-flex flex-row header-row justify-content-center text-center">


								<div class="editor-tab"
										 :class="{ active: app.activeProject.activeEditor == 'ProjectInfo' }"
										 @click="app.activeProject.activeEditor = 'ProjectInfo'">
									<div class="tab-content">


										<svg width="16"
												 height="15"
												 viewBox="0 0 16 15"
												 fill="none"
												 xmlns="http://www.w3.org/2000/svg">
											<path fill-rule="evenodd"
														clip-rule="evenodd"
														d="M7.15236 0.505403C7.37131 -0.168465 8.32466 -0.168469 8.54361 0.505402L10.0591 5.16946H14.9631C15.6717 5.16946 15.9663 6.07615 15.3931 6.49263L11.4256 9.37517L12.941 14.0392C13.16 14.7131 12.3887 15.2735 11.8155 14.857L7.84798 11.9744L3.8805 14.857C3.30727 15.2735 2.53599 14.7131 2.75495 14.0392L4.27039 9.37517L0.302906 6.49263C-0.27032 6.07615 0.0242765 5.16946 0.732827 5.16946H5.63691L7.15236 0.505403ZM7.84798 0.994419L6.39158 5.47676C6.29367 5.77812 6.01283 5.98216 5.69596 5.98216H0.982949L4.79585 8.7524C5.05221 8.93865 5.15948 9.26879 5.06156 9.57015L3.60516 14.0525L7.41806 11.2823C7.67442 11.096 8.02155 11.096 8.27791 11.2823L12.0908 14.0525L10.6344 9.57015C10.5365 9.26879 10.6438 8.93865 10.9001 8.7524L14.713 5.98216H10C9.68314 5.98216 9.4023 5.77812 9.30438 5.47676L7.84798 0.994419Z"
														fill="#26274F" />
										</svg>
										<span>Header

										</span>

									</div>




								</div>



								<div class="editor-tab"
										 :class="{ active: app.activeProject.activeEditor == 'Steps' }"
										 @click="app.activeProject.activeEditor = 'Steps'">
									<div class="tab-content">
										<svg width="15"
												 height="15"
												 viewBox="0 0 23 23"
												 fill="none"
												 xmlns="http://www.w3.org/2000/svg">
											<path d="M11.0479 1.69446L1.04785 6.69446L11.0479 11.6945L21.0479 6.69446L11.0479 1.69446Z"
														stroke="#524E61"
														stroke-width="2"
														stroke-linecap="round"
														stroke-linejoin="round" />
											<path d="M1.04785 16.6945L11.0479 21.6945L21.0479 16.6945"
														stroke="#524E61"
														stroke-width="2"
														stroke-linecap="round"
														stroke-linejoin="round" />
											<path d="M1.04785 11.6945L11.0479 16.6945L21.0479 11.6945"
														stroke="#524E61"
														stroke-width="2"
														stroke-linecap="round"
														stroke-linejoin="round" />
										</svg>

										<span>Steps</span>

									</div>

								</div>



								<div class="editor-tab"
										 :class="{ active: app.activeProject.activeEditor == 'Theme' }"
										 @click="app.activeProject.activeEditor = 'Theme'">
									<div class="tab-content">
										<svg width="15"
												 height="16"
												 viewBox="0 0 15 16"
												 fill="none"
												 xmlns="http://www.w3.org/2000/svg">
											<path d="M7.11734 11.4606L14.6999 2.17212C15.1482 1.62296 15.0877 0.82009 14.5621 0.344286C14.0364 -0.131412 13.2316 -0.111905 12.7297 0.388813L4.24068 8.85692C3.97998 9.11698 3.84131 9.46302 3.85021 9.83111C3.85361 9.97116 3.87831 10.107 3.92241 10.2351C3.43866 10.1898 2.95119 10.3267 2.52606 10.6321C1.79232 11.1591 1.59205 11.7719 1.41532 12.3125C1.2175 12.918 1.0466 13.4408 0.167503 13.9129C0.0843854 13.9575 0.025334 14.0367 0.00646293 14.1291C-0.0124081 14.2216 0.0104918 14.3176 0.0693313 14.3914C0.481949 14.9088 1.12325 15.1763 1.94 15.1763C2.0809 15.1763 2.22731 15.1683 2.37838 15.1523C3.09368 15.0764 3.92676 14.8131 4.60686 14.4478C5.1784 14.1409 5.58762 13.6453 5.75905 13.0523C5.83984 12.773 5.86539 12.4843 5.83506 12.1944C5.82521 12.1004 5.80962 12.0077 5.78842 11.9168C5.88436 11.9386 5.98317 11.9499 6.08367 11.9499C6.11781 11.9499 6.15216 11.9486 6.18662 11.9459C6.55397 11.9182 6.88442 11.7459 7.11734 11.4606ZM13.1789 0.839173C13.3141 0.704214 13.4915 0.636257 13.6693 0.636257C13.8357 0.636257 14.0025 0.695839 14.1351 0.815956C14.4095 1.06425 14.4411 1.48323 14.2071 1.7699L7.27488 10.2616L5.41799 8.58096L13.1789 0.839173ZM5.14808 12.8756C5.02457 13.3028 4.72549 13.6621 4.30598 13.8874C3.83399 14.1409 3.06208 14.4401 2.31127 14.5197C1.68291 14.5864 1.18908 14.4954 0.837424 14.2493C1.63011 13.7032 1.83579 13.0736 2.01994 12.5102C2.18755 11.9974 2.33226 11.5544 2.89712 11.1488C3.25281 10.8934 3.6474 10.8063 4.03839 10.8968C4.4507 10.9923 4.80861 11.2734 5.02054 11.6679C5.21741 12.0347 5.26395 12.4749 5.14808 12.8756ZM6.62457 11.0583C6.50308 11.2071 6.33059 11.2971 6.13891 11.3115C5.94734 11.3262 5.76329 11.263 5.6207 11.134L4.71436 10.3136C4.57187 10.1846 4.49077 10.0077 4.4861 9.81563C4.48144 9.62353 4.55385 9.44287 4.68987 9.30717L4.967 9.03079L6.87202 10.755L6.62457 11.0583Z"
														fill="#26274F" />
										</svg>

										<span>Design</span>

									</div>

								</div>

								<div v-if="app.isAdmin"
										 class="editor-tab text-warning"
										 :class="{ active: app.activeProject.activeEditor == 'Template' }"
										 @click="app.activeProject.activeEditor = 'Template'">
									<div class="tab-content">
										<font-awesome-icon icon="fa-solid fa-toolbox"></font-awesome-icon>

										<span>Template</span>

									</div>

								</div>

							</div>

						</div>
						<div class="content-card position-relative d-flex flex-column">
							<Transition name="slide-fade-delay">


								<div v-show="app.activeProject.activeEditor == 'Steps'">

									<div class="row px-4 py-3 border-bottom justify-content-around">
										<div class="col-auto">
											<div class="step-title">
												Step {{ app.activeProject.activeStep.step_number }}

											</div>

										</div>
										<div class="col justify-content-center text-center">
											<div class="btn-square btn-square-light me-2"
													 :class="app.activeProject.stepLimit == 'top' || app.activeProject.stepLimit == 'both' ? 'disabled' : ''"
													 @mousedown="setStep('up', app.activeProject.activeStep)">
												<font-awesome-icon icon="fa-solid fa-angle-up"></font-awesome-icon>

											</div>
											<div class="btn-square btn-square-light"
													 :class="app.activeProject.stepLimit == 'bottom' || app.activeProject.stepLimit == 'both' ? 'disabled' : ''"
													 @mousedown="setStep('down', app.activeProject.activeStep)">
												<font-awesome-icon icon="fa-solid fa-angle-down"></font-awesome-icon>

											</div>

										</div>
										<div class="col-auto">
											<div class="btn-square btn-square-success me-2"
													 @click="addStep()">
												<svg width="18"
														 height="18"
														 viewBox="0 0 18 18"
														 fill="none"
														 xmlns="http://www.w3.org/2000/svg">
													<path fill-rule="evenodd"
																clip-rule="evenodd"
																d="M9 0C8.44771 0 8 0.447716 8 1V8H1C0.447715 8 0 8.44772 0 9C0 9.55229 0.447716 10 1 10H8V17C8 17.5523 8.44771 18 9 18C9.55229 18 10 17.5523 10 17V10H17C17.5523 10 18 9.55228 18 9C18 8.44771 17.5523 8 17 8H10V1C10 0.447715 9.55229 0 9 0Z"
																fill="white" />
												</svg>


											</div>
											<div class="btn-square btn-square-primary"
													 @click="addStep(true)">
												<svg width="10"
														 height="22"
														 viewBox="0 0 10 22"
														 fill="none"
														 xmlns="http://www.w3.org/2000/svg">
													<path d="M9.06276 8.5625C9.27825 8.5625 9.48491 8.4769 9.63729 8.32452C9.78966 8.17215 9.87526 7.96549 9.87526 7.75V7.07871C9.87294 5.9901 9.4481 4.9449 8.69026 4.16339C7.93242 3.38188 6.90078 2.92509 5.81276 2.8893V1.25C5.81276 1.03451 5.72716 0.827849 5.57478 0.675476C5.42241 0.523102 5.21575 0.4375 5.00026 0.4375C4.78477 0.4375 4.57811 0.523102 4.42574 0.675476C4.27336 0.827849 4.18776 1.03451 4.18776 1.25V2.8893C3.22401 2.92001 2.30024 3.28167 1.57183 3.91346C0.843412 4.54525 0.354791 5.40862 0.18815 6.35834C0.0215094 7.30807 0.187016 8.28621 0.656834 9.12824C1.12665 9.97027 1.87211 10.6248 2.76784 10.9818L6.62924 12.5271C7.18562 12.7497 7.6471 13.1591 7.93439 13.685C8.22168 14.2109 8.31684 14.8205 8.20351 15.4089C8.09019 15.9974 7.77546 16.528 7.3134 16.9096C6.85134 17.2912 6.27081 17.4999 5.67155 17.5H4.32897C3.64529 17.4992 2.98984 17.2273 2.5064 16.7439C2.02297 16.2604 1.75103 15.605 1.75026 14.9213V14.25C1.75026 14.0345 1.66466 13.8278 1.51228 13.6755C1.35991 13.5231 1.15325 13.4375 0.93776 13.4375C0.722272 13.4375 0.515609 13.5231 0.363236 13.6755C0.210863 13.8278 0.12526 14.0345 0.12526 14.25V14.9213C0.127577 16.0099 0.552422 17.0551 1.31026 17.8366C2.0681 18.6181 3.09974 19.0749 4.18776 19.1107V20.75C4.18776 20.9655 4.27336 21.1722 4.42574 21.3245C4.57811 21.4769 4.78477 21.5625 5.00026 21.5625C5.21575 21.5625 5.42241 21.4769 5.57478 21.3245C5.72716 21.1722 5.81276 20.9655 5.81276 20.75V19.1107C6.7765 19.08 7.70028 18.7183 8.42869 18.0865C9.15711 17.4548 9.64573 16.5914 9.81237 15.6417C9.97901 14.6919 9.8135 13.7138 9.34369 12.8718C8.87387 12.0297 8.12841 11.3752 7.23269 11.0182L3.37128 9.47291C2.8149 9.2503 2.35342 8.84087 2.06613 8.31496C1.77884 7.78905 1.68368 7.17951 1.79701 6.59106C1.91033 6.00261 2.22506 5.472 2.68712 5.09041C3.14918 4.70881 3.72971 4.50005 4.32897 4.5H5.67155C6.35523 4.50077 7.01068 4.77271 7.49412 5.25614C7.97755 5.73958 8.24949 6.39503 8.25026 7.07871V7.75C8.25026 7.96549 8.33586 8.17215 8.48824 8.32452C8.64061 8.4769 8.84727 8.5625 9.06276 8.5625Z"
																fill="white" />
												</svg>


											</div>

										</div>

									</div>

								</div>
							</Transition>
							<EditContainer class="editor-content"
														 :key="app.activeProject.doc.name"></EditContainer>
							<div class="bottom-buttons w-100 position-absolute px-4 pt-2 bg-white">
								<div class="row justify-content-between">

									<div class="col-auto">
										<Transition name="fade">
											<div v-show="app.activeProject.activeEditor == 'Steps'"
													 class="btn-square btn-square-danger"
													 @click="app.deleteActiveStep()">
												<svg width="20"
														 height="20"
														 viewBox="0 0 23 26"
														 fill="none"
														 xmlns="http://www.w3.org/2000/svg">
													<path d="M21.5176 3.78182H16.6027V2.6C16.6027 1.91044 16.3315 1.24912 15.8487 0.761522C15.3659 0.273928 14.711 0 14.0282 0H8.41122C7.72842 0 7.0736 0.273928 6.59079 0.761522C6.10799 1.24912 5.83675 1.91044 5.83675 2.6V3.78182H0.921854C0.735638 3.78182 0.557049 3.85653 0.425375 3.98951C0.2937 4.12249 0.219727 4.30285 0.219727 4.49091C0.219727 4.67897 0.2937 4.85933 0.425375 4.99231C0.557049 5.12529 0.735638 5.2 0.921854 5.2H1.41802L2.88781 23.608C2.94374 24.2577 3.23765 24.8629 3.71206 25.3053C4.18646 25.7477 4.80722 25.9954 5.45292 26H16.9865C17.6322 25.9954 18.253 25.7477 18.7274 25.3053C19.2018 24.8629 19.4957 24.2577 19.5516 23.608L21.0214 5.2H21.5176C21.7038 5.2 21.8824 5.12529 22.0141 4.99231C22.1458 4.85933 22.2197 4.67897 22.2197 4.49091C22.2197 4.30285 22.1458 4.12249 22.0141 3.98951C21.8824 3.85653 21.7038 3.78182 21.5176 3.78182ZM7.241 2.6C7.241 2.28656 7.36429 1.98596 7.58375 1.76433C7.80321 1.54269 8.10086 1.41818 8.41122 1.41818H14.0282C14.3386 1.41818 14.6362 1.54269 14.8557 1.76433C15.0752 1.98596 15.1985 2.28656 15.1985 2.6V3.78182H7.241V2.6ZM18.1474 23.4945C18.1217 23.7905 17.9874 24.0661 17.771 24.2673C17.5545 24.4684 17.2713 24.5806 16.9772 24.5818H5.45292C5.16036 24.5783 4.87956 24.465 4.66504 24.2641C4.45052 24.0632 4.31759 23.7889 4.29207 23.4945L2.79419 5.2H19.6453L18.1474 23.4945ZM15.6665 10.1636V19.6182C15.6665 19.8062 15.5926 19.9866 15.4609 20.1196C15.3292 20.2526 15.1506 20.3273 14.9644 20.3273C14.7782 20.3273 14.5996 20.2526 14.4679 20.1196C14.3363 19.9866 14.2623 19.8062 14.2623 19.6182V10.1636C14.2623 9.97557 14.3363 9.79521 14.4679 9.66223C14.5996 9.52925 14.7782 9.45455 14.9644 9.45455C15.1506 9.45455 15.3292 9.52925 15.4609 9.66223C15.5926 9.79521 15.6665 9.97557 15.6665 10.1636ZM11.9219 10.1636V19.6182C11.9219 19.8062 11.8479 19.9866 11.7162 20.1196C11.5845 20.2526 11.4059 20.3273 11.2197 20.3273C11.0335 20.3273 10.8549 20.2526 10.7232 20.1196C10.5916 19.9866 10.5176 19.8062 10.5176 19.6182V10.1636C10.5176 9.97557 10.5916 9.79521 10.7232 9.66223C10.8549 9.52925 11.0335 9.45455 11.2197 9.45455C11.4059 9.45455 11.5845 9.52925 11.7162 9.66223C11.8479 9.79521 11.9219 9.97557 11.9219 10.1636ZM8.17717 10.1636V19.6182C8.17717 19.8062 8.1032 19.9866 7.97152 20.1196C7.83985 20.2526 7.66126 20.3273 7.47505 20.3273C7.28883 20.3273 7.11024 20.2526 6.97857 20.1196C6.84689 19.9866 6.77292 19.8062 6.77292 19.6182V10.1636C6.77292 9.97557 6.84689 9.79521 6.97857 9.66223C7.11024 9.52925 7.28883 9.45455 7.47505 9.45455C7.66126 9.45455 7.83985 9.52925 7.97152 9.66223C8.1032 9.79521 8.17717 9.97557 8.17717 10.1636Z"
																fill="white" />
												</svg>

											</div>
										</Transition>

									</div>
									<div class="col-auto">
										<div class="btn btn-outline-primary me-2">
											Previous

										</div>
										<div class="btn btn-success">
											Next

										</div>

									</div>

								</div>

							</div>

						</div>









					</div>

					<div class="col-xl-8 col-lg-8 col-md-6">
						<div class="row  gx-1">
							<div class="col-md-12 sw-header">
								<div class="row header-row justify-content-between px-4">
									<div class="col-auto">




									</div>

									<div class="col-auto d-flex align-items-center">
										<div class="d-flex">
											<div :class="activeProject.isDirty ? 'text-warning' : activeProject.isSaving ? 'text-warning' : 'text-primary'"
													 class="btn-square disabled">

												<font-awesome-icon icon="fa-solid fa-floppy-disk"></font-awesome-icon>

											</div>

										</div>
										<div class="d-flex ms-4">
											<div class="undo-btns bg-white">
												<div class="btn-square undo">
													<svg width="18"
															 height="16"
															 viewBox="0 0 18 16"
															 fill="none"
															 xmlns="http://www.w3.org/2000/svg">
														<path d="M5.10401 0.251795L1.04883 3.50009C0.812983 3.68777 0.812983 4.04604 1.04883 4.23373L5.10401 7.48202C5.30673 7.6445 5.60295 7.6111 5.76441 7.40756C5.92276 7.20581 5.88958 6.91426 5.68994 6.75326L2.67114 4.33505L10.9084 4.33138C13.8296 4.32976 16.1868 6.69546 16.1868 9.62313C16.1868 12.5508 13.8299 14.9149 10.9084 14.9149H7.41602C7.15761 14.9135 6.94684 15.1216 6.94483 15.38C6.94346 15.6408 7.15522 15.8525 7.41602 15.8512H10.9084C14.3375 15.8512 17.1279 13.0566 17.1279 9.62313C17.1279 6.18965 14.3378 3.39198 10.9084 3.39388L2.67969 3.39877L5.68994 0.985438C5.8927 0.824067 5.92606 0.528794 5.76441 0.326258C5.53182 0.055527 5.23084 0.142599 5.10401 0.251795V0.251795Z"
																	fill="#26274F" />
													</svg>

												</div>
												<div class="btn-square redo">
													<svg width="18"
															 height="16"
															 viewBox="0 0 18 16"
															 fill="none"
															 xmlns="http://www.w3.org/2000/svg">
														<path d="M12.896 0.251795L16.9512 3.50009C17.187 3.68777 17.187 4.04604 16.9512 4.23373L12.896 7.48202C12.6933 7.6445 12.3971 7.6111 12.2356 7.40756C12.0772 7.20581 12.1104 6.91426 12.3101 6.75326L15.3289 4.33505L7.09155 4.33138C4.17037 4.32976 1.81323 6.69546 1.81323 9.62313C1.81323 12.5508 4.17006 14.9149 7.09155 14.9149H10.584C10.8424 14.9135 11.0532 15.1216 11.0552 15.38C11.0565 15.6408 10.8448 15.8525 10.584 15.8512H7.09155C3.66255 15.8512 0.87207 13.0566 0.87207 9.62313C0.87207 6.18965 3.66223 3.39198 7.09155 3.39388L15.3203 3.39877L12.3101 0.985438C12.1073 0.824067 12.0739 0.528794 12.2356 0.326258C12.4682 0.055527 12.7692 0.142599 12.896 0.251795Z"
																	fill="#26274F" />
													</svg>


												</div>

											</div>

										</div>
										<div class="d-flex ms-4">
											<div class="view-btns">
												<div class="btn-square desktop active">
													<svg width="23"
															 height="17"
															 viewBox="0 0 23 17"
															 fill="none"
															 xmlns="http://www.w3.org/2000/svg">
														<rect x="0.5"
																	y="0.5"
																	width="21.1094"
																	height="14.0493"
																	rx="2.5"
																	stroke="#26274F" />
														<rect x="0.25"
																	y="16.2283"
																	width="21.6094"
																	height="0.5"
																	rx="0.25"
																	stroke="#26274F"
																	stroke-width="0.5" />
													</svg>

												</div>
												<div class="btn-square mbl">
													<svg width="15"
															 height="23"
															 viewBox="0 0 15 23"
															 fill="none"
															 xmlns="http://www.w3.org/2000/svg">
														<rect x="0.5"
																	y="0.5"
																	width="14"
																	height="22"
																	rx="2.5"
																	stroke="#26274F"
																	stroke-opacity="0.4" />
														<rect x="5.25"
																	y="20.25"
																	width="4.5"
																	height="0.5"
																	rx="0.25"
																	stroke="#26274F"
																	stroke-opacity="0.4"
																	stroke-width="0.5" />
													</svg>


												</div>

											</div>

										</div>
										<div class="btn btn-primary fw-bold mx-2"
												 @click="shareModal = true">Share

										</div>


									</div>

								</div>

							</div>

						</div>
						<!-- <div class="content-card"> -->


						<!-- <div class="row justify-content-center"> -->
						<!-- <div class="g-0" :class="{ 'col-auto': app.isMobile, 'col': !app.isMobile }"> -->
						<div class="content-card project-wrapper px-2"
								 :class="{ mobile: app.isMobile }">
							<StreamBoard></StreamBoard>

						</div>

						<!-- </div> -->

						<!-- </div> -->

						<!-- </div> -->

					</div>

				</div>

			</div>
		</Transition>
		<Transition name="fade">
			<div v-if="shareModal"
					 class="share-modal"
					 @click.self="shareModal = false">
				<div class="main-modal elv-6 border-radius mx-auto position-relative p-4">

					<div role="button"
							 class="position-absolute btn-circle bg-primary"
							 @click="shareModal = false">
						<font-awesome-icon icon="fa-solid fa-xmark"></font-awesome-icon>

					</div>
					<div class="d-flex">


						<div class="share-label text-uppercase mb-2">Share {{ activeProject.doc.title }}

						</div>



					</div>
					<div class="d-flex flex-row justify-content-center">

						<div class="form-floating mb-3 flex-grow-1">
							<input type="text"
										 class="form-control"
										 name="Email"
										 id="Email"
										 placeholder="Email">
							<label for="floatingEmail">Email</label>

						</div>
						<div class="bg-primary text-white px-3 text-center ms-3"
								 style="height:46px;line-height:46px;border-radius:80px;">
							Send Link

						</div>

					</div>
					<div role="button"
							 class="text-primary"
							 @click="copyProjectLink()">
						<font-awesome-icon icon="fa-solid fa-link"></font-awesome-icon>
						{{ projectLinkText }}

					</div>

				</div>

			</div>
		</Transition>

	</div>
</template>
<style lang="scss" scoped>
.view-btns {
	background-color: var(--bs-light);
	border-radius: var(--bs-border-radius);

	.btn-square.active {
		background-color: #26274F33;

	}

	.btn-square {
		background-color: transparent;

	}

}

.undo-btns {
	border-radius: var(--bs-border-radius);
	border: 1px solid var(--bs-primary);

	.btn-square {
		height: 35px;
		width: 35px;
		line-height: 35px;
	}

	.undo {
		border-right: 1px solid var(--bs-primary);
		border-radius: 0;
	}
}

.step-title {
	font-weight: 700;
	font-size: 12px;
	line-height: 40px;
}

.editor-tab {
	color: var(--bs-primary);
	font-weight: 500;
	font-size: 0.9rem;
	border-radius: var(--bs-border-radius);
	height: 47px;
	background-color: transparent;
	display: inline-block;
	vertical-align: middle;
	line-height: 40px;
	cursor: pointer;
	// align-items: center !important;
	justify-content: center !important;
	flex-grow: 1 !important;
	display: flex !important;

	transition: all 0.2s ease;

	.tab-content {
		transition: all 0.2s ease;
		display: flex !important;
		height: 40px;
		flex-grow: 1 !important;
		background-color: var(--bs-light);
		border-radius: var(--bs-border-radius);
		align-items: center !important;
		justify-content: center !important;

		svg {

			margin-right: 5px;
			// display: inline-block;
		}


	}
}

.editor-tab:not(:first-child) {

	margin-left: 3px;
}

.editor-tab:not(:last-child) {

	margin-right: 3px;
}

.editor-tab.active {
	background-color: white;
	height: 62px;
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;

	.tab-content {


		background-color: inherit;
		border-radius: var(--bs-border-radius);
	}
}

.editor-tab:hover {
	background-color: white;
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;
	height: 62px;

	.tab-content {
		background-color: transparent;

	}
}

.bottom-buttons {

	bottom: 0;
	right: 0;

	.btn-square {
		height: 35px !important;
		width: 35px !important;
		line-height: 35px;
	}
}

.share-label {
	font-size: 0.8em;
	font-weight: bold;
}

.share-modal {
	position: fixed;
	width: 100vw;
	height: 100vh;
	top: 0;
	left: 0;
	background-color: rgba(0, 0, 0, 0.202);
	z-index: 99999;

	.form-floating>label {
		padding: 0.5rem;
	}

	.btn-circle {
		top: -10px;
		right: -10px;
	}

	.main-modal {
		position: relative;
		display: flex;
		flex-direction: column;
		min-height: 200px;
		top: 25%;
		width: fit-content;
		min-width: 500px;

	}
}

.form-control {
	border: 1px solid rgba(82, 78, 97, 0.25);
	border-radius: 10px;
}

input.form-control {
	height: 46px;


}

#step-buttons {

	.step-btn {
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0);
		opacity: 0;
		position: absolute;
		transform: scale(0);
		transform-origin: top;
	}

	.add-payment {
		right: 0px;
		top: 0;
		position: absolute;
	}

	.add-payment.show {
		right: 70px;
		top: 20px;
	}

	.add-step {
		right: 20px;
		top: 0;
		transform: scale(0);
		position: absolute;
		opacity: 0;

	}

	.add-step.show {
		top: 60px;
	}

	.step-btn.show {
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
		opacity: 1;
		// transform: translateY(30px);
		transform: scale(1.5);
	}

	.step-btn:hover {
		transform: scale(1.6);
	}
}

.btn {
	padding-left: 1rem;
	padding-right: 1rem;
	min-width: 106px;
	font-size: 14px;
}

:root {
	--sw-scrollbar-width: 10px;
}

.project-container {
	background-color: none !important;

}

.panel-tab:first-of-type {
	margin-top: 90px;
}

.panel-tab.admin {
	color: var(--bs-warning);
}

.panel-tab:hover {


	path {

		stroke: var(--bs-primary);
	}
}

.panel-tab {
	cursor: pointer;

	height: 45px;
	width: 45px;
	text-align: center;
	line-height: 45px;
	transition: all 0.2s ease-out;

	path {
		transition: all 0.2s ease-out;
	}
}

.panel-tab.active {
	background-color: white;
	border-left: 3.25px solid var(--bs-primary);
}

.edit-container {

	height: calc(100vh - var(--header-height) - (var(--main-container-padding)*2));
	overflow: hidden;

}

.sw-header {
	// background-color: #524E6126;
	height: 47px;

	padding-bottom: 25px;

	.header-row {
		// height: 55px;
	}

	label {
		// line-height: 55px;
		// font-weight: 700;
		// text-transform: uppercase;
	}
}

.content-card {
	--content-card-height: calc(100vh - 60px - var(--header-height) - (var(--main-container-padding)*2));
	background-color: white;
	border-radius: 8px;
	height: var(--content-card-height);
	overflow: scroll;

	.editor-content {
		max-height: calc(var(--content-card-height) - 73px - 43px);
		overflow: scroll;
	}
}

.project-wrapper {

	// height: calc(100vh - var(--header-height) - (var(--main-container-padding)*2));
	overflow-y: scroll;
	overflow-x: hidden;
	position: relative;
	// padding: 1em;
}

.mobile {
	max-width: 360px;
	width: 360px;
	max-height: 800px;
	overflow-y: scroll;
	overflow-x: hidden;
	transition: all 0.5s ease;
	--sw-scrollbar-width: 1px;


}

::-webkit-scrollbar {
	--sw-scrollbar-width: 5px;
	width: var(--sw-scrollbar-width)
}

::-webkit-scrollbar {
	--sw-scrollbar-width: 5px;
	width: var(--sw-scrollbar-width)
}

/* Track */
::-webkit-scrollbar-track {
	background: transparent;
}

/* Handle */
::-webkit-scrollbar-thumb {
	background: transparent;
	border-radius: 1rem;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
	background: #555;
}
</style>