<script setup lang="ts">
import { useStore, useModal } from "../stores/stores"
import { useRouter } from "vue-router";
import { formatDate } from "@/composables/utils"
import Icon from "@/components/icons/Icon.vue"
import { ref } from "vue";
import Loader from "../components/Loader.vue";
import CircleButton from "../components/icons/CircleButton.vue";
const app = useStore()
const router = useRouter()
const modal = useModal()
const searchFilter = ref('')
const confirmDelete = ref(false)
const projectToDelete = ref('')
const showTemplates = ref(1)
function newProject() {
	router.push('/new-project')

}
function gotToProject(project_name: string) {
	console.log({ project_name })
	app.isProjectLoading = true
	app.loadActiveProject(project_name).then(() => {
		router.push('/edit/' + project_name)
		app.isProjectLoading = false
	})

}
function gotToViewProject(project_name: string) {
	console.log({ project_name })
	app.isProjectLoading = true
	app.loadActiveProject(project_name).then(() => {
		router.push('/view/' + project_name)
		app.isProjectLoading = false
	})

}

function deleteProject(project_name: string) {
	projectToDelete.value = project_name
	confirmDelete.value = true
}
</script>

<template>
	<Transition name="fade"
							mode="out-in">


		<div v-if="app.isProjectLoading"
				 class="vh-100">

			<Loader></Loader>

		</div>
		<div v-else>
			<div class="container mt-5">
				<div class="row my-5">
					<div class="col-lg-12">
						<h1 class="text-center fw-light">What are you working on today?</h1>

					</div>

				</div>
				<div class="row mb-3 justify-content-between">
					<div class="col-auto">
						<div class="input-group mb-3"
								 style="width: 465px;">
							<input v-model="searchFilter"
										 type="text"
										 name="name"
										 id="name"
										 class="form-control"
										 placeholder="Search"
										 aria-describedby="suffixId"
										 autocomplete="off">
							<Icon icon="search"
										class="search-icon"></Icon>

						</div>

					</div>
					<div v-if="app.isAdmin"
							 class="col-auto">
						<button class="btn btn-info text-white"
										@click="$router.push('templates')">
							<small class="text-xs">Templates</small>
						</button>

					</div>
					<div class="col-auto">
						<button class="btn btn-primary text-white new-project-button"
										@click="newProject()">
							<font-awesome-icon icon="fa-solid fa-plus" /> New Project
						</button>

					</div>

				</div>
				<div class="row mt-4">
					<div class="col position-relative">
						<div class="row justify-content-between mx-auto mb-4">
							<div class="col-1">

							</div>
							<div class="col">
								<span>
									Project Name
								</span>

							</div>
							<div class="col">

							</div>
							<div class="col-1">
								status

							</div>
							<div class="col-2">
								date created

							</div>
							<div class="col-2">

								last updated

							</div>
							<div class="col">

							</div>

						</div>

						<TransitionGroup name="list-scale-y">


							<div v-for="project in app.userProjects.filter((project) => {
								if (showTemplates) {
							
									if (searchFilter == '') {
										return project
									} else if (project.project_name.toLowerCase().indexOf(searchFilter.toLowerCase()) != -1) {
										return project;
									}
								}
							})"
									 class="row justify-content-between project-row mb-3 elv-1 mx-auto"
									 :key="project.name">

								<div class="col-1">
									<div class="preview-img"
											 :style="'background-image:url(' + app.staticHostUrl + project.preview_image + ')'">

									</div>

								</div>
								<div role="button"
										 class="col"
										 @click="gotToProject(project.name)">
									<span class="fw-semibold">
										{{ project.project_name }}</span>

								</div>
								<div class="col">
									<div v-if="project.is_template == 1"
											 class="">
										<div class="badge bg-info">Template

										</div>
										<!-- <div class="template-name">{{project.template_name}}

										</div> -->

									</div>


								</div>
								<div class="col-1">
									<span class="">
										{{ project.status }}</span>

								</div>
								<div class="col-2">
									{{ formatDate(project.creation) }}

								</div>
								<div class="col-2">
									{{ formatDate(project.modified) }}

								</div>
								<div class="col">
									<div class="row justify-content-center">

										<div class="col-auto">


											<div role="button"
													 class="icon-btn"
													 @click="gotToViewProject(project.name)">
												<Icon icon="view"></Icon>

											</div>

										</div>
										<div class="col-auto">
											<div role="button"
													 class="icon-btn"
													 @click="gotToProject(project.name)">
												<Icon icon="edit"></Icon>

											</div>

										</div>
										<div class="col-auto">
											<div role="button"
													 class="icon-btn">
												<Icon icon="share"></Icon>

											</div>

										</div>

										<div class="col-auto">
											<div role="button"
													 class="icon-btn"
													 @click="deleteProject(project.name)">
												<Icon icon="trash"></Icon>

											</div>

										</div>


									</div>

								</div>

							</div>

						</TransitionGroup>

					</div>

				</div>
				<div>

				</div>

			</div>
			<div v-if="confirmDelete"
					 class="confirmation"
					 @click.self="confirmDelete = false">
				<div class="card mx-auto">
					<div class="card-body">
						<div role="button"
								 class="position-absolute circle-button"
								 @click="confirmDelete = false">
							<CircleButton size="small"
														icon="x"
														color="green"></CircleButton>

						</div>
						<div class="row m-4">

							<div class="col">
								<h4>Are you sure you want to delete this project?</h4>

							</div>

						</div>


						<div class="row pt-3 justify-content-center">
							<div class="col-auto">
								<button class="btn btn-secondary text-white me-4"
												@click="confirmDelete = false">
									No
								</button>
								<button class="btn btn-danger text-white"
												@click="app.deleteProject(projectToDelete)">
									Yes
								</button>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>
	</Transition>
</template>
<style lang="scss" scoped>
.template-name {
	line-height: 1rem;
	width: fit-content;
}

.preview-img {
	border-radius: var(--bs-border-radius);
	height: calc(100% - 5px);
	width: 100%;
	overflow: hidden;
	background-size: cover;
	background-repeat: no-repeat;
	padding: 3px;
	background-origin: content-box;
}

.confirmation {
	position: fixed;
	width: 100vw;
	height: 100vh;
	top: 0;
	left: 0;
	background-color: rgba(0, 0, 0, 0.202);

	.circle-button {
		top: -10px;
		right: -10px;
	}

	.card {
		min-height: 200px;
		top: 50%;
		width: fit-content;
	}
}

.project-row {
	border-radius: 15px;
	// box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.12);
	height: 56px;
	line-height: 56px;

	transition: all 0.2s ease;
}

.project-row:hover {
	transform: scale(1.01);
	box-shadow: var(--elv-4-shadow);
}

.icon-btn {
	/* margin-right: 1.5rem; */
	transition: all 0.2s ease-out;
}

.icon-btn:hover {
	stroke: var(--bs-primary) !important;
	transform: scale(1.2);
}

.new-project-button {
	border-radius: 80px;
	width: 214.28px;
}

.search-icon {
	background-color: white;
	border-radius: 1rem;
	line-height: 35px;
	padding: 0 1rem;
	box-shadow: inset 0 1px 2px rgb(0 0 0 / 8%);
}
</style>