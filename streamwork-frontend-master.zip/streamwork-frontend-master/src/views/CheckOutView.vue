<template>

  <div class="container checkout-container">
    <div class="row">
      <div class="col">
        <Transition name="fade">
          <div v-if="app.customerAccount?.account_type == 'Free Account'" class="card checkout-card mx-auto">



            <div class="row justify-content-between h-100 px-4 py-3">
              <div class="col-md-6 py-5 px-5">
                <img src="@/assets/img/about.svg?url" alt="">
                <div class="card shadow-sm border text-center mt-2">
                  <div class="card-header bg-primary bg-gradient text-white">

                    <div class="h2 mb-0">PRO

                    </div>


                  </div>

                  <div class="card-body">
                    <img class="price-img" src="@/assets/img/pro.svg?url" alt="">
                    <br>
                    <p class="h2 fw-normal"><small>$</small>{{ payment.plans.proPlanMonthly.planCost }}/Month</p>
                    <hr class="border-dark">
                    <p>Up to 50 projects</p>
                    <hr class="border-dark">
                    <p>Custom links</p>
                    <hr class="border-dark">
                    <p class="mb-0">Additional templates</p>

                  </div>

                </div>

              </div>
              <div class="col-md-6 bg-light p-4">


                <div class="row g-5">

                  <div class="col-12">
                    <h4 class="mb-3">Billing Information</h4>
                    <div v-if="!app.customerAccount?.billing_address">
                      <div class="row g-3">
                        <div class="col-sm-6">
                          <label for="firstName" class="form-label">First name</label>
                          <input v-model="payment.billingInfo.firstName" type="text" class="form-control"
                            :class="payment.formFields.firstName.validClass" id="firstName" placeholder="" required>
                          <div class="invalid-feedback">
                            {{ payment.formFields.firstName.errorMessage }}

                          </div>

                        </div>

                        <div class="col-sm-6">
                          <label for="lastName" class="form-label">Last name</label>
                          <input v-model="payment.billingInfo.lastName" type="text" class="form-control"
                            :class="payment.formFields.lastName.validClass" id="lastName" placeholder="" required>
                          <div class="invalid-feedback">
                            {{ payment.formFields.lastName.errorMessage }}


                          </div>

                        </div>

                      </div>
                      <div class="row">
                        <div class="col">
                          <label for="company" class="form-label">Company</label>
                          <input v-model="payment.billingInfo.company" type="text" class="form-control" id="company"
                            placeholder="">
                          <div class="invalid-feedback">

                          </div>

                        </div>

                      </div>
                      <div class="row">



                        <div class="col-8">
                          <label for="address" class="form-label">Address</label>
                          <input v-model="payment.billingInfo.address" type="text" class="form-control" id="address"
                            placeholder="1234 Main St" required>
                          <div class="invalid-feedback">
                            Please enter your address.

                          </div>

                        </div>
                        <div class="col-4">
                          <label for="city" class="form-label">City</label>
                          <input v-model="payment.billingInfo.city" type="text" class="form-control"
                            :class="payment.formFields.city.validClass" id="city" placeholder="1234 Main St" required>
                          <div class="invalid-feedback">
                            {{ payment.formFields.city.errorMessage }}

                          </div>

                        </div>



                        <div class="col-md-5">
                          <label for="country" class="form-label">Country</label>
                          <input @focusin="revealCountries()" @focusout="showCountries = false"
                            v-model="payment.billingInfo.country.name" type="text" autocomplete="off"
                            class="form-control" id="country" :class="payment.formFields.country.validClass" />
                          <div v-show="showCountries" class="countries">
                            <div class="list-group">
                              <div v-for="country in filterCountries()" @mousedown="selectCountry(country)"
                                class="list-group-item country-list" :key="country.code" :id="country.code">
                                {{ country.name }}

                              </div>

                            </div>



                          </div>
                          <div class="invalid-feedback">
                            {{ payment.formFields.country.errorMessage }}

                          </div>

                        </div>

                        <div class="col-md-4" v-show="payment.billingInfo.country.code == 'us'">
                          <label for="state" class="form-label">State</label>
                          <input @focusin="revealStates()" v-model="payment.billingInfo.state.name" type="text"
                            autocomplete="off" class="form-control" id="country" />
                          <div v-show="showStates" class="states">
                            <div class="list-group">
                              <div v-for="state in filterStates()" @click="selectState(state)"
                                class="list-group-item country-list" :key="state.abbreviation" :id="state.abbreviation">
                                {{ state.name }}

                              </div>

                            </div>



                          </div>
                          <div class="invalid-feedback">
                            Please provide a valid state.

                          </div>

                        </div>

                        <div class="col-md-3">
                          <label for="zip" class="form-label">Zip</label>
                          <input v-model="payment.billingInfo.zip" type="text" class="form-control" id="zip"
                            placeholder="" required>
                          <div class="invalid-feedback">
                            Zip code required.

                          </div>

                        </div>

                      </div>

                    </div>
                    <BillingAddress v-else></BillingAddress>
                    <hr>
                    <div class="row">
                      <div class="col">
                        <h4>Payment Information</h4>

                      </div>

                    </div>


                    <div class="row px-4 mb-2">
                      <div v-if="!app.hasVaultedShopper" class="card bg-secondary bg-gradient text-white">
                        <div class="card-body">
                          <div class="row row g-2 mb-3 justify-content-center">

                            <div class="col-auto">
                              <img class="cc-img shadow-sm" src="@/assets/img/5b7b3de-Mastercard.png" />

                            </div>
                            <div class="col-auto">
                              <img class="cc-img shadow-sm" src="@/assets/img/9018c4f-Visa.png" />

                            </div>
                            <div class="col-auto">
                              <img class="cc-img shadow-sm" src="@/assets/img/amex.png" />

                            </div>
                            <div class="col-auto">
                              <img class="cc-img shadow-sm" src="@/assets/img/8c73810-Diners_Club.png" />

                            </div>
                            <div class="col-auto">
                              <img class="cc-img shadow-sm" src="@/assets/img/caea86d-Discover.png" />

                            </div>
                            <div class="col-auto">
                              <img class="cc-img shadow-sm" src="@/assets/img/e076aed-JCB.png" />

                            </div>

                          </div>
                          <div class="row mb-3">

                            <div class="col">
                              <label for="cc-number" class="form-label">Credit
                                card
                                number</label>
                              <div class="input-group mb-3">
                                <div class="form-control hosted-field" id="card-number" data-bluesnap="ccn">

                                </div>

                                <span class="cc-choice">
                                  <Transition name="fade">
                                    <div v-if="ccChoice == 'mastercard'" class="cc-img" :class="ccChoice">

                                    </div>
                                    <div v-else-if="ccChoice == 'amex'" class="cc-img" :class="ccChoice">

                                    </div>
                                    <div v-else-if="ccChoice == 'visa'" class="cc-img" :class="ccChoice">

                                    </div>
                                    <div v-else-if="ccChoice == 'discover'" class="cc-img" :class="ccChoice">

                                    </div>
                                    <div v-else-if="ccChoice == 'jcb'" class="cc-img" :class="ccChoice">

                                    </div>
                                    <div v-else-if="ccChoice == 'diners'" class="cc-img" :class="ccChoice">

                                    </div>
                                  </Transition>
                                </span>


                              </div>



                              <div v-show="payment.errorCodes.ccn.show" class="cc-invalid">
                                {{ payment.errorCodes.ccn.errorMessage }}

                              </div>

                            </div>

                          </div>
                          <div class="row justify-content-between">
                            <div class="col">
                              <label for="cc-expiration" class="form-label">Expiration</label>
                              <div class="form-control" id="exp-date" data-bluesnap="exp">

                              </div>
                              <div v-show="payment.errorCodes.exp.show" class="cc-invalid">
                                {{ payment.errorCodes.exp.errorMessage }}

                              </div>

                            </div>


                            <div class="col">
                              <label for="cc-cvv" class="form-label">CVV</label>
                              <div class="form-control" id="cvv" data-bluesnap="cvv">

                              </div>
                              <div v-show="payment.errorCodes.cvv.show" class="cc-invalid">

                                {{ payment.errorCodes.cvv.errorMessage }}

                              </div>

                            </div>


                          </div>



                        </div>


                      </div>
                      <div v-if="app.hasVaultedShopper" class="row">
                        <PaymentMethod></PaymentMethod>

                      </div>


                    </div>
                    <div class="row justify-content-between">
                      <div class="col text-center">
                        <button class="btn btn-primary self-align-middle w-100" @click="submitPayment()">Pay
                          Now</button>

                      </div>

                    </div>





                  </div>

                </div>


              </div>

            </div>


            <Transition name="fade">
              <div v-if="payment.isProcessing" class="processing-payment">
                <Loader><span class="fw-bold text-dark"> Processing your payment...</span></Loader>

              </div>
            </Transition>

          </div>
          <div v-else class="d-flex justify-content-center align-items-center" style="height:80vh">


            <h1>{{ app.customerAccount?.account_type }}</h1>




          </div>
        </Transition>

      </div>

    </div>

    <div class="fixed-bottom">



      <Footer>

      </Footer>

    </div>



  </div>



</template>

<script lang="ts" setup>
import { serverApi } from '@/composables/frappe';
import { usePayment, useStore } from '@/stores/stores';
import type { CardData, CardType, ErrorCode, ErrorDescription, TagId } from '@/types/bluesnap';
import { onMounted, ref, watch } from 'vue';
import Footer from '../components/Footer.vue';
import PaymentMethod from '../components/checkout/PaymentMethod.vue';
import Loader from '../components/Loader.vue';
import BillingAddress from '../components/checkout/BillingAddress.vue';

const app = useStore()
app.showFooter = true
const payment = usePayment()
const isBsLoading = ref(true);
const countries = ref([])
const states = [{ "name": "Alabama", "abbreviation": "AL" }, { "name": "Alaska", "abbreviation": "AK" }, { "name": "Arizona", "abbreviation": "AZ" }, { "name": "Arkansas", "abbreviation": "AR" }, { "name": "California", "abbreviation": "CA" }, { "name": "Colorado", "abbreviation": "CO" }, { "name": "Connecticut", "abbreviation": "CT" }, { "name": "Delaware", "abbreviation": "DE" }, { "name": "Florida", "abbreviation": "FL" }, { "name": "Georgia", "abbreviation": "GA" }, { "name": "Hawaii", "abbreviation": "HI" }, { "name": "Idaho", "abbreviation": "ID" }, { "name": "Illinois", "abbreviation": "IL" }, { "name": "Indiana", "abbreviation": "IN" }, { "name": "Iowa", "abbreviation": "IA" }, { "name": "Kansas", "abbreviation": "KS" }, { "name": "Kentucky", "abbreviation": "KY" }, { "name": "Louisiana", "abbreviation": "LA" }, { "name": "Maine", "abbreviation": "ME" }, { "name": "Maryland", "abbreviation": "MD" }, { "name": "Massachusetts", "abbreviation": "MA" }, { "name": "Michigan", "abbreviation": "MI" }, { "name": "Minnesota", "abbreviation": "MN" }, { "name": "Mississippi", "abbreviation": "MS" }, { "name": "Missouri", "abbreviation": "MO" }, { "name": "Montana", "abbreviation": "MT" }, { "name": "Nebraska", "abbreviation": "NE" }, { "name": "Nevada", "abbreviation": "NV" }, { "name": "New Hampshire", "abbreviation": "NH" }, { "name": "New Jersey", "abbreviation": "NJ" }, { "name": "New Mexico", "abbreviation": "NM" }, { "name": "New York", "abbreviation": "NY" }, { "name": "North Carolina", "abbreviation": "NC" }, { "name": "North Dakota", "abbreviation": "ND" }, { "name": "Ohio", "abbreviation": "OH" }, { "name": "Oklahoma", "abbreviation": "OK" }, { "name": "Oregon", "abbreviation": "OR" }, { "name": "Pennsylvania", "abbreviation": "PA" }, { "name": "Rhode Island", "abbreviation": "RI" }, { "name": "South Carolina", "abbreviation": "SC" }, { "name": "South Dakota", "abbreviation": "SD" }, { "name": "Tennessee", "abbreviation": "TN" }, { "name": "Texas", "abbreviation": "TX" }, { "name": "Utah", "abbreviation": "UT" }, { "name": "Vermont", "abbreviation": "VT" }, { "name": "Virginia", "abbreviation": "VA" }, { "name": "Washington", "abbreviation": "WA" }, { "name": "West Virginia", "abbreviation": "WV" }, { "name": "Wisconsin", "abbreviation": "WI" }, { "name": "Wyoming", "abbreviation": "WY" }]
const bsObj = ref({})
const cardList = ["@/assets/img/97e7acc-Amex.png", '8c73810-Diners_Club.png', 'caea86d-Discover.png', '076aed-JCB.png', '5b7b3de-Mastercard.png', '9018c4f-Visa.png']
const cardUrls = {
  "AMEX": "@/assets/img/97e7acc-Amex.png",
  "DINERS": "@/assets/img/8c73810-Diners_Club.png",
  "DISCOVER": "@/assets/img/caea86d-Discover.png",
  "JCB": "@/assets/img/e076aed-JCB.png",
  "MASTERCARD": "@/assets/img/5b7b3de-Mastercard.png",
  "VISA": "@/assets/img/9018c4f-Visa.png"
}
const ccChoice = ref('blank-cc')
const showCountries = ref(false)
const showStates = ref(false)

watch(payment.billingInfo, () => {
  console.info('statechange')
  if (payment.formFields.wasValidated) {
    console.info('statechangevalidated')

    payment.validateBillingInfo()


  }
})
onMounted(() => {

  serverApi.getList('Country', ['name', 'code'], undefined, undefined, 500).then((response) => {

    countries.value = response
    //info(response)
  })
  payment.getPlans()
  if (app.customerAccount?.name) {
    payment.getVaultedShopper(app.customerAccount?.name)
  }

  get_bs_token()
})

function filterCountries() {
  let filtered = countries.value.filter((str: { name: string }) => {

    if (str.name.toLowerCase().indexOf(payment.billingInfo.country.name.toLowerCase()) != -1) {
      return str
    }

  })

  return filtered
}

function filterStates() {
  let filtered = states.filter((state) => {

    if (state.name.toLowerCase().indexOf(payment.billingInfo.state.name.toLowerCase()) != -1) {
      return state
    }

  })

  return filtered
}
function revealCountries() {

  payment.billingInfo.country = { name: '', code: '' }
  showCountries.value = true
}
function revealStates() {

  payment.billingInfo.state = { name: '', abbreviation: '' }
  showStates.value = true
}

function selectCountry(country: { name: string, code: string }) {

  payment.billingInfo.country = country

  //showCountries.value = false

}
function selectState(state: { name: string, abbreviation: string }) {

  payment.billingInfo.state = state

  showStates.value = false

}

function submitPayment() {

  console.info('cliked')
  if (app.hasVaultedShopper) {
    payment.submitPayment()
  } else {
    payment.validateBillingInfo()
    if (payment.validated) {


      bluesnap.hostedPaymentFieldsSubmitData(function (callback: any) {
        console.info('callback')
        if (null != callback.cardData) {
          var fraudSessionId = callback.transactionFraudInfo.fraudSessionId;

          console.log();
          payment.cardData = callback.cardData
          payment.statusCode = callback.statusCode
          payment.transactionFraudInfo = callback.transactionFraudInfo
          console.info(callback)
          payment.submitPayment()
          // submit the form 
        } else {
          var errorArray = callback.error;
          for (i in errorArray) {
            console.log("Received error: tagId= " +
              errorArray[i].tagId + ", errorCode= " +
              errorArray[i].errorCode + ", errorDescription= " +
              errorArray[i].errorDescription);
          }
        }
      });
    }
  }
}

function get_bs_token() {

  serverApi.frappeCall('GET', 'streamwork.bluesnap.bluesnap_api.get_token').then((response) => {

    console.info(response)
    payment.token = response
    create_bs_object(response)
    bluesnap.hostedPaymentFieldsCreate(bsObj.value)
    isBsLoading.value = false


  })
}

function create_bs_object(token: string) {

  bsObj.value = {
    //insert your Hosted Payment Fields token
    token: token,
    onFieldEventHandler: {
      onFocus: function (tagId: TagId) {
        // Handle focus
        //    changeImpactedElement(tagId, "hosted-field-valid hosted-field-invalid", "hosted-field-focus");
      },
      onBlur: function (tagId: TagId) {
        // Handle blur
        //    changeImpactedElement(tagId, "hosted-field-focus");
      },
      onError: function (tagId: TagId, errorCode: ErrorCode, errorDescription: ErrorDescription) {

        console.info(errorCode, errorDescription, tagId)
        payment.errorCodes[tagId].errorMessage = payment.errorCodes[tagId][errorDescription]
        payment.errorCodes[tagId].show = true;
        // Handle a change in validation
        //    changeImpactedElement(tagId, "hosted-field-valid hosted-field-focus", "hosted-field-invalid");
        //$("#" + tagId + "-help").removeClass('helper-text-green').text(errorCode + " - " + errorDescription);
      },
      onType: function (tagId: TagId, cardType: CardType, cardData: CardData) {
        payment.errorCodes[tagId].show = false;
        ccChoice.value = cardType.toLowerCase()
        // get card type from cardType and display card image
        //    $("#card-logo > img").attr("src", this.cardUrl[cardType]);
        //    if (null != cardData) {
        //        $("#" + tagId + "-help").addClass('helper-text-green').text(JSON.stringify(cardData));
        //    }
      },
      onValid: function (tagId: TagId) {
        console.info(tagId)
        payment.errorCodes[tagId].show = false;
        // Handle a change in validation
        //    changeImpactedElement(tagId, "hosted-field-focus hosted-field-invalid", "hosted-field-valid");
        //    $("#" + tagId + "-help").text("");
      }
    },
    //styling is optional
    style: {
      // Styling all inputs
      "input": {
        "font-size": "1rem",
        "font-family":
          "RobotoDraft,Roboto,Helvetica Neue,Helvetica,Arial,sans-serif",
        "color": "#555"
      },
      // Styling input state
      ":focus": {
        "color": "#555"
      },
      "::placeholder": {
        "color": "#d9d9d9"
      }
    },
    ccnPlaceHolder: "xxxx-xxxx-xxxx-xxxx",
    cvvPlaceHolder: "123",
    expPlaceHolder: "MM / YY"
  }

}




</script>


<style lang="scss" scoped>
.paid-account {
  min-height: 500px;
}

.cc-invalid {

  width: 100%;
  margin-top: 0.25rem;
  font-size: 0.875em;
  color: #e65d5d;
}

.hosted-field {}

.cart-container {

  background-color: #F7FAFC;
  height: 100%;
  margin: 12px;
  text-align: center;
  padding-top: 50px;
  padding: 20px;
}

.countries,
.states {
  max-width: fit-content;
  position: absolute;
  max-height: 200px;
  overflow-y: scroll;
  z-index: 1000;
}

.cart-card {
  min-height: 70vh;
}

.price-img {
  width: 130px;
  margin-bottom: 30px;
}

#card-number,
#cvv,
#exp-date {
  height: 38px;
  /*height: 60px;
    max-height: 60px;
    border: 1px solid #9EAEBC;
    border-radius: var(--border-radius); */
}

#cvv {}

#checkout-form label {}




.cc-img {
  width: 40px;
  box-shadow: var(--bs-shadow);
}

.country-list:hover {
  background-color: var(--bs-primary);
  color: white;
}

/* Hosted Payment Fields styles*/
.hosted-field-focus {
  outline: none;
  background-image: linear-gradient(#009688, #009688), linear-gradient(#d2d2d2, #d2d2d2);
  animation: input-highlight 0.5s forwards;
  box-shadow: none;
  background-size: 0 2px, 100% 1px;
}

.cc-form-control {}

:root {
  --checkout-margin: calc(((100vh - 688px)/2)/2)
}

.checkout-card {
  max-width: 996px;

  margin-top: calc(((100vh - 688px)/2)/2)
}

.checkout-container {
  height: calc(100vh - var(--header-height) - (var(--main-container-padding)*2));
}

.cc-choice {

  width: 62px;
  display: flex;
  align-items: center;
  padding: 0;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #212529;
  text-align: center;
  white-space: nowrap;
  background-color: white;
  border: 1px solid #ced4da;
  border-radius: 0.375rem;


}

.blank-cc {}

.cc-choice .cc-img {
  width: 100%;
  height: 100%;
  background-size: 56px 38px;
  background-clip: padding-box;
  background-repeat: no-repeat;
  background-position: left;
}

.amex {
  background-image: url('@/assets/img/amex.png');
}

.visa {
  background-image: url('@/assets/img/9018c4f-Visa.png');

}

.mastercard {
  background-image: url('@/assets/img/5b7b3de-Mastercard.png')
}

.discover {
  background-image: url('@/assets/img/caea86d-Discover.png')
}

.diners {
  background-image: url('@/assets/img/8c73810-Diners_Club.png');

}

.jcb {
  background-image: url('@/assets/img/e076aed-JCB.png');

}

.processing-payment {
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.8);
}
</style>