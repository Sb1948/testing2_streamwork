<template>
	<div>
		<div class="row justify-content-start mb-4">
			<div v-for="(category) in app.categories"
					 class="col-auto g-2 mb-4 sw-width"
					 :key="category.name">
				<div class="category-card bg-white border"
						 :class="{ active: app.activeProject.doc.category == category.name }"
						 :id="category.name"
						 @click="app.activeProject.doc.category = category.name">
					<div class="container h-100 mb-2 pb-2 border-bottom">
						<div class="d-flex flex-row justify-content-start align-items-center">



							<div class="category-icon-wrapper me-2">
								<img class="category-icon"
										 :src="app.staticHostUrl + category.category_icon" />

							</div>

							<div class="category-name-wrapper text-center">


								<span class="category-name">{{ category.category_name }}</span>


							</div>




						</div>


					</div>
					<div class="row px-3">



						<div v-for="template in category.templates"
								 class="col-auto mb-4 sw-width"
								 :key="template.name">
							<div class="card template-card border-secondary"
									 :id="template.name"
									 @click="gotToProject(template.name)">


								<div class="template-icon-wrapper">
									<img v-if="template.preview_image"
											 class="img-fluid"
											 :src="app.staticHostUrl + template.preview_image" />

								</div>

								<div class="mx-auto text-center text-xs no-select">{{ template.template_name }}

								</div>


							</div>


						</div>

					</div>

				</div>

			</div>

		</div>

	</div>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
import { useRouter } from 'vue-router';

const router = useRouter()
const app = useStore()
function gotToProject(project_name: string) {
	console.log({ project_name })
	app.isProjectLoading = true
	app.loadActiveProject(project_name).then(() => {
		router.push('/edit/' + project_name)
		app.isProjectLoading = false
	})

}
</script>

<style lang="scss" scoped>
.category-card {
	// box-shadow: 0 0px 0px rgba(0, 0, 0, 0.01);
	// height: 130px;
	// width: 130px;
	cursor: pointer;
	font-size: 16px;
	transition: all 0.15s ease;
	//	border: 1px solid var(--bs-border-color);
	border-radius: var(--bs-border-radius);

	.category-name {
		transition: all 0.15s ease;
	}

}

/* .category-card.active {
	background-color: var(--bs-primary);

	.category-name {

		color: white;
		font-weight: bold;
	}
}

.category-card.active:hover {
	.category-name {
		color: white;
	}
}

.category-card:hover {
	.category-name {
		color: var(--bs-primary);
	}

	transform: scale(1.02);
	box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);
} */

.category-wrapper,
.template-wrapper {
	max-width: 1000px;

}

.category-icon-wrapper {
	// height: 65px;
	width: fit-content;
}

.category-icon {
	height: 35px;
	width: fit-content;
	margin: 10px 0 0 0;
}

.category-name {
	line-height: 1.5;
	font-size: 1rem;
	color: #524E61;
	display: inline-block;
	vertical-align: middle;
}

.category-name-wrapper {
	// line-height: 65px;
}

.template {
	height: 440px;
	background-size: cover;
	background-repeat: no-repeat;

}

.template-card {
	height: 195px;
	width: 150px;
	font-size: 18px;
	transition: all 0.2s ease-out;
}

.template-icon-wrapper {
	overflow: hidden;
	margin: 1rem;
}

.template-card {
	box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.12);
}

.template-card:hover {
	cursor: pointer;
	transform: scale(1.05);
	box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.4);

}
</style>