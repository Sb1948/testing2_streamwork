<template>
	<div class="container-fluid mt-5">
		<div class="row justify-content-center my-4">
			<div class="col-auto">
				<h1 class="text-center fw-light">Account Settings</h1>

			</div>


		</div>
		<div class="row justify-content-center">

			<div class="col-auto">


				<div class="elv-4 p-2 bg-white mt-sm-5 border-radius account-settings">


					<div class="row text-center">
						<div class="col-auto">
							<div class="profile-wrapper">
								<Transition name="fade"
														mode="out-in">
									<div v-if="app.userDoc.user_image && !upload"
											 class="profile-image shadow-sm img-fluid"
											 :style="{ backgroundImage: 'url(' + [app.userDoc.user_image] + ')' }">



									</div>
									<div v-else>
										<FileUploader></FileUploader>

									</div>
								</Transition>

							</div>
							<div role="button"
									 @click="toggleUploadButton()"
									 class="upload-button">
								<Transition name="fade"
														mode="out-in">

									<b v-if="uploadButton == 'Upload'">{{ uploadButton }}</b>
									<b v-else-if="uploadButton == 'Cancel'">{{ uploadButton }}</b>
								</Transition>

							</div>

						</div>
						<div class="col">
							<div class="d-flex flex-row mb-3">
								<div class="text-start flex-grow-1 px-2">

									<label class="form-label"
												 for="firstname">First Name</label>
									<input type="text"
												 class="profile-input form-control"
												 :value="app.userDoc.first_name"
												 disabled>

								</div>
								<div class="text-start flex-grow-1 px-2">
									<label class="form-label"
												 for="lastname">Last Name</label>
									<input type="text"
												 class="profile-input form-control"
												 :value="app.userDoc.last_name"
												 disabled>

								</div>

							</div>
							<div class="d-flex flex-row">
								<div class="text-start flex-grow-1 px-2">

									<label class="form-label"
												 for="firstname">Email Address</label>
									<input type="text"
												 class="profile-input form-control"
												 :value="app.userDoc.email"
												 disabled>

								</div>


							</div>

						</div>

					</div>





				</div>

			</div>


		</div>
		<div v-if="false"
				 class="row">
			<div class="col-md-5">

				<div class="card wrapper card-shadow bg-white mt-sm-5">
					<h4 class="pb-4 border-bottom">Billing Informations</h4>
					<div class="d-flex align-items-start py-3 border-bottom">
						<div class="card-body">
							<BillingAddress></BillingAddress>
							<Transition name="fade"
													appear>


								<div v-if="app.hasVaultedShopper"
										 class="row">
									<div class="col"
											 style="max-width:400px;">


										<PaymentMethod></PaymentMethod>

									</div>

								</div>
							</Transition>

						</div>

					</div>


				</div>

			</div>

		</div>

	</div>
</template>

<script setup lang="ts">
import { serverApi } from '@/composables/frappe';
import { usePayment, useStore } from '@/stores/stores';
import { onMounted, ref } from 'vue';
import FileUploader from '../components/FileUploader.vue'
import PaymentMethod from '../components/checkout/PaymentMethod.vue';
import Loader from '../components/Loader.vue';
import BillingAddress from '../components/checkout/BillingAddress.vue';

const app = useStore()
const myFiles = ''
const upload = ref(false)
const uploadButton = ref('Upload')
const payment = usePayment()
onMounted(() => {
	if (app.customerAccount?.name) {
		payment.getVaultedShopper(app.customerAccount?.name)
	}

})

function toggleUploadButton() {

	upload.value = !upload.value
	if (upload.value) {
		uploadButton.value = 'Cancel'
	} else {
		uploadButton.value = 'Upload'
	}
}



</script>

<style lang="scss" scoped>
.form-control {
	border: 1px solid rgba(82, 78, 97, 0.25);
	border-radius: 10px;
}

.form-label {
	font-size: 14px;
	color: #524E61;

}

input.form-control {
	height: 38px;


}

.account-settings {
	width: 700px;
}

.profile-wrapper {
	width: 145px;
	height: 145px;
	border-top-left-radius: var(--bs-border-radius);
	border-top-right-radius: var(--bs-border-radius);
	overflow: hidden;
}

.profile-image {
	height: 100%;
	background-size: cover;
	background-repeat: no-repeat;
	background-origin: padding-box;
}

.profile-input:disabled {
	background-color: transparent;
	border: none;
}

/* imported card */


.img {
	width: 70px;
	height: 70px;
	border-radius: 6px;
	object-fit: cover;
}

#img-section p,
#deactivate p {
	font-size: 12px;
	color: #777;
	margin-bottom: 10px;
	text-align: justify;
}

#img-section b,
#img-section button,
#deactivate b {
	font-size: 14px;
}

label {
	margin-bottom: 0;
	font-size: 14px;
	font-weight: 500;
	color: #777;
	padding-left: 3px;
}



input[placeholder] {
	font-weight: 500;
}




@media(max-width:576px) {
	.wrapper {
		padding: 25px 20px;
	}

	#deactivate {
		line-height: 18px;
	}
}

.upload-button {
	background-color: var(--bs-secondary);
	color: white;
	line-height: 2rem;
	border-bottom-left-radius: var(--bs-border-radius);
	border-bottom-right-radius: var(--bs-border-radius);
	transition: all 0.1s ease-in-out;
}

.upload-button:hover {
	background-color: var(--bs-primary);
}
</style>