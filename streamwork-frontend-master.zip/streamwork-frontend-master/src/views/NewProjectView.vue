<template>
	<div>
		<div v-if="app.isProjectCreating"
				 class="vh-100">

			<Loader></Loader>

		</div>

		<div v-else
				 class="new-project-container">

			<div class="text-center new-project-title mb-4">New Project

			</div>
			<div class="progress-container  mx-auto mb-5 position-relative">
				<div class="progress progress-line"
						 style="height: 3px;">
					<div class="progress-bar"
							 role="progressbar"
							 :style="'width:' + (app.newProject.step == 1 ? '0' : app.newProject.step == 2 ? '50' : app.newProject.step == 3 ? '100' : '0') + '%'">


					</div>

				</div>
				<div class="row text-center mx-auto position-relative"
						 style="z-index: 2;">
					<div class="col-auto gx-0">
						<div :class="{ active: app.newProject.step > 1 }"
								 class="step"
								 @click="app.newProject.step > 1 ? setStep(1) : ''">

							<svg width="44"
									 height="44"
									 viewBox="-2 -2 44 44"
									 xmlns="http://www.w3.org/2000/svg"
									 :class="{ 'current-step': app.newProject.step == 1, 'future-step': app.newProject.step < 1, 'completed-step': app.newProject.step > 1, }">
								<circle cx="20"
												cy="20"
												r="20" />
								<path
											d="M15.3533 27.7778V25.1378H19.0533V17.3978L15.7133 18.7778L15.0133 15.9778L20.6933 13.7578H22.3733V25.1378H25.4933V27.7778H15.3533Z" />

							</svg>





						</div>
						<div style="display: inline-block;"
								 class="text-center">Category

						</div>

					</div>
					<div class="col gx-0">


					</div>
					<div class="col-auto gx-0">
						<div :class="{ active: app.newProject.step > 2 }"
								 class="step"
								 @click="app.newProject.step > 2 ? setStep(2) : ''"
								 :disabled="app.newProject.step < 2">

							<svg width="44"
									 height="44"
									 viewBox="-2 -2 44 44"
									 xmlns="http://www.w3.org/2000/svg"
									 :class="{ 'current-step': app.newProject.step == 2, 'future-step': app.newProject.step < 2, 'completed-step': app.newProject.step > 2, }">
								<circle cx="20"
												cy="20"
												r="20" />
								<path
											d="M14.9579 25.5578C15.9179 24.8112 16.7446 24.1512 17.4379 23.5778C18.1312 23.0045 18.7179 22.4912 19.1979 22.0378C19.6779 21.5712 20.0579 21.1512 20.3379 20.7778C20.6312 20.3912 20.8379 20.0378 20.9579 19.7178C21.0779 19.3845 21.1379 19.0578 21.1379 18.7378C21.1379 18.3245 21.0512 17.9778 20.8779 17.6978C20.7179 17.4178 20.4779 17.2045 20.1579 17.0578C19.8379 16.8978 19.4379 16.8178 18.9579 16.8178C18.4912 16.8178 17.9979 16.8912 17.4779 17.0378C16.9579 17.1845 16.4246 17.4045 15.8779 17.6978L14.8579 14.9378C15.3112 14.6445 15.8046 14.3978 16.3379 14.1978C16.8712 13.9978 17.4246 13.8445 17.9979 13.7378C18.5846 13.6312 19.1646 13.5778 19.7379 13.5778C20.7912 13.5778 21.6779 13.7578 22.3979 14.1178C23.1312 14.4778 23.6912 14.9845 24.0779 15.6378C24.4646 16.2912 24.6579 17.0512 24.6579 17.9178C24.6579 18.3578 24.6179 18.7712 24.5379 19.1578C24.4579 19.5445 24.3179 19.9378 24.1179 20.3378C23.9179 20.7378 23.6379 21.1645 23.2779 21.6178C22.9179 22.0712 22.4446 22.5845 21.8579 23.1578C21.2846 23.7312 20.5846 24.3845 19.7579 25.1178H25.6579V27.7778H14.9979L14.9579 25.5578Z" />



							</svg>


						</div>
						<div style="display: inline-block;"
								 class="text-center">Template

						</div>

					</div>
					<div class="col gx-0">


					</div>
					<div class="col-auto gx-0">
						<div :class="{ active: app.newProject.step == 3 }"
								 class="step">

							<svg width="44"
									 height="44"
									 viewBox="-2 -2 44 44"
									 xmlns="http://www.w3.org/2000/svg"
									 :class="{ 'current-step': app.newProject.step == 3, 'future-step': app.newProject.step < 3, 'completed-step': app.newProject.step > 3, }">
								<circle cx="20"
												cy="20"
												r="20" />
								<path
											d="M14.4779 26.8978L15.3579 24.4978C15.7312 24.6578 16.1246 24.7912 16.5379 24.8978C16.9512 25.0045 17.3846 25.0912 17.8379 25.1578C18.3046 25.2112 18.7846 25.2378 19.2779 25.2378C19.9446 25.2378 20.4846 25.1778 20.8979 25.0578C21.3246 24.9245 21.6379 24.7245 21.8379 24.4578C22.0512 24.1778 22.1579 23.8378 22.1579 23.4378C22.1579 22.9045 21.9246 22.5112 21.4579 22.2578C20.9912 22.0045 20.2846 21.8778 19.3379 21.8778H17.2379V19.4778H19.3779C19.9379 19.4778 20.3979 19.4178 20.7579 19.2978C21.1179 19.1778 21.3779 19.0045 21.5379 18.7778C21.7112 18.5512 21.7979 18.2778 21.7979 17.9578C21.7979 17.4778 21.5712 17.1112 21.1179 16.8578C20.6779 16.5912 20.0112 16.4578 19.1179 16.4578C18.5312 16.4578 17.9312 16.5112 17.3179 16.6178C16.7179 16.7112 16.1379 16.8778 15.5779 17.1178L14.7979 14.6178C15.1979 14.4045 15.6512 14.2178 16.1579 14.0578C16.6779 13.8978 17.2379 13.7778 17.8379 13.6978C18.4512 13.6178 19.0912 13.5778 19.7579 13.5778C20.9046 13.5778 21.8712 13.7245 22.6579 14.0178C23.4446 14.3112 24.0446 14.7312 24.4579 15.2778C24.8712 15.8112 25.0779 16.4645 25.0779 17.2378C25.0779 17.9445 24.8912 18.5712 24.5179 19.1178C24.1446 19.6645 23.6112 20.0845 22.9179 20.3778C23.7712 20.6312 24.4112 21.0445 24.8379 21.6178C25.2779 22.1778 25.4979 22.8578 25.4979 23.6578C25.4979 24.5778 25.2646 25.3578 24.7979 25.9978C24.3446 26.6378 23.6779 27.1312 22.7979 27.4778C21.9179 27.8112 20.8379 27.9778 19.5579 27.9778C18.8646 27.9778 18.2246 27.9378 17.6379 27.8578C17.0512 27.7912 16.5046 27.6778 15.9979 27.5178C15.5046 27.3578 14.9979 27.1512 14.4779 26.8978Z" />

							</svg>



						</div>

						<div style="display: inline-block;"
								 class="text-center">Let's Go!

						</div>

					</div>

				</div>



			</div>
			<div class="new-project-content mx-auto">
				<Transition name="slide-fade"
										mode="out-in">

					<div v-if="app.newProject.step == 1"
							 class="category-wrapper mx-auto">


						<div class="row justify-content-center">
							<div v-for="category in app.categories.filter((category) => { if (category.template_count > 0 && category.name != app.settings.scratch_category) { return category } })"
									 class="col-auto mb-4 sw-width"
									 :key="category.name">
								<div class="card category-card border-secondary"
										 :id="category.name"
										 @click="chooseCategory(category)">
									<div class="container h-100">
										<div class="row justify-content-center">
											<div class="col-auto">


												<div class="category-icon-wrapper">
													<img class="category-icon"
															 :src="app.staticHostUrl + category.category_icon" />

												</div>




											</div>

										</div>
										<div class="category-name-wrapper text-center">


											<span class="category-name">{{ category.category_name }}</span>


										</div>

									</div>

								</div>

							</div>

						</div>
						<div class="row justify-content-end pe-5">
							<div class="col-auto">

								<div role="button"
										 @click="startFromScratch()"
										 v-if="app.newProject.step == 1"
										 class="text-primary sw-btn">Or start from scratch
									<font-awesome-icon icon="fa-solid fa-arrow-circle-right"></font-awesome-icon>

								</div>

							</div>

						</div>


					</div>
					<div v-else-if="app.newProject.step == 2"
							 class="template-wrapper mx-auto">

						<div class="row justify-content-center">
							<div v-for="template in app.newProject.category.templates"
									 class="col-auto mb-4 sw-width"
									 :key="template.name">
								<div class="card template-card border-secondary"
										 :id="template.name"
										 @click="chooseTemplate(template)">


									<div class="template-icon-wrapper">
										<img v-if="template.preview_image"
												 class="img-fluid"
												 :src="app.staticHostUrl + template.preview_image" />

									</div>




								</div>
								<div class="mx-auto text-center no-select">{{ template.template_name }}

								</div>

							</div>

						</div>
						<div class="row justify-content-start ps-5">
							<div class="col-auto">



								<div role="button"
										 class="sw-btn"
										 @click="stepBack()">
									<font-awesome-icon icon="fa-solid fa-arrow-circle-left"></font-awesome-icon>
									<span class="ms-1">Back

									</span>

								</div>


							</div>

						</div>


					</div>
					<div v-else-if="app.newProject.step == 3"
							 class="">
						<div class="row justify-content-center">


							<div class="col-auto text-center">
								<div class="form-floating mb-3"
										 style="width:470px;">
									<input type="text"
												 class="form-control px-4"
												 id="project-name"
												 placeholder="Project Name"
												 v-model="app.newProject.projectName"
												 required>
									<label for="project-name">Now give your project a name</label>

								</div>
								<button :disabled="app.newProject.projectName != '' ? false : true"
												@mousedown="app.newProject.projectName ? createProject() : ''"
												class="btn btn-primary">Let's Go!


								</button>

							</div>

						</div>

						<div class="row justify-content-start ps-5">
							<div class="col-auto">



								<div role="button"
										 class="sw-btn"
										 @click="stepBack()">
									<font-awesome-icon icon="fa-solid fa-arrow-circle-left"></font-awesome-icon>
									<span class="ms-1">Back

									</span>

								</div>


							</div>

						</div>

					</div>
				</Transition>




			</div>

		</div>

	</div>
</template>

<script setup lang="ts">
import { serverApi } from "@/composables/frappe";
import type { StreamWorkCategory, StreamWorkTemplate } from "@/types/docTypes";
import type { Category, NewProjectStep } from "@/types/localTypes";
import { onUnmounted, watch } from "vue"
import { useRouter } from "vue-router"
import { useStore, useModal } from "../stores/stores"


const fileUrl = import.meta.env.VITE_STATIC_HOST_URL
const router = useRouter()
const app = useStore()
const modal = useModal()

onUnmounted(() => {
	app.newProject.projectName = ''
	app.newProject.step = 1
})


function setStep(step: NewProjectStep) {
	app.newProject.fromScratch = false
	app.newProject.step = step
	if (step == 1) {
		app.newProject.progress = 18
	} else {
		app.newProject.progress = (step - 1) * 50 - 18
	}

}

async function createProject() {

	app.isProjectCreating = true
	const response = await serverApi.createProject(app.newProject.projectName, app.customerAccount.name, app.newProject.template.name, app.newProject.fromScratch)
	if (response.message.status == 'success') {
		app.isProjectCreating = false
		await app.loadSessionData()
		router.push('/edit/' + response.message.project)

	}

	app.isProjectCreating = false

}

function stepBack() {
	app.newProject.fromScratch = false
	app.newProject.step--;
	app.newProject.progress -= 50 - 18
}

function chooseCategory(category: StreamWorkCategory) {
	console.info(category)
	app.newProject.category = category
	app.newProject.step += 1
	app.newProject.progress = 50
	console.info(app.newProject)

}

function chooseTemplate(template: StreamWorkTemplate) {
	app.newProject.template = template
	app.newProject.step += 1
	app.newProject.progress = 85
	console.info(app.newProject)

}
function startFromScratch() {
	let scratch_category = app.categories.filter((cat) => {
		if (cat.name == app.settings.scratch_category) {
			return cat
		}
	})
	if (scratch_category.length > 0) {
		if (scratch_category[0].template_count > 0) {
			app.newProject.category = scratch_category[0]
			app.newProject.step += 1
			app.newProject.progress = 85
			return
		}
	}
	app.newProject.step = 3
	app.newProject.progress = 85
	app.newProject.fromScratch = true
}

watch(modal, () => {
	if (!modal.modalShown) {
		app.newProject.step = 1
	}
})

</script>

<style lang="scss" scoped>
.new-project-title {
	font-size: 3rem;
	font-weight: 300;
}

.category-wrapper,
.template-wrapper {
	max-width: 1000px;

}

.category-icon-wrapper {
	height: 65px;
	width: fit-content;
}

.category-icon {
	height: 55px;
	width: fit-content;
	margin: 10px 0 0 0;
}

.category-name {
	line-height: 1.5;
	font-size: 18px;
	color: #524E61;
	display: inline-block;
	vertical-align: middle;
}

.category-name-wrapper {
	line-height: 65px;
}

.category-card {
	height: 130px;
	width: 130px;
	font-size: 18px;
	transition: all 0.2s ease-out;
}




.step {
	color: var(--bs-secondary)
}

.step.active {
	font-weight: 700 !important;
	cursor: pointer;
}

.template {
	height: 440px;
	background-size: cover;
	background-repeat: no-repeat;

}

.template-card {
	height: 195px;
	width: 150px;
	font-size: 18px;
	transition: all 0.2s ease-out;
}

.template-icon-wrapper {
	overflow: hidden;
	margin: 1rem;
}

.template-card,
.category-card {
	box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.12);
}

.template-card:hover,
.category-card:hover {
	cursor: pointer;
	transform: scale(1.05);
	box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.4);

}

.template-card:active,
.template-card:focus,
.category-card:active,
.category-card:focus {
	border: 2px solid var(--bs-primary) !important;

}

.img-thumbnail:hover {
	box-shadow: 0.1rem 0.2rem 0.3rem rgb(0 0 0 / 8%);
	transition: all 0.1s ease-in-out;
}

@media only screen and (min-width: 992px) {
	.project-name-card {
		position: absolute;
		top: 30%;
	}

}

.new-project-container {
	// position: absolute;
	width: 100vw;
	// height: calc(100vh - var(--header-height));
	margin-top: var(--header-height);
	// top: 0;
	// left: 0;
	background-color: var(--bs-body-bg);
	// padding-top: 10vh;
	overflow: hidden;
}

@media only screen and (max-width: 992px) {
	.new-project-content {
		width: 90%;

	}
}

@media only screen and (min-width: 992px) {
	.new-project-content {
		width: 900px;

	}
}

circle {
	transition: all 0.3s ease;
}

path {
	transition: all 0.3s ease;
}

.future-step {
	circle {
		fill: var(--bs-body-bg);
		stroke: var(--bs-gray-500);
		stroke-width: 2;
	}

	path {
		fill: var(--bs-gray-500);
	}

}

.current-step {
	circle {
		fill: var(--bs-body-bg);
		stroke: var(--bs-primary);
		stroke-width: 2;
	}

	path {
		fill: var(--bs-primary);
	}

}

.completed-step {
	circle {
		fill: var(--bs-primary);
		stroke: var(--bs-primary);
		stroke-width: 2;
	}

	path {
		fill: white;
	}

}

.progress-container {
	width: 400px;
}

.progress-line {
	margin-top: 22px;
	position: absolute;
	width: 90%;
	top: 0;
	left: 5%;
	z-index: 1;
	//border-top: 1px solid var(--bs-primary);

}

.progress-line.complete {
	border-top: 3px solid var(--bs-primary);
}

.sw-btn {
	transition: all 0.2s ease-out;
}

.sw-btn:hover {
	transform: scale(1.05);

}
</style>