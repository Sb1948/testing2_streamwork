<template>
	<div class="container-md view">
		<div class="project-wrapper pt-5"
				 :style="{
				 	backgroundColor: theme.colorPalette.background
				 }">
			<StreamBoard></StreamBoard>

		</div>


	</div>
</template>

<script setup lang="ts">
import { useTheme } from "@/stores/theme";
import { onMounted } from "vue";
import StreamBoard from "../components/streamboard/StreamBoard.vue";
const theme = useTheme()

onMounted(() => {

})
</script>

<style lang="scss">
.view {

	.project-wrapper {
		background-color: transparent;


		position: relative;

	}

	.step-button {
		display: none;
	}

	.step-master .step-row-container {
		border: none !important;
	}


}

.main-container {
	overflow-y: scroll !important;
	height: calc(100vh - var(--header-height)) !important;

}
</style>