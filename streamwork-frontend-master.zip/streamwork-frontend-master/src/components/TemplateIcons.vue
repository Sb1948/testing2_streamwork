<template>

	<div class="card-body">
		<div class="row justify-content-center">
			<div class="col-auto mb-2 icon-box"
					 v-for="icon in app.activeProject.icons"
					 :key="icon.name">
				<div class="icon-wrapper img-thumbnail d-flex align-items-center"
						 :style="'background-image:url(\'' + app.staticHostUrl + icon.icon + '\')'">
					<div class="overlay-img d-flex align-items-center">

						<div class="btn-circle bg-danger mx-auto"
								 @click="app.deleteTemplateIcon(icon)">
							<font-awesome-icon icon="fa-solid fa-trash"></font-awesome-icon>

						</div>

					</div>

				</div>

			</div>

		</div>

	</div>



</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
const app = useStore()
const props = defineProps(['isCover', 'isFooter'])
</script>
<style lang="scss" scoped>
.icon-wrapper {
	width: 100px;
	max-height: 100px;
	background-repeat: no-repeat;
	background-size: contain;
	background-position: 50%;
	transition: all 0.2s ease;


}

.overlay-img {
	width: 100%;
	height: 100%;
	background-color: rgba(255, 255, 255, 0.665);
	opacity: 0;
	transition: all 0.2s ease;
}

.icon-wrapper.img-thumbnail {
	height: 100px;
}

.icon-box {
	transition: all 0.2s ease;
}

.btn-circle {}

.icon-box:hover {
	transform: scale(1.2);
	cursor: pointer;

	.img-thumbnail {}

	.overlay-img {
		opacity: 1;
	}

	.btn-circle {}
}
</style>