<template>
  <div class="card">
    <div class="card-body">
      <div class="d-flex flex-column">
        <h6 class="mb-3 text-sm">{{ address?.address_title }}</h6>
      <span v-if="address?.company" class="text-dark font-weight-bold ms-sm-2">{{ address?.company }}</span>
        <span class="text-dark ms-sm-2 font-weight-bold">{{ address?.address_line1 }}</span>
        <span class="text-dark ms-sm-2 font-weight-bold">{{ address?.city }}{{ address?.state ? ', ' + address?.state : '' }}</span>
        <span
          class="text-dark ms-sm-2 font-weight-bold">{{ address?.country }}{{ address?.pincode ? ', ' + address?.pincode : '' }}</span>

      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { usePayment, useStore } from '@/stores/stores';

import { ref } from 'vue';

const app = useStore()
const payment = usePayment()
const address = ref(app.customerAccount?.billing_address)
</script>

<style scoped>
</style>