<template>
    <div class="row">

        <div class="col-md-6">


            <div class="card wrapper card-shadow bg-white mt-sm-5">
                <h4 class="pb-4 border-bottom">Account settings</h4>
                <div class="d-flex align-items-start py-3 border-bottom">
                    <div class="profile-image border-radius"
                        :style="{ backgroundImage: 'url(' + [profile_image] + ')' }">



                    </div>

                    <div class="pl-sm-4 pl-2" id="img-section">
                        <b>Profile Photo</b>
                        <p>Accepted file type .png. Less than 1MB</p>
                        <button @click="upload()" class="btn button border"><b>Upload</b></button>

                    </div>

                </div>
                <div class="py-2 personal-info">
                    <div class="row py-2">
                        <div class="col-md-6">
                            <label class="border-bottom" for="firstname">First Name</label>
                            <input type="text" class="profile-input form-control" :value="customer.first_name" disabled>

                        </div>
                        <div class="col-md-6 pt-md-0 pt-3">
                            <label class="border-bottom" for="lastname">Last Name</label>
                            <input type="text" class="profile-input form-control" :value="customer.last_name" disabled>

                        </div>

                    </div>
                    <div class="row py-2">
                        <div class="col-md-6">
                            <label class="border-bottom" for="email">Email Address</label>
                            <input type="text" class="profile-input form-control" :value="customer.email" disabled>

                        </div>
                        <div class="col-md-6">
                            <button class="sw-btn small border-radius">Edit Info</button>

                        </div>

                    </div>


                </div>


            </div>

        </div>
        <div class="col-md-5">

            <div class="card wrapper card-shadow bg-white mt-sm-5">
                <h4 class="pb-4 border-bottom">Billing Information</h4>
                <div class="d-flex align-items-start py-3 border-bottom">
                    <div class="card-body">
                        <spinner v-if="payment_loading" />
                        <transition-group name="list">
                            <div v-for="item in payment_methods" class="item" :key="item.creditCard.cardLastFourDigits">

                                <payment-method :card-data="item" :first_name="vaulted_shopper.firstName" :last_name="vaulted_shopper.lastName"></payment-method>

                            </div>
                        </transition-group>

                    </div>

                </div>


            </div>

        </div>

    </div>
</template>

<script>
import PaymentMethod from '../components/PaymentMethod.vue'
export default {
    components: { PaymentMethod },

    data() {
        return {
            customer: {},
            page_name: 'account',

            profile_image: frappe.user_image,
            vaulted_shopper: {},
            payment_methods: [],
            payment_loading: true
        }
    },
    created() {
        // refreshed

        this.get_vaulted_shopper()

        //    this.get_customer_data()
    },
    methods: {
        get_vaulted_shopper() {
            frappe.call({
                method: 'streamwork.customer.get_vaulted_shopper',
            }).then((result) => {

                this.vaulted_shopper = result.message.vaulted_shopper
                this.customer = result.message.customer
                frappe.streamwork.customer.vaulted_shopper = this.vaulted_shopper
                this.payment_methods = this.vaulted_shopper.paymentSources.creditCardInfo
                this.payment_loading = false
                frappe.streamwork.vault_updated = true
            });
        },
        upload() {
            new frappe.ui.FileUploader();
        }
    },
}
</script>

<style>
.profile-image {
    width: 250px;
    height: 250px;
    background-size: cover;
    background-repeat: no-repeat;
}

.profile-input:disabled {
    background-color: transparent;
    border: none;
}

/* imported card */
.wrapper {
    padding: 30px 50px;
    border: 1px solid #ddd;
    border-radius: var(--border-radius);
    margin: 10px auto;
    max-width: 600px;
}

h4 {
    letter-spacing: -1px;
    font-weight: 400;
}

.img {
    width: 70px;
    height: 70px;
    border-radius: 6px;
    object-fit: cover;
}

#img-section p,
#deactivate p {
    font-size: 12px;
    color: #777;
    margin-bottom: 10px;
    text-align: justify;
}

#img-section b,
#img-section button,
#deactivate b {
    font-size: 14px;
}

label {
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 500;
    color: #777;
    padding-left: 3px;
}



input[placeholder] {
    font-weight: 500;
}




@media(max-width:576px) {
    .wrapper {
        padding: 25px 20px;
    }

    #deactivate {
        line-height: 18px;
    }
}

/* end imported card */

/* transition */
.list-item {
    display: inline-block;
    margin-right: 10px;
}

.list-enter-active,
.list-leave-active {
    transition: all 1s;
}

.list-enter,
.list-leave-to

/* .list-leave-active below version 2.1.8 */
    {
    opacity: 0;
    transform: translateY(30px);
}
</style>