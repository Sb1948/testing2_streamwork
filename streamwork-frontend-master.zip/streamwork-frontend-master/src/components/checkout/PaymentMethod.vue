<template>
  <div class="container-fluid">
    <transition name="fade" mode="out-in">
      <div v-if="!edit" class="col-auto mb-xl-0 mb-4" :key="'card'">
        <div class="card cc-card bg-transparent shadow-xl">
          <i @click="toggle_edit()" id="edit-card" class="fas fa-pencil-alt ms-auto text-white cursor-pointer fa-2x"
            data-bs-toggle="tooltip" data-bs-placement="top" title="" aria-hidden="true"
            data-bs-original-title="Edit Card" aria-label="Edit Card"></i>
          <span class="sr-only">Edit Card</span>
          <div class="overflow-hidden position-relative rounded cc-bg">
            <span class="mask bg-gradient-dark"></span>
            <div class="card-body position-relative z-index-1 p-3">
              <font-awesome-icon icon="fa-solid fa-wifi" class="text-white"></font-awesome-icon>
            
              <h5 class="text-white mt-4 mb-5 pb-2">
                ****&nbsp;&nbsp;&nbsp;****&nbsp;&nbsp;&nbsp;****&nbsp;&nbsp;&nbsp;{{ cardInfo?.cardLastFourDigits }}
              </h5>
              <div class="d-flex">
                <div class="d-flex">
                  <div class="me-4">
                  

                  </div>
                  <div>
                    <p class="text-white text-sm opacity-8 mb-0">Expires</p>
                    <h6 class="text-white mb-0">
                      {{ cardInfo?.expirationMonth }}/{{ cardInfo?.expirationYear }}
                    </h6>

                  </div>

                </div>
                <div class="ms-auto w-20 d-flex align-items-end justify-content-end">
                 
                  <div class="cc-img" :class="cardInfo?.cardType.toLowerCase()">

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>
      <div v-else class="col-auto mb-xl-0 mb-4" :key="'edit'">
        <div class="card cc-card bg-transparent shadow-xl">
          <i @click="toggle_edit()" id="edit-card" class="fas fa-pencil-alt ms-auto text-white cursor-pointer fa-2x"
            data-bs-toggle="tooltip" data-bs-placement="top" title="" aria-hidden="true"
            data-bs-original-title="Edit Card" aria-label="Edit Card"></i>
          <span class="sr-only">Edit Card</span>
          <div class="overflow-hidden cc-card position-relative border-radius"
            style="background-image: url('@/assets/img/curved14.jpg');">
            <span class="mask bg-gradient-dark"></span>
            <div class="card-body position-relative z-index-1 p-3">
              <div class="row">
                <div class="col-md-6">
                  <label class="form-label text-white">First Name</label>
                  <input type="text" class="form-control" :value="cardData.billingContactInfo.firstName">

                </div>
                <div class="col-md-6">
                  <label class="form-label text-white">Last Name</label>
                  <input type="text" class="form-control" :value="cardData.billingContactInfo.lastName">

                </div>


              </div>
              <div class="row">
                <div class="col">
                  <select class="form-control">
                    <option value="1">01</option>
                    <option value="2">02</option>
                    <option value="3">03</option>
                    <option value="4">04</option>
                    <option value="5">05</option>
                    <option value="6">06</option>
                    <option value="7">07</option>
                    <option value="8">08</option>
                    <option value="9">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>

                  </select>

                </div>
                <div class="col">

                </div>

              </div>



            </div>

          </div>

        </div>

      </div>
    </transition>

  </div>

</template>

<script lang="ts" setup>
import { usePayment, useStore } from '@/stores/stores'
import { onMounted, ref, watch } from 'vue'

const app = useStore()
const payment = usePayment()
const edit = ref(false)
const cardInfo = ref(app.vaultedShopper?.paymentSources?.creditCardInfo? app.vaultedShopper?.paymentSources?.creditCardInfo[0].creditCard : null )
onMounted(() => {

})
watch(() => app.vaultedShopper, shopper => {
  console.info(shopper)
})
</script>

<style lang="scss" scoped>
#edit-card {
  position: absolute;
  top: 5px;
  right: 10px;
  z-index: 100;
  color: white;

}

.cc-card {
  width:100%;
  min-height: 212px;
}

.mask {
  position: absolute;
  background-size: cover;
  background-position: 50%;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: .8;
}

.bg-gradient-dark {
  background-image: linear-gradient(310deg, #141727, #3a416f);
}

.w-20 {
  width: 20% !important;
}

.w-60 {
  width: 60% !important;
}

.cc-bg{
  background-image: url('@/assets/img/curved14.jpg');
}
.cc-img {
  width: 100%;
  height: 100%;
  background-size: 56px 38px;
  background-clip: padding-box;
  background-repeat: no-repeat;
  background-position: left;
}
.amex {
  background-image: url('@/assets/img/amex.png');
}

.visa {
  background-image: url('@/assets/img/9018c4f-Visa.png');

}

.mastercard {
  background-image: url('@/assets/img/5b7b3de-Mastercard.png')
}

.discover {
  background-image: url('@/assets/img/caea86d-Discover.png')
}

.diners {
  background-image: url('@/assets/img/8c73810-Diners_Club.png');

}

.jcb {
  background-image: url('@/assets/img/e076aed-JCB.png');

}
</style>