<template>
    <div v-if="app.showFooter" class="footer sticky-bottom bg-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0"><small>Copyright Streamwork 2022 </small></p>

                </div>
                <div class="col-md-6 text-start text-sm-end mt-4 mt-sm-0">
                    <p class="mb-0"><small> <a class="me-4" href="mailto:info@streamwork.io">Contact us </a> <a
                                class="hide" href="#!"> legal/privacy policy </a> </small></p>

                </div>

            </div>

        </div>

    </div>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';

const app= useStore()
</script>

<style scoped>

</style>