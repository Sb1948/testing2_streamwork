
<script setup lang="ts">
import { serverApi } from "@/composables/frappe";
import { onMounted, ref, watch } from "vue"
import { useStore, useLoginForm } from "../stores/stores"
import Loader from "./Loader.vue"

const app = useStore()
const formState = useLoginForm()
const googleLogin = ref({})

watch(formState.$state, () => {
  console.info('statechange')
  if (formState.wasValidated) {
    console.info('statechangevalidated')
    if (formState.formView == 'login') {
      formState.validateLogin()
    } else if (formState.formView == 'register') {
      formState.validateRegistration()
    }

  }
})

onMounted(() => {
  formState.getGoogleLogin()
})
function login() {
  formState.loading = true
  app.login()
}
function register() {
  formState.loading = true
  app.register()
}

</script>
<template>
  <div class="container-lg">
    <Transition name="fade" mode="out-in">
      <div v-if="formState.formView == 'loggingIn' || formState.formView == 'registering'"
        class="row justify-content-center align-items-center" style="height:80vh;">
        <div class="col">
          <div class="row mb-2">
            <Loader></Loader>

          </div>
          <div class="row justify-content-center">
            <div class="col-auto">
              <h5>
                {{ formState.formView == 'loggingIn' ? "We're loading your account" : "We're creating your new account!" }}
              </h5>

            </div>


          </div>

        </div>



      </div>
      <div v-else class="card login-card mx-auto">



        <div class="row h-100 px-4 py-3">
          <div class="col-md-4 py-5">
            <div class="row ps-5 mb-4">
              <div class="col-md-12">
                <img src="@/assets/img/logo-green.svg?url" />

              </div>

            </div>
            <div class="row ps-5 mb-5">
              <div class="col-md-12">
                <span class="text-muted">Simplifying per-project workflow for creatives and clients
                  alike</span>

              </div>

            </div>
            <div class="row my-5">
              <div class="col-md-12">
                <img class="login-img img-fluid my-5" src="@/assets/img/login-img.svg?url" />

              </div>

            </div>

          </div>
          <div class="col-md-8 bg-light">







            <div class="row justify-content-center">
              <div class="col-md-8 text-center mb-3 mt-5">
                <Transition name="fade" mode="out-in">
                  <h2 v-if="formState.formView == 'login'" :key="'login'">Welcome back!</h2>
                  <h2 v-else-if="formState.formView == 'register'" :key="'register'">Create your
                    free
                    account:</h2>

                </Transition>

              </div>

            </div>

            <div class="row justify-content-center">
              <div class="col-auto mb-4">
                <Transition name="fade" mode="out-in">
                  <div v-if="formState.formView == 'login'" class="text-muted" :key="'login'">
                    Don't
                    have
                    an account? <span class="text-primary fw-bold pointer"
                      @click="formState.change_state('register')">Sign up</span>

                  </div>
                  <div v-else-if="formState.formView == 'register'" class="text-muted" :key="'register'">
                    Already a member?
                    <span class="text-primary fw-bold pointer" @click="formState.change_state('login')">Log
                      in</span>

                  </div>
                </Transition>


              </div>

            </div>

            <div class="row justify-content-center">
              <div class="col-lg-7 col-md-8 col-sm-9 col-10">
                <Transition name="slide-fade" mode="out-in">


                  <form v-if="formState.formView == 'login'" class="login-form">
                    <div class=" form-floating mb-3 has-validation">
                      <input :class="formState.email.validClass" type="text" class="form-control form-control-lg px-4"
                        id="email" placeholder="email" v-model="formState.email.value"
                        :required="formState.email.rules.required" :disabled="formState.loading">
                      <label class="login-label" for="email">Email</label>
                      <div class="invalid-feedback">
                        {{ formState.email.errorMessage }}

                      </div>

                    </div>

                    <div class="form-floating mb-3 has-validation">
                      <input :class="formState.password.validClass" type="password"
                        class="form-control form-control-lg px-4" id="password" placeholder="password"
                        v-model="formState.password.value" :required="formState.password.rules.required"
                        :disabled="formState.loading">
                      <label class="login-label" for="password">password</label>
                      <div class="invalid-feedback">
                        {{ formState.password.errorMessage }}

                      </div>

                    </div>

                    <div class="d-grid gap-2">
                      <button type="submit" class="btn btn-primary btn-lg text-white" @click.prevent="login()"
                        :disabled="formState.loading">
                        <Transition name="fade" mode="out-in">

                          <div v-if="formState.loading">


                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            <span class="ms-2">Logging In...</span>

                          </div>
                          <span v-else>Log In</span>
                        </Transition>
                      </button>
                      <div class="mx-auto">
                        or

                      </div>
                      <a :href="formState.googleLogin.auth_url" class="btn btn-lg btn-light text-dark">
                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 18 18"
                          aria-hidden="true">
                          <title>Google</title>
                          <g fill="none" fill-rule="evenodd">
                            <path fill="#4285F4"
                              d="M17.64 9.2045c0-.6381-.0573-1.2518-.1636-1.8409H9v3.4814h4.8436c-.2086 1.125-.8427 2.0782-1.7959 2.7164v2.2581h2.9087c1.7018-1.5668 2.6836-3.874 2.6836-6.615z">
                            </path>
                            <path fill="#34A853"
                              d="M9 18c2.43 0 4.4673-.806 5.9564-2.1805l-2.9087-2.2581c-.8059.54-1.8368.859-3.0477.859-2.344 0-4.3282-1.5831-5.036-3.7104H.9574v2.3318C2.4382 15.9832 5.4818 18 9 18z">
                            </path>
                            <path fill="#FBBC05"
                              d="M3.964 10.71c-.18-.54-.2822-1.1168-.2822-1.71s.1023-1.17.2823-1.71V4.9582H.9573A8.9965 8.9965 0 0 0 0 9c0 1.4523.3477 2.8268.9573 4.0418L3.964 10.71z">
                            </path>
                            <path fill="#EA4335"
                              d="M9 3.5795c1.3214 0 2.5077.4541 3.4405 1.346l2.5813-2.5814C13.4632.8918 11.426 0 9 0 5.4818 0 2.4382 2.0168.9573 4.9582L3.964 7.29C4.6718 5.1627 6.6559 3.5795 9 3.5795z">
                            </path>
                          </g>
                        </svg>
                        <span class="ms-2">Login with Google</span>

                      </a>

                    </div>

                  </form>
                  <form v-else-if="formState.formView == 'register'" class="login-form">
                    <div class="form-floating mb-3 has-validation">
                      <input :class="formState.first_name.validClass" type="text"
                        class="form-control form-control-lg px-4" id="first-name" placeholder="First Name"
                        v-model="formState.first_name.value" :required="formState.first_name.rules.required"
                        :disabled="formState.loading">
                      <label class="login-label" for="last-name">First Name</label>
                      <div class="invalid-feedback">
                        {{ formState.first_name.errorMessage }}

                      </div>

                    </div>
                    <div class="form-floating mb-3 has-validation">
                      <input :class="formState.last_name.validClass" type="text"
                        class="form-control form-control-lg px-4" id="last-name" placeholder="Last Name"
                        v-model="formState.last_name.value" :required="formState.last_name.rules.required"
                        :disabled="formState.loading">
                      <label class="login-label" for="last-name">Last Name</label>
                      <div class="invalid-feedback">
                        {{ formState.last_name.errorMessage }}

                      </div>

                    </div>

                    <div class="form-floating mb-3 has-validation">
                      <input :class="formState.email.validClass" type="text" class="form-control form-control-lg px-4"
                        id="email" placeholder="email" v-model="formState.email.value"
                        :required="formState.email.rules.required" :disabled="formState.loading">
                      <label class="login-label" for="email">Email</label>
                      <div class="invalid-feedback">
                        {{ formState.email.errorMessage }}

                      </div>

                    </div>
                    <div class="form-floating mb-3 has-validation">
                      <input :class="formState.password.validClass" type="password"
                        class="form-control form-control-lg px-4" id="password" placeholder="password"
                        v-model="formState.password.value" :required="formState.password.rules.required"
                        :disabled="formState.loading">
                      <label class="login-label" for="password">password</label>
                      <div class="invalid-feedback">
                        {{ formState.password.errorMessage }}

                      </div>

                    </div>

                    <div class="form-floating mb-3 has-validation">
                      <input :class="formState.confirmPassword.validClass" type="password"
                        class="form-control form-control-lg px-4" id="confirm-password" placeholder="Confirm Password"
                        v-model="formState.confirmPassword.value" :disabled="formState.loading">
                      <label class="login-label" for="confirm-password">Confirm Password</label>
                      <div id="confirm-passwordFeedback" class="invalid-feedback">
                        {{ formState.confirmPassword.errorMessage }}

                      </div>

                    </div>
                    <div class="d-grid gap-2">

                      <button type="submit" class="btn btn-primary btn-lg text-white" @click.prevent="register()"
                        :disabled="formState.loading">
                        <Transition name="fade" mode="out-in">

                          <div v-if="formState.loading">


                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            <span class="ms-2">Registering...</span>

                          </div>
                          <span v-else>Register</span>
                        </Transition>
                      </button>

                    </div>
                  </form>


                </Transition>
                <Transition name="pop">
                  <div v-if="formState.error.hasError" class="row justify-content-center p-0">
                    <div class="col-auto p-0">



                      <small class="text-danger">{{ formState.error.message }}</small>


                    </div>

                  </div>
                </Transition>

              </div>

            </div>



          </div>

        </div>

      </div>
    </Transition>

  </div>
</template>

<style lang="scss" scoped>
.login-card {
  max-width: 996px;
  height: 688px;
  margin-top: calc(((100vh - 688px)/2)/2)
}

.invalid-feedback {
  position: absolute;
  top: 0;
  text-align: center;
  font-size: small;
}

@media only screen and (min-width: 996px) {
  .login-img {
    transform: scale(1.2) translateX(3rem)
  }
}
</style>