<template>
	<Popper class="popper-sw"
					:arrow="true"
					placement="top"
					:hover="true"
					:content="tipContent">
		<div class="btn-square"
				 :class="customClasses"
				 @click="emit('btnClick')">
			<slot></slot>

		</div>
	</Popper>
</template>

<script setup lang="ts">
import Popper from "vue3-popper"
defineProps(['tipContent', 'customClasses'])
const emit = defineEmits(['btnClick'])
</script>
<style>
.popper-sw {
	--popper-theme-background-color: white;
	--popper-theme-background-color-hover: white;
	--popper-theme-padding: 5px 12px;
	--popper-theme-border-radius: var(--bs-border-radius);
	--popper-theme-box-shadow: var(--elv-4-shadow);
}
</style>
<style lang="scss" scoped>
.btn-square {
	z-index: 99;
}

.tip {
	position: absolute;
	bottom: 40px;
	z-index: 100;
	background-color: white;

}

.tip::after {
	color: white;
	content: '\25B21';
	box-shadow: var(--elv-4-shadow);

}
</style>