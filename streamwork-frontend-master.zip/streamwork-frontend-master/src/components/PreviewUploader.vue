<template>


	<file-pond class="border rounded"
						 :instantUpload="true"
						 :name="props.name"
						 ref="pond"
						 :allowReplace="props.allowReplace"
						 :allow-multiple="allowMultiple || false"
						 :server="server"
						 :accepted-file-types="props.acceptedFileTypes"
						 labelIdle='Drop Files Here<br /> or <span>Browse your Computer</span>'
						 :stylePanelLayout="'integrated'"
						 imagePreviewHeight="200px"
						 @init="handleFilePondInit"
						 @initfile="handleLoaded"
						 @processfiles="handleProcessFiles"
						 key="preview" />

</template>
<script lang="ts" setup>
import { useFileUploader } from '@/stores/stores';
import vueFilePond from 'vue-filepond'

// Import plugins
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type'
import FilePondPluginImagePreview from 'filepond-plugin-image-preview'

// Import styles
import 'filepond/dist/filepond.min.css'
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css'
import { serverApi } from '@/composables/frappe'
import type { FilePondBaseProps, FilePondFile, FilePondOptions } from 'filepond';
import { ref } from 'vue';
import type { FrappeFile } from '@/types/docTypes';

const emit = defineEmits(['close', 'uploaded'])

const pond = ref()


const props = defineProps<{
	allowReplace?: boolean,
	stylePanelLayout?: String,
	instantUpload?: boolean,
	acceptedFileTypes?: String
	name: string,
	allowMultiple?: boolean,
	stylePanelAspectRatio?: string,
	folder: string
}>()

const uploaderStore = useFileUploader()

// Create FilePond component
const FilePond = vueFilePond(FilePondPluginFileValidateType, FilePondPluginImagePreview)

const server = {
	process: (fieldName: string, file: File, metadata: any, load: any, error: any, progress: any, abort: any, transfer: any, options: any) => {
		// fieldName is the name of the input field
		// file is the actual file object to send



		const formData = new FormData();

		formData.append('file', file, file.name);
		formData.append('folder', props.folder);
		formData.append('is_private', '0')
		formData.append('file_name', file.name);

		const request = new XMLHttpRequest();
		request.open('POST', serverApi.baseURL + '/method/upload_file')
		request.withCredentials = true
		request.upload.onprogress = (e) => {
			progress(e.lengthComputable, e.loaded, e.total)
		};

		request.onload = function () {
			if (request.status >= 200 && request.status < 300) {

				const fileObject: FrappeFile = JSON.parse(request.responseText).message
				// the load method accepts either a string (id) or an object
				console.info({ fileObject })
				emit("uploaded", fileObject)
				console.info(JSON.parse(request.responseText).message)
				load(JSON.parse(request.responseText).message);
			} else {
				// Can call the error method if something is wrong, should exit after
				error('oh no');
			}
			console.info('onload')
		};


		request.send(formData)


		// Should expose an abort method so the request can be cancelled
		return {
			abort: () => {
				// This function is entered if the user has tapped the cancel button
				request.abort();

				// Let FilePond know the request has been cancelled
				abort();
			},
		};
	},
}

function handleProcessFiles() {
	console.info('done')
	pond.value.removeFiles()
	emit('close')
}
function handleFilePondInit(e: any) {
	uploaderStore.pond = pond.value
	console.log('FilePond has initialized', uploaderStore.pond);

	// example of instance method call on pond reference

}
function handleLoaded(file: FilePondFile) {
	console.info('Loaded', file)

	uploaderStore.setFileDetails(file)
	uploaderStore.ready = true

}

</script>
<style>
.filepond--wrapper {
	overflow: hidden;
	height: 100%;
	width: 100%;


}

.filepond--root {
	/* background-color: var(--bs-gray-200); */

	/* max-height: 100%; */
	width: 100%;
}

/* use a hand cursor intead of arrow for the action buttons */
.filepond--file-action-button {
	cursor: pointer;
}

/* the text color of the drop label*/
.filepond--drop-label {
	color: var(--bs-text-color);
}

/* underline color for "Browse" button */
.filepond--label-action {
	text-decoration-color: #aaa;
}

/* the background color of the filepond drop area */
.filepond--panel-root {
	background-color: #eee;
	border-radius: var(--bs-border-radius);
}

/* the border radius of the drop area */
.filepond--panel-root {
	border-radius: var(--bs-border-radius);
}

.filepond--item {
	width: calc(50% - 1.5em);
	border-radius: 0.5em;


}

/* the border radius of the file item */
.filepond--item-panel {
	border-radius: 0.5em;
}

/* the background color of the file and file panel (used when dropping an image) */
.filepond--item-panel {
	background-color: #555;
	border-radius: var(--bs-border-radius);
}

/* the background color of the drop circle */
.filepond--drip-blob {
	background-color: #999;
}

.filepond--root[data-style-panel-layout~=compact] .filepond--item,
.filepond--root[data-style-panel-layout~=integrated] .filepond--item {
	border-radius: 0.5em;

}

/* the background color of the black action buttons */
.filepond--file-action-button {
	background-color: rgba(0, 0, 0, 0.5);
}

/* the icon color of the black action buttons */
.filepond--file-action-button {
	color: white;
}

/* the color of the focus ring */
.filepond--file-action-button:hover,
.filepond--file-action-button:focus {
	box-shadow: 0 0 0 0.125em rgba(255, 255, 255, 0.9);
}

.filepond--action-process-item {
	display: none;
}

/* the text color of the file status and info labels */
.filepond--file {
	color: white;
}

.filepond--list-scroller {
	transform: unset !important;
}

/* error state color */
[data-filepond-item-state*='error'] .filepond--item-panel,
[data-filepond-item-state*='invalid'] .filepond--item-panel {
	background-color: red;
}

[data-filepond-item-state='processing-complete'] .filepond--item-panel {
	background-color: green;
}

/* bordered drop area */
/* .pond-wrapper {
	height: 100%;
} */

.filepond--panel-root {
	/*background-color: transparent;*/
	/*border: 2px solid #2c3340;*/
}

.browse {
	cursor: pointer;
	color: var(--bs-primary);
}

.browse:hover {
	color: var(--bs-primary-hover)
}
</style>