<template>
	<div class="position-relative" :class="button ? 'button' : ''">
		<svg class="circle" :width="sizes.viewbox[props.size]" :height="sizes.viewbox[props.size]"
			xmlns="http://www.w3.org/2000/svg">
			<circle :class="props.color" :cx="sizes[props.size]" :cy="sizes[props.size]" :r="sizes[props.size]" />

		</svg>
		<div v-if="props.icon == 'x'" class="position-absolute icon text-center text-white">
			<span class="fw-bold">x</span>

		</div>
		<div v-if="props.icon == 'arrowUp'" class="position-absolute icon text-center text-white">

			<svg :width="sizes.icon[props.size]" :height="sizes.icon[props.size]" viewBox="0 0 29 29" fill="none"
				xmlns="http://www.w3.org/2000/svg">

				<path d="M19.7054 15.7338L14.7556 10.7841L9.80587 15.7338" stroke="white" stroke-width="3"
					stroke-linecap="round" stroke-linejoin="round" />
			</svg>

		</div>
		<div v-if="props.icon == 'arrowDown'" class="position-absolute icon text-center text-white">

			<svg :width="sizes.icon[props.size]" :height="sizes.icon[props.size]" viewBox="0 0 29 29" fill="none"
				xmlns="http://www.w3.org/2000/svg">

				<path d="M19.4983 12.9181L14.5486 17.8678L9.59884 12.9181" stroke="white" stroke-width="3"
					stroke-linecap="round" stroke-linejoin="round" />
			</svg>

		</div>

		<div v-if="props.icon == '+'" class="position-absolute icon text-center text-white">

			<svg :width="sizes.icon[props.size]" :height="sizes.icon[props.size]" viewBox="0 0 29 29" fill="none"
				xmlns="http://www.w3.org/2000/svg">

				<path d="M14.2605 9.77966L14.2605 20.1221" stroke="white" stroke-width="2.24165" stroke-linecap="round"
					stroke-linejoin="round" />
				<path d="M19.4329 14.9509L9.09043 14.9509" stroke="white" stroke-width="2.24165" stroke-linecap="round"
					stroke-linejoin="round" />
			</svg>

		</div>


		<div v-if="props.icon == 'trash'" class="position-absolute icon text-center text-white">

			<svg :width="sizes.icon[props.size]" :height="(sizes.icon[props.size]/1.5)" viewBox="0 0 15 16" fill="none"
				xmlns="http://www.w3.org/2000/svg">

				<path d="M1.44165 4.1825H2.79394H13.6122" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
				<path
					d="M4.82238 4.18248V2.83019C4.82238 2.47154 4.96485 2.12758 5.21845 1.87398C5.47206 1.62038 5.81602 1.47791 6.17467 1.47791H8.87924C9.23789 1.47791 9.58185 1.62038 9.83546 1.87398C10.0891 2.12758 10.2315 2.47154 10.2315 2.83019V4.18248M12.26 4.18248V13.6485C12.26 14.0072 12.1175 14.3511 11.8639 14.6047C11.6103 14.8583 11.2663 15.0008 10.9077 15.0008H4.14623C3.78758 15.0008 3.44362 14.8583 3.19002 14.6047C2.93642 14.3511 2.79395 14.0072 2.79395 13.6485V4.18248H12.26Z"
					stroke="white" stroke-linecap="round" stroke-linejoin="round" />
			</svg>

		</div>

		<div v-if="props.icon == 'slot'" :style="'line-height:' + sizes.viewbox[props.size] + 'px;'"
			class="position-absolute w-100 top-0 text-center text-white">


			<slot></slot>



		</div>




	</div>





</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';


const props = defineProps<{
	button: boolean,
	size: "small" | "medium"
	color: "green" | "red" | "dark" | "blue",
	icon: "trash" | "x" | "arrowUp" | "arrowDown" | "arrowLeft" | "arrowRight" | "+" | "slot" | string
}>()


const sizes = {
	small: 14,
	medium: 20,
	viewbox: {
		small: '28' as string,
		medium: '40',
	},
	icon: {
		small: '29' as string,
		medium: '40' as string,
	}

}
const colors = {
	green: ''
}

</script>

<style lang="scss" scoped>
.green {
	fill: var(--bs-primary);
}

.red {
	fill: var(--bs-danger);
}

.dark {
	fill: #524E61;
}

.icon {
	top: -1px;
	left: 0;
	width: fit-content;
	height: 100%;
}

.button {
	transition: all 0.2s ease-out;
}

.button:hover {
	transform: scale(1.05);
	cursor: pointer;

	.dark {
		fill: #7f7c8a;
	}

	.green {
		fill: #33d9bb;
	}
}
</style>