<template>
	<div>
		<svg :width="sizes.width[size]" :height="sizes.height[size]" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M1.44165 3.24475H2.79394H13.6122" :stroke="stroke" stroke-linecap="round" stroke-linejoin="round" />
			<path
				d="M4.82238 3.24474V1.89245C4.82238 1.5338 4.96485 1.18984 5.21845 0.936237C5.47206 0.682634 5.81602 0.540161 6.17467 0.540161H8.87924C9.23789 0.540161 9.58185 0.682634 9.83546 0.936237C10.0891 1.18984 10.2315 1.5338 10.2315 1.89245V3.24474M12.26 3.24474V12.7108C12.26 13.0694 12.1175 13.4134 11.8639 13.667C11.6103 13.9206 11.2663 14.063 10.9077 14.063H4.14623C3.78758 14.063 3.44362 13.9206 3.19002 13.667C2.93642 13.4134 2.79395 13.0694 2.79395 12.7108V3.24474H12.26Z"
				:stroke="stroke" stroke-linecap="round" stroke-linejoin="round" />
		</svg>



	</div>
</template>

<script setup lang="ts">



defineProps<{
	stroke: string
	size:'small' | 'medium'
}>()
const sizes = {
	width: {
		small: 15,
		medium: 20,
		large: 30
	},
	height: {
		small: 15,
		medium: 20,
		large: 30
	}
}
</script>

<style scoped>
</style>