<template>
	<div class="icon">

		<Trash v-if="icon == 'trash'" :stroke="stroke || '#9EAEBC'" size="small">

		</Trash>

		<View v-if="icon == 'view'" :stroke="stroke || '#9EAEBC'" size="small">

		</View>
		<Share v-if="icon == 'share'" :stroke="stroke || '#9EAEBC'" size="small">

		</Share>

		<Edit v-if="icon == 'edit'" :stroke="stroke || '#9EAEBC'" size="small"></Edit>

		<Search v-if="icon == 'search'" :stroke="stroke || '#9EAEBC'" size="small"></Search>


	</div>
</template>

<script setup lang="ts">
import Trash from '@/components/icons/Trash.vue'
import View from '@/components/icons/View.vue'
import Share from '@/components/icons/Share.vue'
import Edit from '@/components/icons/Edit.vue'
import Search from '@/components/icons/Search.vue'


defineProps<{
	icon?: 'trash' | 'view' | 'share' | 'edit' | 'search'
	stroke?: string
	size?: 'small' | 'medium'
	hover?: string
}>()

</script>

<style scoped>
</style>