<template>
	<div>

		<svg :width="sizes.width[size]" :height="sizes.height[size]" viewBox="0 0 19 18" fill="none"
			xmlns="http://www.w3.org/2000/svg">
			<path fill-rule="evenodd" clip-rule="evenodd"
				d="M11.0135 1.68313C7.49405 1.68313 4.64096 4.61838 4.64096 8.2392C4.64096 11.86 7.49405 14.7953 11.0135 14.7953C14.533 14.7953 17.3861 11.86 17.3861 8.2392C17.3861 4.61838 14.533 1.68313 11.0135 1.68313ZM3.70487 8.2392C3.70487 4.08651 6.97707 0.720093 11.0135 0.720093C15.05 0.720093 18.3222 4.08651 18.3222 8.2392C18.3222 12.3919 15.05 15.7583 11.0135 15.7583C8.90876 15.7583 7.0118 14.843 5.67821 13.3782L1.38483 17.1642C1.18857 17.3372 0.893094 17.3138 0.724869 17.1119C0.556644 16.91 0.579373 16.606 0.775635 16.433L5.08301 12.6346C4.21584 11.3984 3.70487 9.88019 3.70487 8.2392Z"
				:fill="stroke" />
		</svg>


	</div>
</template>

<script setup lang="ts">

defineProps<{
	stroke: string
	size: 'small' | 'medium'
}>()

const sizes = {
	width: {
		small: 19,
		medium: 20,
		large: 30
	},
	height: {
		small: 18,
		medium: 20,
		large: 30
	}
}
</script>

<style scoped>
</style>