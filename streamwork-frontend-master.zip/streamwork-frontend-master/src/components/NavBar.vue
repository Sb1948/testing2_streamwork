<script setup lang="ts">
import { ref } from "vue"
import { useStore } from "../stores/stores"
import Logo from "./Logo.vue"
import { RouterLink } from "vue-router";
const session = useStore()
const expanded = ref(false)
function toggle() {

	if (expanded.value) {
		expanded.value = false
	} else {

		expanded.value = true
		addEventListener('mouseup', () => {
			expanded.value = false
		})

	}
}
const app = useStore()
</script>
<template>
	<div>


		<nav class="navbar navbar-expand-lg bg-light">
			<div class="container-fluid">
				<div class="row w-100 justify-content-between">
					<div class="col-auto">

						<div class="navbar-brand">
							<router-link to="/">
								<Logo></Logo>
							</router-link>

						</div>


					</div>
					<div v-if="app.isLoggedIn && $router.currentRoute.value.name=='Edit'"
							 class="col-auto">
						<div class="project-name px-4">

							{{app.activeProject.doc.project_name}}

						</div>

					</div>

					<div class="col-auto">
						<div class="d-flex flex-row align-items-center">
							<div v-if="app.isAdmin"
									 class="col-auto me-3">
								<span class="small admin text-uppercase text-primary">Admin</span>

							</div>
							<div class="col-auto me-3">
								<span class="text-primary small">{{ app.customerAccount.account_type }}</span>

							</div>
							<div v-if="app.customerAccount.account_type == 'Free Account'"
									 class="d-flex flex-shrink me-3">

								<div class="btn bg-white text-primary fw-bold upgrade-btn "> Upgrade Now!

								</div>

							</div>
							<div class="col-auto avatar-col">
								<div v-if="session.isLoggedIn">
									<button @click.prevent="toggle()"
													class="navbar-toggler"
													type="button"
													data-bs-toggle="collapse"
													data-bs-target="#navbarNavDropdown"
													aria-controls="navbarNavDropdown"
													aria-expanded="false"
													aria-label="Toggle navigation">
										<span class="navbar-toggler-icon"></span>
									</button>


									<a @click.prevent="toggle()"
										 class="nav-link dropdown-toggle text-white avatar"
										 href="#"
										 id="navbarDropdownMenuLink"
										 role="button"
										 data-bs-toggle="dropdown"
										 :aria-expanded="expanded">


										<svg width="37"
												 height="37"
												 viewBox="0 0 37 37"
												 fill="none"
												 xmlns="http://www.w3.org/2000/svg">
											<circle cx="18.5"
															cy="18.25"
															r="18"
															fill="#26274F" />
											<mask id="mask0_116_78"
														style="mask-type:alpha"
														maskUnits="userSpaceOnUse"
														x="0"
														y="0"
														width="37"
														height="37">
												<circle cx="18.5"
																cy="18.25"
																r="18"
																fill="#444C8D" />
											</mask>
											<g mask="url(#mask0_116_78)">
												<circle cx="18.2001"
																cy="16.1498"
																r="8.1"
																fill="#444C8D" />
												<path d="M18.7999 21.5502C7.6999 20.9502 4.3999 32.3502 4.3999 32.3502L18.7999 44.0502L31.6999 33.8502C31.6999 33.8502 29.8999 22.1502 18.7999 21.5502Z"
															fill="#444C8D" />
											</g>
										</svg>

									</a>
									<ul :class="{ 'show': expanded }"
											class="dropdown-menu avatar-dropdown"
											aria-labelledby="navbarDropdownMenuLink">
										<li>
											<RouterLink to="/account"
																	class="dropdown-item">
												Account Settings
											</RouterLink>
											<RouterLink to="/checkout"
																	class="dropdown-item">
												Upgrad to Pro
											</RouterLink>

										</li>
										<li>
											<hr class="dropdown-divider">
										</li>
										<li><a class="dropdown-item"
												 @click="session.logout()"
												 href="#">Logout
												<font-awesome-icon icon="fa-solid fa-arrow-right-from-bracket" />
											</a></li>
									</ul>




								</div>


							</div>

						</div>

					</div>

				</div>



			</div>
		</nav>

	</div>
</template>
<style lang="scss" scoped>
.project-name {
	--height: calc(var(--header-height) / 1.5);
	background-color: #26274F33;
	display: inline-block;
	vertical-align: center;
	height: var(--height);
	line-height: var(--height);

	border-radius: var(--bs-border-radius);
}

.avatar-col {
	// margin-right: 110px;
}

.dropdown-toggle:after {
	border-bottom: 0;
	content: none;

}

.avatar-dropdown {
	right: 10px;
}

.upgrade-btn {
	padding-left: 1rem;
	padding-right: 1rem;
}

.admin {
	font-weight: bold;
	font-size: 0.6rem;
	color: white;
}
</style>