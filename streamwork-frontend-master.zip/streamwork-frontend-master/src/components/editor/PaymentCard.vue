<template>
    <div>
        <ul class="list-group">
        <li class="list-group-item" v-for="payment in app.activeProject.doc.payments" :key="payment.name">
        {{payment.amount}}
        {{payment.idx}}
        </li>
        </ul>

    </div>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';

const app = useStore()
</script>

<style scoped>
</style>