<template>
	<div class="container-fluid py-4 px-4 position-relative">
		<div class="row">
			<div class="col">


				<Transition name="slide-fade"
										mode="out-in">

										
					<!-- start project info -->
					<div v-if="app.activeProject.activeEditor == 'ProjectInfo'"
							 class="position-relative">

						<InputField text="Project Title"
												:initValue="app.activeProject.doc.title"
												@updateInput="(inputValue) => { app.activeProject.doc.title = inputValue.value }"></InputField>


						<div class="row mb-3">
							<div class="col-md-12">

								<div class="quill-container">
									<label class="form-label">Description</label>

									<QuillEditor class="quill-or"
															 @update:content="quillUpdated()"
															 @ready="quillReady()"
															 ref="quill"
															 toolbar="#toolbar"
															 v-model:content="app.activeProject.doc.description"
															 theme="snow" />
									<div id="toolbar"
											 class="d-flex mx-auto justify-content-between align-items-center">
										<!-- Add buttons as you would before -->
										<button class="ql-bold"></button>
										<button class="ql-italic"></button>
										<button class="ql-underline"></button>
										<button class="ql-link"></button>
										<button class="ql-list"
														value="ordered"></button>
										<button class="ql-list"
														value="bullet"></button>
										<button class="ql-clean"></button>


									</div>

								</div>


							</div>

						</div>
						<InputField text="Client"
												:initValue="app.activeProject.doc.client"
												@updateInput="(inputValue) => { app.activeProject.doc.client = inputValue.value }"></InputField>
						<InputField text="Contact Name"
												:initValue="app.activeProject.doc.contact_person_name"
												@updateInput="(inputValue) => { app.activeProject.doc.contact_person_name = inputValue.value }">
						</InputField>
						<InputField text="Contact Email"
												:initValue="app.activeProject.doc.contact_email"
												@updateInput="(inputValue) => { app.activeProject.doc.contact_email = inputValue.value }">
						</InputField>

						<div class="row position-relative">
							<div class="col">


								<label class="form-label">Cover Image</label>
								<div role="button"
										 class="project-icon-wrapper"
										 :style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.doc.cover_image_url + '\')'"
										 @click="selectProjectIcon({ isCover: true, isFooter: false })">
									<Transition name="slide-fade"
															mode="out-in">

										<div v-if="!app.activeProject.doc.cover_image_url"
												 class="icon-placeholder">

										</div>
									</Transition>


								</div>

							</div>
							<div class="col">
								<label class="form-label">Footer Image</label>
								<div role="button"
										 class="project-icon-wrapper"
										 :style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.doc.footer_image_url + '\')'"
										 @click="selectProjectIcon({ isCover: false, isFooter: true })">
									<Transition name="slide-fade"
															mode="out-in">

										<div v-if="!app.activeProject.doc.footer_image_url"
												 class="icon-placeholder">

										</div>
									</Transition>


								</div>

							</div>
							<Transition name="slide-fade">


								<div v-if="app.activeProject.showProjectIcons"
										 class="cover-footer-icon-selector">
									<ProjectIconSelector :isCover="updateCover"
																			 :isFooter="updateFooter"></ProjectIconSelector>

								</div>
							</Transition>

						</div>


					</div>
					<!-- End project info card-->

					
					<!-- Standard step card-->
					<div v-else-if="app.activeProject.activeEditor == 'Steps' && activeProject.activeStep.step_type == 'Standard'"
							 class="steps-container">
						<Collapsable title="Details"
												 :open="true">
							<InputField text="Step Title"
													:initValue="app.activeProject.activeStep.title"
													@updateInput="(inputValue) => { app.activeProject.activeStep.title = inputValue.value }"
													:key="app.activeProject.activeStep.name">
							</InputField>


							<div class="row my-3">
								<div class="col">
									<textarea v-model="app.activeProject.activeStep.description"
														class="form-control"
														:id="app.activeProject.activeStep.name"
														rows="4"
														maxlength="500"
														style="resize: none;"></textarea>

								</div>

							</div>
						</Collapsable>

						<Collapsable title="Image"
												 :open="true">
							<Transition name="slide-fade">

								<ProjectIconSelector v-show="app.activeProject.iconSelectorActive">

								</ProjectIconSelector>
							</Transition>
							<div role="button"
									 class="edit-icon-wrapper mx-auto my-2"
									 :style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.activeStep.icon_url + '\')'"
									 @click="changeStepIcon">
								<Transition name="slide-fade"
														mode="out-in">

									<div v-if="!app.activeProject.activeStep.icon_url"
											 class="icon-placeholder">

									</div>
								</Transition>

							</div>
						</Collapsable>



						<Collapsable title="Timeframe">
							<TimeField></TimeField>
						</Collapsable>


						<!-- Attachments Section -->
						<Collapsable title="Attachments">
							<template v-slot:topbar>
								<SquareButton class="me-1"
															tipContent="Add Link"
															@btnClick="app.activeProject.activeButtons ? addUrl() : ''"
															:customClasses="{ 'btn-square-primary': app.activeProject.activeButtons, 'btn-square-secondary disabled': !app.activeProject.activeButtons }">
									<svg width="21"
											 height="20"
											 viewBox="0 0 21 20"
											 fill="none"
											 xmlns="http://www.w3.org/2000/svg">
										<path d="M11.8558 9.13555C11.6583 9.13555 11.4609 9.06036 11.3105 8.9096C10.1079 7.70698 8.15111 7.70659 6.94811 8.9096C6.64735 9.21074 6.15844 9.21074 5.85769 8.9096C5.55655 8.60846 5.55655 8.12032 5.85769 7.81918C7.66181 6.01467 10.5972 6.01506 12.401 7.81918C12.7021 8.12032 12.7021 8.60846 12.401 8.9096C12.2506 9.06036 12.0528 9.13555 11.8558 9.13555Z"
													fill="white" />
										<path d="M11.311 13.5346C10.1261 13.5346 8.9412 13.0835 8.03933 12.1816C7.73819 11.8805 7.73819 11.3923 8.03933 11.0912C8.34008 10.7901 8.829 10.7901 9.12975 11.0912C10.3324 12.2938 12.2892 12.2942 13.4922 11.0912C13.7929 10.7901 14.2819 10.7901 14.5826 11.0912C14.8837 11.3923 14.8837 11.8805 14.5826 12.1816C13.6804 13.0835 12.4955 13.5346 11.311 13.5346Z"
													fill="white" />
										<path d="M14.0367 12.4072C13.8393 12.4072 13.6419 12.332 13.4915 12.1812C13.1903 11.8801 13.1903 11.3919 13.4915 11.0908L17.7992 6.7831C18.0999 6.48197 18.5888 6.48197 18.8896 6.7831C19.1907 7.08424 19.1907 7.57239 18.8896 7.87352L14.5819 12.1812C14.4315 12.332 14.2341 12.4072 14.0367 12.4072Z"
													fill="white" />
										<path d="M7.54841 18.8957C7.35099 18.8957 7.15357 18.8205 7.0032 18.6698C6.70206 18.3686 6.70206 17.8805 7.0032 17.5794L9.41114 15.1714C9.71189 14.8703 10.2008 14.8703 10.5016 15.1714C10.8027 15.4725 10.8027 15.9607 10.5016 16.2618L8.09362 18.6698C7.94324 18.8205 7.74582 18.8957 7.54841 18.8957Z"
													fill="white" />
										<path d="M2.09528 13.4428C1.89786 13.4428 1.70045 13.3676 1.55007 13.2168C1.24893 12.9157 1.24893 12.4276 1.55007 12.1264L5.85776 7.81911C6.1589 7.51798 6.64743 7.51798 6.94818 7.81911C7.24932 8.12025 7.24932 8.6084 6.94818 8.90953L2.64049 13.2168C2.48973 13.3672 2.29231 13.4428 2.09528 13.4428Z"
													fill="white" />
										<path d="M10.484 5.05492C10.2865 5.05492 10.0895 4.97973 9.93874 4.82935C9.63761 4.52822 9.63761 4.04007 9.93874 3.73855L12.3467 1.33022C12.6478 1.02909 13.136 1.02909 13.4375 1.33022C13.7386 1.63136 13.7386 2.1195 13.4375 2.42103L11.0295 4.82935C10.8788 4.97934 10.681 5.05492 10.484 5.05492Z"
													fill="white" />
										<path d="M4.82161 20C3.62902 20 2.43642 19.5566 1.54997 18.6698C-0.22369 16.8961 -0.22369 13.8998 1.54997 12.1261C1.85073 11.825 2.33964 11.825 2.64039 12.1261C2.94153 12.4273 2.94153 12.9154 2.64039 13.2165C1.45821 14.3987 1.45821 16.3968 2.64039 17.579C3.82258 18.7612 5.82065 18.7612 7.00284 17.579C7.30359 17.2778 7.7925 17.2778 8.09325 17.579C8.39439 17.8801 8.39439 18.3683 8.09325 18.6694C7.20681 19.5566 6.01421 20 4.82161 20Z"
													fill="white" />
										<path d="M18.344 8.09947C18.1466 8.09947 17.9492 8.02429 17.7988 7.87353C17.4977 7.57239 17.4977 7.08425 17.7988 6.78311C18.981 5.60092 18.981 3.60285 17.7988 2.42067C16.6166 1.23848 14.6186 1.23848 13.4364 2.42067C13.1356 2.7218 12.6467 2.7218 12.346 2.42067C12.0448 2.11953 12.0448 1.63139 12.346 1.33025C14.1196 -0.443416 17.116 -0.443416 18.8896 1.33025C20.6633 3.10391 20.6633 6.10025 18.8896 7.87391C18.7389 8.02429 18.5415 8.09947 18.344 8.09947Z"
													fill="white" />
									</svg>
								</SquareButton>
								<SquareButton class="me-1"
															tipContent="Add File"
															:customClasses="{ 'btn-square-primary': app.activeProject.activeButtons, 'btn-square-secondary disabled': !app.activeProject.activeButtons }"
															@btnClick="app.activeProject.activeButtons ? showUploadingFile() : ''">
									<svg width="18"
											 height="23"
											 viewBox="0 0 18 23"
											 fill="none"
											 xmlns="http://www.w3.org/2000/svg">
										<path d="M5.75669 0.17559C5.86087 0.065868 6.0037 0 6.15173 0H15.0146C16.6501 0 18 1.34457 18 2.97984V19.7396C18 21.375 16.6501 22.7196 15.0146 22.7196H2.98538C1.34995 22.7196 0 21.375 0 19.7396V6.43167C0 6.28901 0.0658684 6.1519 0.159122 6.04755L5.75669 0.17559ZM5.59757 1.93721L1.84933 5.87196H4.28593C5.0103 5.87196 5.59757 5.29024 5.59757 4.56587V1.93721ZM2.98538 21.622H15.0146C16.0408 21.622 16.9024 20.7715 16.9024 19.7396V2.97984C16.9024 1.95368 16.0463 1.09757 15.0146 1.09757H6.69514V4.56587C6.69514 5.89935 5.61941 6.96953 4.28593 6.96953H1.09757V19.7396C1.09757 20.7715 1.95368 21.622 2.98538 21.622Z"
													fill="white" />
										<path d="M4.48371 17.8354H13.5166C13.8184 17.8354 14.0654 18.0823 14.0654 18.3842C14.0654 18.686 13.8184 18.933 13.5166 18.933H4.47816C4.17638 18.933 3.92938 18.686 3.92938 18.3842C3.92938 18.0823 4.17638 17.8354 4.48371 17.8354Z"
													fill="white" />
										<path d="M11.8093 11.9306L9.54825 9.49935V15.4921C9.54825 15.7939 9.30124 16.0409 8.99946 16.0409C8.69751 16.0409 8.45068 15.7939 8.45068 15.4921V9.49935L6.18967 11.9306C6.07995 12.0457 5.93712 12.1062 5.78909 12.1062C5.65735 12.1062 5.52007 12.0568 5.4159 11.958C5.19628 11.7494 5.17981 11.4036 5.38834 11.1842L8.60426 7.73235C8.7086 7.62263 8.85126 7.55676 9.00484 7.55676C9.15859 7.55676 9.30124 7.62263 9.40542 7.73235L12.6213 11.1842C12.8299 11.4036 12.8134 11.7548 12.594 11.958C12.3634 12.1665 12.0178 12.15 11.8093 11.9306Z"
													fill="white" />
									</svg>


								</SquareButton>

							</template>




							<div class="row mb-3">
								<div class="col mt-2">

									<Transition name="slide-fade">

										<AddLinkModal v-show="app.activeProject.showNewLink"></AddLinkModal>
									</Transition>
									<Transition name="slide-fade">
										<AddFileModal v-show="uploadStore.active"></AddFileModal>
									</Transition>
									<TransitionGroup name="list-pop"
																	 tag="ul"
																	 class="list-group list-group-flush position-relative">

										<LinkListItem v-for="link, index in app.activeProject.stepLinks[app.activeProject.activeStep.name]"
																	:key="link.name"
																	:link="link"
																	:index="index">

										</LinkListItem>
										<!-- 	<li class="list-group-item bg-gray border-radius border-none mb-2"
												v-for="link, index in app.activeProject.stepLinks[app.activeProject.activeStep.name]"
												:key="link.name">

											<div class="d-flex">

												<div class="fw-bold d-flex flex-shrink">
													{{ link.type }}

												</div>

												<div class="d-flex flex-column flex-grow-1 mx-2">
													<div>

														{{ link.title }}

													</div>
													<div v-if="link.type == 'File'"
															 class="text-truncate">
														<a :href="app.staticHostUrl + link.file"
															 target="_blank"><small>
																{{ link.file?.replace('/files/', '') }}</small></a>

													</div>
													<div v-else
															 class="text-truncate">
														<a :href="link.url"
															 target="_blank"><small>{{ link.url }}</small>
														</a>

													</div>

												</div>
												<div class="d-flex flex-shrink">


													<div class="d-flex align-items-center">
														<div class="d-flex flex-column">
															<div class="btn-circle bg-danger text-center"
																	 @click="app.deleteLink(link, index)">
																<svg width="21"
																		 height="21"
																		 viewBox="0 0 21 21"
																		 fill="none"
																		 xmlns="http://www.w3.org/2000/svg">
																	<path d="M2.99023 5.48853H4.66191H18.0353"
																				stroke="white"
																				stroke-width="2"
																				stroke-linecap="round"
																				stroke-linejoin="round" />
																	<path d="M7.16962 5.4885V3.84105C7.16962 3.40412 7.34575 2.98509 7.65925 2.67613C7.97275 2.36717 8.39795 2.1936 8.8413 2.1936H12.1847C12.628 2.1936 13.0532 2.36717 13.3667 2.67613C13.6802 2.98509 13.8563 3.40412 13.8563 3.84105V5.4885M16.3638 5.4885V17.0206C16.3638 17.4576 16.1877 17.8766 15.8742 18.1856C15.5607 18.4945 15.1355 18.6681 14.6922 18.6681H6.33379C5.89043 18.6681 5.46523 18.4945 5.15173 18.1856C4.83823 17.8766 4.66211 17.4576 4.66211 17.0206V5.4885H16.3638Z"
																				stroke="white"
																				stroke-width="2"
																				stroke-linecap="round"
																				stroke-linejoin="round" />
																</svg>

															</div>


														</div>

													</div>

												</div>

											</div>


										</li> -->
									</TransitionGroup>

								</div>

							</div>




						</Collapsable>


						<div class="row justify-content-around mb-2">
							<div class="col-auto">
								<div class="form-check form-switch">
									<input class="form-check-input"
												 type="checkbox"
												 id="flexSwitchCheckChecked"
												 checked>
									<label class="form-check-label"
												 for="flexSwitchCheckChecked">Requires approval</label>

								</div>

							</div>
							<div class="col-auto">

								<div class="form-check">
									<input class="form-check-input"
												 type="checkbox"
												 id="completed">
									<label class="form-check-label"
												 for="completed">
										Completed
									</label>

								</div>

							</div>


						</div>

					</div>
					<!-- End steps card-->


					<!-- Start Theme Editor -->
					<div v-else-if="app.activeProject.activeEditor == 'Theme'">
						<div class="row position-relative justify-content-center mb-4"
								 style="z-index: 2;">

							<div class="col-auto">
								<label class="form-label">Font Style</label>
								<div class="form-control font-select d-flex justify-content-between"
										 role="button"
										 :style="'font-family:' + theme.activeFont"
										 @click="openFonts()">
									<span>{{ theme.activeFont }}</span><span>
										<font-awesome-icon icon="fa-solid fa-angle-down"></font-awesome-icon>
									</span>

								</div>
								<div v-show="app.activeProject.fontChoicesActive"
										 class="font-choices shadow bg-white pt-2">

									<div role="button"
											 v-for="font in app.fonts"
											 :style="'font-family:' + font.name"
											 class="font-option py-2 px-4"
											 @click="theme.changeFont(font)">
										{{ font.name }}

									</div>



								</div>

							</div>



						</div>
						<div class="row justify-content-center position-relative"
								 style="z-index: 1;">
							<div class="col-auto">

								<h6 class="text-primary text-center">Color Group</h6>
								<div v-for="palette in colorPalettes"
										 :key="palette.name"
										 class="palette-button d-flex p-2 mx-0 my-1"
										 @click="theme.setPalette(palette, true)"
										 :class="{ active: theme.colorPalette.name == palette.name }">

									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.background }">

									</div>
									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.step_background }">

									</div>
									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.primary }">

									</div>
									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.secondary }">

									</div>
									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.text }">

									</div>
									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.info }">

									</div>
									<div class="d-flex palette-sample"
											 :style="{ backgroundColor: palette.contact }">

									</div>



								</div>

							</div>


						</div>


					</div>
					<div v-else-if="app.activeProject.activeEditor == 'Template'">
						<div class="mb-4">

							<div class="form-check form-switch">
								<input class="form-check-input"
											 type="checkbox"
											 id="flexSwitchCheckDefault"
											 :checked="app.activeProject.doc.is_template == 1"
											 @change="toggleTemplate()">
								<label class="form-check-label"
											 for="flexSwitchCheckDefault">Treat as template</label>

							</div>

						</div>
						<div v-if="app.activeProject.doc.is_template == 1">
							<div class="row mb-4">
								<div class="col">
									<InputField @updateInput="(inputValue) => { app.activeProject.doc.template_name = inputValue.value }"
															text="Template Name"></InputField>

									<div v-if="app.activeProject.doc.category"
											 class="d-flex category-card border flex-column justify-content-start align-items-center category">



										<div class="category-icon-wrapper">
											<img class="category-icon"
													 :src="app.staticHostUrl + app.activeProject.category.category_icon" />

										</div>

										<div class="category-name-wrapper text-center">


											<span class="category-name">{{ app.activeProject.category.category_name }}</span>


										</div>




									</div>



								</div>
								<div class="col-auto">
									<label>Preview Image</label>
									<div role="button"
											 class="preview-image-wrapper mx-auto"
											 :style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.doc.preview_image + '\')'"
											 @click="changePreviewImage">

										<PreviewUploader v-show="!app.activeProject.doc.preview_image || app.activeProject.showPreviewImageUploader"
																		 @uploaded="(fileObject: FrappeFile) => {
																		 	app.activeProject.doc.preview_image = fileObject.file_url
																		 	app.activeProject.showPreviewImageUploader = false
																		 }"
																		 name="preview"
																		 folder="Home/Previews"></PreviewUploader>
										<div v-show="app.activeProject.doc.preview_image && app.activeProject.showPreviewImageUploader"
												 class="btn btn-secondary">Cancel

										</div>

									</div>

								</div>

							</div>


							<div class="row mb-2">
								<div class="col">


									<Collapsable title="Category">
										<div class="row justify-content-start mb-4">
											<div v-for="(category) in app.categories"
													 class="col-md-4 col-sm-12 mb-4 sw-width"
													 :key="category.name">
												<div class="category-card border"
														 :class="{ active: app.activeProject.doc.category == category.name }"
														 :id="category.name"
														 @click="() => { app.activeProject.doc.category = category.name; app.activeProject.category = category }">
													<div class="container h-100">
														<div class="d-flex flex-column justify-content-center align-items-center category">



															<div class="category-icon-wrapper mb-1">
																<img class="category-icon mx-auto"
																		 :src="app.staticHostUrl + category.category_icon" />

															</div>

															<div class="category-name-wrapper text-center">


																<span class="category-name">{{ category.category_name }}</span>


															</div>




														</div>


													</div>

												</div>

											</div>

										</div>
									</Collapsable>

								</div>

							</div>
							<div class="row">
								<div class="col">
									<Collapsable title="Icon Set">
										<div class="row">
											<div class="col">
												<div class="btn-circle bg-primary fw-bold h4"
														 @click="openIconUploader = true">
													+

												</div>

											</div>

										</div>
										<div class="row">
											<TemplateIcons></TemplateIcons>


										</div>
										<Transition name="fade">

											<div v-show="openIconUploader"
													 class="icon-uploader-wrapper"
													 @click.self="openIconUploader = false">

												<div class="icon-uploader p-4 rounded shadow">
													<IconUploader @close="openIconUploader = false"></IconUploader>

												</div>

											</div>
										</Transition>

									</Collapsable>

								</div>

							</div>


						</div>

					</div>


				</Transition>

			</div>

		</div>


	</div>
</template>

<script setup lang="ts">
import ProjectIconSelector from '@/components/ProjectIconSelector.vue';
import { useFileUploader, useStore } from '@/stores/stores';
import Delta from 'quill-delta';
import { QuillEditor } from '@vueup/vue-quill'
import type { Quill } from '@vueup/vue-quill'
import '@/assets/quill.css'
import { ref } from 'vue';
import Collapsable from './Collapsable.vue';
import TimeField from '@/components/editor/TimeField.vue';
import { storeToRefs } from 'pinia';
import { useTheme } from '@/stores/theme';
import TemplateIcons from '../TemplateIcons.vue';
import IconUploader from '../IconUploader.vue';
import InputField from './InputField.vue';
import SquareButton from '../SquareButton.vue';
import LinkListItem from './LinkListItem.vue';
import AddLinkModal from './AddLinkModal.vue';
import AddFileModal from './AddFileModal.vue';
import PreviewUploader from '../PreviewUploader.vue';
import type { FrappeFile } from '@/types/docTypes';

const uploadStore = useFileUploader()
const app = useStore()
const description = ref(new Delta())
const quill = ref(null as Quill)
const updateCover = ref(false)
const updateFooter = ref(false)
const toolbarOptions = [
	['bold', 'italic', 'underline'],        // toggled buttons
	[{ 'list': 'ordered' }, { 'list': 'bullet' }],
	['clean']                                         // remove formatting button
];
const openIconUploader = ref(false);
const theme = useTheme()
const { activeProject, colorPalettes } = storeToRefs(app)

function quillReady() {
	// console.info('Quill ready')
	// console.info(quill.value)
}
function quillUpdated() {
	// console.info('Quill updated')
	app.activeProject.doc.description_html = quill.value.getHTML()
	//console.info()
}

function changeStepIcon() {
	app.activeProject.iconSelectorActive = true
	document.addEventListener('mouseup', () => {
		app.activeProject.iconSelectorActive = false
	}, { once: true })
}
function changePreviewImage() {
	app.activeProject.showPreviewImageUploader = true
}
function openFonts() {
	app.activeProject.fontChoicesActive = true
	document.addEventListener('mouseup', () => {
		app.activeProject.fontChoicesActive = false
	}, { once: true })
}
function selectProjectIcon(options: { isCover: boolean, isFooter: boolean }) {
	document.addEventListener('mouseup', () => {
		app.activeProject.showProjectIcons = false
	}, { once: true })
	document.querySelector(options.isCover ? '#cover-image' : '#footer-image')?.scrollIntoView({
		behavior: 'smooth',
		block: 'center'
	})
	updateCover.value = options.isCover
	updateFooter.value = options.isFooter
	app.activeProject.showProjectIcons = true

}


function addUrl() {
	app.activeProject.activeButtons = false
	if (!app.activeProject.stepLinks[app.activeProject.activeStep.name]) {
		app.activeProject.stepLinks[app.activeProject.activeStep.name] = []
	}
	app.activeProject.newLink.title = ''
	app.activeProject.newLink.url = ''
	app.activeProject.newLink.name = app.activeProject.doc.name + (Math.random() + 1).toString(36).substring(7)
	app.activeProject.newLink.parent = app.activeProject.doc.name
	app.activeProject.newLink.step = app.activeProject.activeStep.name
	app.activeProject.newLink.type = 'URL'
	app.activeProject.newLink.idx = app.activeProject.doc.links.length - 1
	app.activeProject.showNewLink = true


}

function showUploadingFile() {
	uploadStore.active = true
	app.activeProject.activeButtons = false
}




function toggleTemplate() {
	app.activeProject.doc.is_template = + !Boolean(app.activeProject.doc.is_template)
}
</script>

<style lang="scss" scoped>
.icon-uploader-wrapper {
	position: fixed;
	width: 100vw;
	height: 100vh;
	top: 0;
	left: 0;
	background-color: #0000005f;
	z-index: 4;
}

.icon-uploader {
	position: fixed;
	width: 50vw;
	height: 50vh;
	top: 25vh;
	left: 25vw;
	z-index: 5;
	background-color: white;
}

// .form-control {
// 	border: 1px solid rgba(82, 78, 97, 0.25);
// 	border-radius: 10px;
// }

// input.form-control {
// 	height: 38px;


// }

.form-label {
	font-size: 0.9rem;
	color: #26274F80;
	font-weight: 700;

}

.project-icon-wrapper,
.edit-icon-wrapper {
	background-repeat: no-repeat;
	background-color: var(--bs-light);
	background-size: contain;
	background-position: 50%;
	background-origin: content-box;
	border-radius: var(--bs-border-radius);
}

.preview-image-wrapper {
	background-repeat: no-repeat;
	background-color: var(--bs-light);
	background-size: cover;
	background-position: 50% 0;
	background-origin: content-box;
	border-radius: var(--bs-border-radius);
	width: 160px;
	height: 120px;
	padding: 10px;
	transition: all 0.15s ease;

}

.project-icon-wrapper {
	width: 100%;
	height: 120px;
	padding: 20px 10px;
	transition: all 0.15s ease;
}


.cover-footer-icon-selector {
	position: absolute;
	top: 0;
	left: 0;
	transition: all 0.15s ease;
}

.edit-icon-wrapper {
	width: 160px;
	height: 120px;
	padding: 10px;
	transition: all 0.15s ease;
}

.border-none {
	border: none;
}



.palette-button:hover {
	cursor: pointer;
	border: 1px dashed var(--bs-secondary);

}

.palette-button.active {
	cursor: pointer;
	border: 1px solid var(--bs-primary);
	transition: all 0.15s ease-out;

}

.palette-button {

	margin-bottom: 0.5rem;
	border: 1px solid white;
	border-radius: var(--bs-border-radius);
}

.palette-sample {
	width: 37px;
	height: 37px;
	padding: 0;
	border-radius: 50%;
	border: 1px solid var(--bs-border-color);
	margin: 0px 5px;
}

.font-choices {
	position: absolute;
	min-width: 200px;
	max-width: 300px;
	border: 1px solid var(--bs-border-color);
	border-radius: var(--bs-border-radius);
	overflow: hidden;

}

.font-option:hover {
	background-color: var(--bs-primary);
	color: white;
}

.font-option {
	transition: all 0.15s ease-out;
	background-color: white;
}

.font-select {
	min-width: 200px;
	max-width: 300px;
}

.payment-amount {
	max-height: 38px;
}

.category-card {
	box-shadow: 0 0px 0px rgba(0, 0, 0, 0.01);
	// height: 130px;
	// width: 130px;
	cursor: pointer;
	font-size: 16px;
	transition: all 0.15s ease;
	//	border: 1px solid var(--bs-border-color);
	border-radius: var(--bs-border-radius);

	.category-name {
		transition: all 0.15s ease;
	}

}

.category-card.active {
	background-color: var(--bs-primary);

	.category-name {

		color: white;
		font-weight: bold;
	}
}

.category-card.active:hover {
	.category-name {
		color: white;
	}
}

.category-card:hover {
	.category-name {
		color: var(--bs-primary);
	}

	transform: scale(1.02);
	box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);
}

.category-wrapper,
.template-wrapper {
	max-width: 1000px;

}

.category-icon-wrapper {

	width: fit-content;
}

.category-icon {
	height: 35px;
	width: fit-content;
	margin: 10px 0 0 0;
}

.category-name {

	font-size: 0.8rem;
	color: #524E61;

	vertical-align: middle;
}

.category {
	height: 85px;
}

.category-name-wrapper {
	// line-height: 65px;
	line-height: 1 !important;
}

.quill-container {
	border: 1px solid #D4D3D8;
	border-radius: var(--bs-border-radius);
	padding: 0.25rem 0.75rem;

	.form-label {
		margin-bottom: 0;
	}
}
</style>

<style lang="scss">
.ql-container.ql-snow {
	border: none;
}

.ql-editor {
	padding: 0;
}

.ql-toolbar.ql-snow {
	width: fit-content;
	border: 1px solid #d1d5db;
	border-radius: var(--bs-border-radius);
	box-sizing: border-box;
	font-family: 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif;
	padding: 0.2rem;
	/* border-bottom: 0;
	border-top-left-radius: var(--bs-border-radius);
	border-top-right-radius: var(--bs-border-radius); */
}

.ql-snow.ql-toolbar button,
.ql-snow .ql-toolbar button {
	margin-left: 8px;
	margin-right: 1px;
	border-radius: var(--bs-border-radius);
}

.ql-snow.ql-toolbar button.ql-active,
.ql-snow .ql-toolbar button.ql-active,
.ql-snow.ql-toolbar .ql-picker-label.ql-active,
.ql-snow .ql-toolbar .ql-picker-label.ql-active,
.ql-snow.ql-toolbar .ql-picker-item.ql-selected,
.ql-snow .ql-toolbar .ql-picker-item.ql-selected {
	background-color: var(--bs-light);
	color: var(--bs-primary);
}

.ql-snow.ql-toolbar button.ql-active .ql-stroke,
.ql-snow .ql-toolbar button.ql-active .ql-stroke,
.ql-snow.ql-toolbar .ql-picker-label.ql-active .ql-stroke,
.ql-snow .ql-toolbar .ql-picker-label.ql-active .ql-stroke,
.ql-snow.ql-toolbar .ql-picker-item.ql-selected .ql-stroke,
.ql-snow .ql-toolbar .ql-picker-item.ql-selected .ql-stroke,
.ql-snow.ql-toolbar button.ql-active .ql-stroke-miter,
.ql-snow .ql-toolbar button.ql-active .ql-stroke-miter,
.ql-snow.ql-toolbar .ql-picker-label.ql-active .ql-stroke-miter,
.ql-snow .ql-toolbar .ql-picker-label.ql-active .ql-stroke-miter,
.ql-snow.ql-toolbar .ql-picker-item.ql-selected .ql-stroke-miter,
.ql-snow .ql-toolbar .ql-picker-item.ql-selected .ql-stroke-miter {
	stroke: var(--bs-primary);
}
</style>