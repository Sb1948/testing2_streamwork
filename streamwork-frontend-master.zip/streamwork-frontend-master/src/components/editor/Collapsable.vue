<template>



	<div class="wrap-container mb-2 container-fluid"
			 :class="{ open: reveal }">
		<div role="button"
				 class="row header px-3 justify-content-between"
				 @click.self="reveal = !reveal">
			<div class="col-auto"
					 @click="reveal = !reveal">
				<span class="title">

					{{ title }}
				</span>

			</div>

			<div class="col-auto">
				<Transition name="fade">

					<span v-show="reveal">

						<slot name="topbar"></slot>

					</span>
				</Transition>
				<span class="title"
							@click="reveal = !reveal">
					<svg class="arrow"
							 :class="{ closed: !reveal }"
							 width="11"
							 height="6"
							 viewBox="0 0 11 6"
							 fill="none"
							 xmlns="http://www.w3.org/2000/svg">
						<path d="M10.3442 0.500001L5.67187 5L0.999571 0.499999"
									stroke="#26274F"
									stroke-linecap="round"
									stroke-linejoin="round" />
					</svg>


				</span>

			</div>

		</div>

		<Transition name="v-size">

			<div v-show="reveal"
					 class="row px-3 content">
				<div class="col">

					<slot></slot>

				</div>

			</div>
		</Transition>

	</div>

</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';

const props = defineProps<{
	title: string,
	open?: boolean,
}>()

const reveal = ref(false)
onMounted(() => {
	reveal.value = props.open ? true : false
})
</script>

<style lang="scss" scoped>
.wrap-container.open {
	border: 1px solid var(--bs-light);


	.header {
		background: transparent;
	}
}

.wrap-container {
	border-radius: var(--bs-border-radius);
	overflow: hidden;
	// border: 1px solid var(--bs-border-color);
	// transition: all 0.15s ease;
}

.header {
	background: var(--bs-light);
	transition: all 0.15s ease;

}

.content {
	transform-origin: center top;
}

.title {
	color: var(--bs-primary);
	line-height: 49px;
	font-weight: 500;
}

.arrow {
	transition: all 0.1s ease;
}

.closed {
	transform: rotate(-90deg);
}
</style>