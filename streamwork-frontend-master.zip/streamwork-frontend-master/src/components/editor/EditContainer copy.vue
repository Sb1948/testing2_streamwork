
<script setup lang="ts">
import LinksList from '@/components/LinksList.vue';
import { serverApi } from '@/composables/frappe';
import FileUploader from '@/components/FileUploader.vue';
import ProjectIconSelector from '@/components/ProjectIconSelector.vue';
import { useFileUploader, useStore } from '@/stores/stores';
import { useTheme } from '@/stores/theme';
import { onActivated, watch, ref, onMounted, onUpdated } from 'vue';
import Delta from 'quill-delta';
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css'
import UpArrow from '@/svg/UpArrow.svg'
import DownArrow from '@/svg/DownArrow.svg'
import CircleTrash from '@/svg/CircleTrash.svg'
import FileButtonSmall from '@/svg/FileButtonSmall.svg'
import LinkButtonSmall from '@/svg/LinkButtonSmall.svg'
import Link from '@/svg/Link.svg'
import type { ProjectLink, ProjectStep } from '@/types/docTypes.js';
import TimeField from './TimeField.vue';
import Loader from '../Loader.vue';
import CircleButton from '../icons/CircleButton.vue';
const app = useStore()
const theme = useTheme()
const uploadStore = useFileUploader()
const updateCover = ref(false)
const updateFooter = ref(false)
const showIcons = ref(false)

const description = ref(new Delta())
const quill = ref(null)

function quillReady() {
	// console.info('Quill ready')
	// console.info(quill.value)
}
function quillUpdated() {
	// console.info('Quill updated')
	app.activeProject.doc.description_html = quill.value.getHTML()
	//console.info()
}

function selectProjectIcon(options: { isCover: boolean, isFooter: boolean }) {
	document.addEventListener('mouseup', () => {
		app.activeProject.showProjectIcons = false
	}, { once: true })
	document.querySelector(options.isCover ? '#cover-image' : '#footer-image')?.scrollIntoView({
		behavior: 'smooth',
		block: 'center'
	})
	updateCover.value = options.isCover
	updateFooter.value = options.isFooter
	app.activeProject.showProjectIcons = true

}

function addStep() {

	//Can change 7 to 2 for longer results.
	let r = app.activeProject.doc.name + (Math.random() + 1).toString(36).substring(7);

	app.activeProject.enableDrag = false
	let newStep: ProjectStep = {
		name: r,
		title: "Step Title",
		doctype: "Project Step",
		parent: app.activeProject.doc.name,
		parentfield: "steps",
		parenttype: "StreamWork Project",
		description: 'Add a brief description to the step here.',
		//left: !app.activeProject.activeStep?.left,
		idx: !app.activeProject.emptySteps ? app.activeProject.activeStep?.idx : 0,
		step_number: app.activeProject.emptySteps ? 1 : app.activeProject.activeStep.step_number + 1,
		step_type: 'Standard',
		show_date: 0,
		date_type: 'Milestone',
		return: true,
		isNew: true,
		"__islocal": 1,
		"__unsaved": 1,
		"__unedited": false

	}
	if (!app.activeProject.emptySteps) {
		const idx = app.activeProject.activeStep?.idx

		app.activeProject.doc?.steps.splice(app.activeProject.activeStep.idx, 0, newStep)
	} else {
		app.activeProject.doc?.steps.push(newStep)
		app.activeProject.emptySteps = false
		app.setActiveStep(app.activeProject.doc.steps[app.activeProject.doc.steps.length - 1])
	}


	app.sortSteps(true)

	app.updateProject(false).then(() => {
		const step = app.activeProject.doc.steps.filter((step) => {
			if (step.name == r) {
				return step
			}
		})[0]
		console.info({ step })
		app.setActiveStep(step)
		app.activeProject.enableDrag = true

	})


}

function addLink(link: ProjectLink) {
	app.addLink(link).then(() => {
		app.activeProject.activeButtons = true
	})
}
function addUrl() {
	app.activeProject.activeButtons = false
	if (!app.activeProject.activeStep?.links) {
		app.activeProject.activeStep.links = []
	}
	app.activeProject.activeStep.links.unshift({
		name: '',
		parent: app.activeProject.doc?.name,
		parenttype: 'StreamWork Project',
		parentfield: 'links',
		step: app.activeProject.activeStep?.name,
		type: 'URL',
		url: '',
		isNew: true
	} as ProjectLink)

}

function showUploadingFile() {
	uploadStore.active = true
	app.activeProject.activeButtons = false
}
function closeUploadingFile() {
	uploadStore.active = false
	uploadStore.$reset
	app.activeProject.activeButtons = true
}

function cancelLink() {
	app.activeProject.activeStep?.links?.shift()
	app.activeProject.activeButtons = true

}


function openDropdown(id) {
	const dropdownEl = document.querySelector(id)
	dropdownEl.classList.add('show')
	addEventListener('mouseup', () => {
		dropdownEl.classList.remove('show')
	}, { once: true })

}
function setStep(direction: 'down' | 'up', currentNumber: number) {
	//console.info('Active Step Change', app.activeProject.activeStep)

	let newStep = app.activeProject.doc.steps.filter((step) => {
		let move = direction == 'up' ? -1 : 1
		if (step.step_number == currentNumber + move && step.step_type == 'Standard') {
			return step
		}
	})
	console.info({ newStep })
	if (newStep.length == 1) {
		app.setActiveStep(newStep[0])
	}
	if (newStep.length == 0) {
		app.activeProject.stepLimit = direction == 'down' ? 'bottom' : direction == 'up' ? 'top' : 'mid'
	}
}
onMounted(() => {

})
</script>
<template>
	<div class="col-xl-5 col-lg-6 edit-container">
		<!-- Utility Panel Card -->



		<div class="border-bottom my-2">

		</div>

		<!-- END Utility Panel Card -->

		<!-- Edit Card -->
		<div class="card mb-4 edit-card bg-light" key="editStep">
			<div class="row">


				<div class="col">


					<ul class="nav nav-tabs">
						<li class="nav-item">
							<div role="button" class="nav-link" @click="app.activeProject.activeEditor = 'ProjectInfo'"
								:class="{ active: app.activeProject.activeEditor == 'ProjectInfo' }"><small class="fw-bold">Project
									Info</small>

							</div>
						</li>
						<li class="nav-item">
							<div role="button" class="nav-link" :class="{ active: app.activeProject.activeEditor == 'Steps' }"
								@click="app.activeProject.activeEditor = 'Steps'"><small class="fw-bold">Steps</small>

							</div>
						</li>
						<li class="nav-item">
							<div role="button" class="nav-link" @click="app.activeProject.activeEditor = 'Payments'"
								:class="{ active: app.activeProject.activeEditor == 'Payments' }"><small
									class="fw-bold">Payments</small>

							</div>
						</li>

						<li class="nav-item">
							<div role="button" class="nav-link" @click="app.activeProject.activeEditor = 'Theme'"
								:class="{ active: app.activeProject.activeEditor == 'Theme' }"><small class="fw-bold">Theme &
									Style</small>


							</div>
						</li>

					</ul>

				</div>
				<div class="col-auto">
					<CircleButton size="small" color="red"></CircleButton>
					<button type="button" class="btn sw-bg-gray"
						@click="app.isMobile = !app.isMobile">{{ app.isMobile ? 'Mobile' : 'Desktop' }}</button>
					<div class="btn me-2 save-btn" :class="app.activeProject.isDirty ? 'btn-warning' : 'btn-primary'"
						@mousedown="async () => { await app.updateProject(); app.activeProject.isDirty = false }">
						<Transition name="fade" mode="out-in">

							<font-awesome-icon v-if="app.activeProject.isDirty" icon="fa-solid fa-floppy-disk"></font-awesome-icon>
							<font-awesome-icon v-else icon="fa-solid fa-check"></font-awesome-icon>

						</Transition>

					</div>

				</div>


			</div>
			<div class="card-header bg-white border-bottom p-3">

				<div class="row justify-content-between">
					<div class="col-3">

					</div>
					<div class="col">



						<h5 class="card-title fw-bold text-uppercase text-center">
							<Transition name="fade" mode="out-in">
								<div v-if="app.activeProject.activeEditor == 'ProjectInfo'">
									Project Information

								</div>
								<div v-else-if="app.activeProject.activeEditor == 'Steps'">
									<div v-if="app.activeProject.emptySteps">

										Project Steps

									</div>

									<span v-else>
										{{ 'Editing Step ' + app.activeProject.activeStep?.step_number }}
									</span>


								</div>
								<div v-else-if="app.activeProject.activeEditor == 'Payments'">
									Payments

								</div>

								<div v-else-if="app.activeProject.activeEditor == 'Theme'">
									Theme & Style

								</div>
							</Transition>

						</h5>


					</div>
					<Transition name="fade">
						<div v-if="app.activeProject.activeEditor == 'Steps' && !app.activeProject.emptySteps"
							class="col-auto toolbar-buttons">




							<div class="btn sw-bg-gray"
								:class="app.activeProject.stepLimit == 'top' || app.activeProject.stepLimit == 'both' ? 'disabled' : ''"
								@mousedown="setStep('up', app.activeProject.activeStep.step_number)">
								<font-awesome-icon icon="fa-solid fa-arrow-up"></font-awesome-icon>

							</div>
							<div class="btn sw-bg-gray"
								:class="app.activeProject.stepLimit == 'bottom' || app.activeProject.stepLimit == 'both' ? 'disabled' : ''"
								@mousedown="setStep('down', app.activeProject.activeStep.step_number)">
								<font-awesome-icon icon="fa-solid fa-arrow-down"></font-awesome-icon>

							</div>
							<div class="btn btn-dark" @mousedown="addStep()">
								<font-awesome-icon icon="fa-solid fa-plus"></font-awesome-icon>

							</div>
							<div class="btn btn-danger" @mousedown="app.deleteActiveStep()">
								<font-awesome-icon icon="fa-solid fa-trash"></font-awesome-icon>

							</div>

						</div>
					</Transition>

					<div v-if="app.activeProject.emptySteps || app.activeProject.activeEditor != 'Steps'" class="col-3">

					</div>


				</div>


			</div>

			<div class="card-body"
				:class="app.activeProject.activeEditor == 'Steps' && app.activeProject.emptySteps ? 'empty-bg' : 'bg-white'">
				<Transition name="slide-fade" mode="out-in">
					<div v-if="app.activeProject.activeEditor == 'Steps'" class="steps-container">
						<Transition name="fade" mode="out-in">
							<div v-if="!app.activeProject.emptySteps" class="row p-3 mb-5 justify-content-center edit-row">
								<div class="col-12">

									<div class="row justify-content-between mb-2">
										<Transition name="slide-fade">

											<ProjectIconSelector v-if="app.activeProject.iconSelectorActive">

											</ProjectIconSelector>
										</Transition>
										<div class="col-auto">

											<div role="button" class="edit-icon-wrapper img-thumbnail"
												:style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.activeStep.icon_url + '\')'"
												@click="app.activeProject.iconSelectorActive = true">
												<Transition name="slide-fade" mode="out-in">

													<div v-if="!app.activeProject.activeStep.icon_url" class="icon-placeholder">

													</div>
												</Transition>


											</div>




										</div>

										<div class="col">
											<label class="input-label">Step Title</label>
											<div class="input-group mb-2">
												<span class="input-group-text">{{ app.activeProject.activeStep?.step_number }}</span>



												<input v-model="app.activeProject.activeStep.title" type="text" class="form-control"
													aria-label="Step Title" :aria-describedby="app.activeProject.activeStep.name">

											</div>
											<TimeField></TimeField>

										</div>


									</div>

									<div class="row">
										<div class="col-12">
											<div class="mb-3">
												<label :for="app.activeProject.activeStep.name" class="input-label">Description</label>
												<textarea v-model="app.activeProject.activeStep.description" class="form-control"
													:id="app.activeProject.activeStep.name" rows="4" maxlength="500"></textarea>

											</div>


										</div>


									</div>

									<div class="border-bottom">

									</div>
									<div class="row justify-content-center">
										<div class="col-auto p-2">
											<h5 class="fw-bold text-primary">Links</h5>

										</div>




									</div>
									<div class="row">
										<div class="col-auto">
											<button class="btn btn-sm fw-bold me-2"
												:class="{ 'btn-dark': app.activeProject.activeButtons, 'btn-secondary': !app.activeProject.activeButtons }"
												:disabled="!app.activeProject.activeButtons" @click="addUrl">
												<font-awesome-icon icon="fa-solid fa-plus"></font-awesome-icon>
												URL
											</button>
											<!-- <Link></Link> -->
											<!-- <LinkButtonSmall @click="addUrl"></LinkButtonSmall> -->
											<button class="btn btn-sm fw-bold text-white"
												:class="{ 'btn-dark': app.activeProject.activeButtons, 'btn-secondary': !app.activeProject.activeButtons }"
												:disabled="!app.activeProject.activeButtons" @click="showUploadingFile">
												<font-awesome-icon icon="fa-solid fa-plus"></font-awesome-icon>
												File
											</button>
											<!-- <FileButtonSmall @click="showUploadingFile"></FileButtonSmall> -->

										</div>

									</div>
									<Transition name="slide-fade" mode="out-in">
										<div v-if="uploadStore.active" class="row border rounded py-2 mt-2">
											<div class="col-6">
												<FileUploader :allowReplace="true" stylePanelLayout="integrate" stylePanelAspectRatio="null"
													:instantUpload="false" :uploadFunction="app.createProjectStepFile" :uploadFunctionArgs="{
														project: app.activeProject.doc.name,
														stepName: app.activeProject.activeStep.name,
														title: uploadStore.fileTitle,
														fileUrl: uploadStore.fileUrl

													}">

												</FileUploader>

											</div>
											<div class="col-6">
												<div class="row my-2">

													<div class="col">
														<input v-model="uploadStore.fileTitle" type="text" class="form-control"
															placeholder="Display Title" />

													</div>




												</div>
												<div class="row">
													<div>
														{{ uploadStore.fileType }}

													</div>
													<div>
														{{ uploadStore.fileName }}

													</div>
													<div>
														{{ uploadStore.fileExtension }}

													</div>

												</div>
												<div class="row justify-content-center">
													<div class="col-auto">
														<button class="btn btn-primary fw-bold" @click="uploadStore.uploadFile()"
															:disabled="!uploadStore.ready">Upload</button>

													</div>
													<div class="col-auto">
														<button class="btn btn-dark fw-bold" @click="closeUploadingFile">Cancel</button>

													</div>

												</div>

											</div>


										</div>
										<div v-else class="row mb-3">
											<div class="col mt-2">
												<TransitionGroup name="list-pop" tag="ul" class="list-group">
													<li class="list-group-item" v-for="link in app.activeProject.activeStep.links"
														:key="link.name">

														<div class="row justify-content-between">

															<div class="col">


																<div class="row">
																	<div class="col-auto">
																		<span class="badge"
																			:class="{ 'bg-info': link.type == 'File', 'bg-warning': link.type == 'URL' }">{{ link.type }}
																		</span>

																	</div>
																	<div v-if="link.isNew" class="col">
																		<div class="row">
																			<div class="col-6">
																				<input v-model="link.title" type="text" class="form-control"
																					placeholder="Link Name" />

																			</div>
																			<div class="col-6">
																				<input v-model="link.url" type="text" class="form-control" placeholder="URL" />

																			</div>

																		</div>



																	</div>
																	<div v-else class="col-auto">
																		<div class="fw-bold">
																			{{ link.title }}

																		</div>

																	</div>


																</div>
																<div v-if="!link.isNew" class="row">

																	<div class="col-auto">


																		<div v-if="link.type == 'File'" class="text-truncate">
																			<a :href="app.staticHostUrl + link.file" target="_blank"><small>
																					{{ link.file?.replace('/files/', '') }}</small></a>

																		</div>
																		<div v-else class="text-truncate">
																			<a :href="link.url" target="_blank"><small>{{ link.url }}</small>
																			</a>

																		</div>

																	</div>


																</div>


															</div>
															<div v-if="link.isNew" class="col-auto">
																<button class="btn btn-primary" @click="addLink(link)">
																	<font-awesome-icon icon="fa-solid fa-check">
																	</font-awesome-icon>

																</button>
																<button class="btn btn-dark mx-2" @click="cancelLink()">
																	<font-awesome-icon icon="fa-solid fa-xmark">
																	</font-awesome-icon>

																</button>

															</div>
															<div v-else class="col-auto">

																<button class="btn btn-danger" @click="app.deleteLink(link)">

																	<font-awesome-icon icon="fa-solid fa-trash">
																	</font-awesome-icon>
																</button>

															</div>

														</div>


													</li>
												</TransitionGroup>

											</div>

										</div>



									</Transition>

								</div>


							</div>
							<div v-else class="empty-step-container text-center">
								<div class="btn btn-dark" @mousedown="addStep()">
									<font-awesome-icon icon="fa-solid fa-plus"></font-awesome-icon>


								</div>
								<br>
								<div class="py-3">Create your first step

								</div>

							</div>
						</Transition>

					</div>
					<!-- End steps card-->
					<div v-else-if="app.activeProject.activeEditor == 'Payments'">

						<ul class="list-group">
							<draggable v-model="app.activeProject.doc.payments" animation="150" group="mainGroup"
								easing="cubic-bezier(1, 0, 0, 1)" :group="{ name: 'steps', pull: true, put: true }" sort="true"
								forceFallback="true" @change="log" ghost-class="ghost">
								<li class="list-group-item" v-for="step in app.activeProject.doc?.steps.filter((step) => {
									if (step.step_type == 'Payment') {
										return step
									}

								})" :key="step.name">

									<div class="form-check">
										<input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"
											:checked="step.percent">
										<label class="form-check-label" for="flexRadioDefault1">
											Show %
										</label>

									</div>
									<div class="form-check">
										<input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
										<label class="form-check-label" for="flexRadioDefault2">
											Show Currency
										</label>

									</div>
									<div class="form-check form-switch">
										<input v-model="step.show_amount" class="form-check-input" type="checkbox" role="switch"
											id="flexSwitchCheckDefault">
										<label class="form-check-label" for="flexSwitchCheckDefault">Show Amount</label>

									</div>
									<div v-if="step.show_amount == 1" class="input-group mb-3">
										<span class="input-group-text">$</span>
										<input v-model="step.amount" type="text" class="form-control"
											aria-label="Amount (to the nearest dollar)">


									</div>
									<div class="form-check form-switch">
										<input v-model="step.show_date" class="form-check-input" type="checkbox" role="switch"
											id="flexSwitchCheckDefault">
										<label class="form-check-label" for="flexSwitchCheckDefault">Show Date</label>

									</div>
								</li>
							</draggable>
						</ul>




					</div>
					<div v-else-if="app.activeProject.activeEditor == 'ProjectInfo'">
						<div class="row mb-3">
							<div class="col">
								<div class="row mb-3">
									<div class="col-md-12">
										<label :for="app.activeProject.doc.project_name" class="form-label">Project Name</label>
										<input v-model="app.activeProject.doc.project_name" type="text" class="form-control"
											:id="app.activeProject.doc.project_name" />

									</div>

								</div>
								<div class="row">
									<div class="col-md-12">

										<label :for="app.activeProject.doc.title" class="form-label">Stream Board
											Title</label>
										<input v-model="app.activeProject.doc.title" type="text" class="form-control"
											:id="app.activeProject.doc.title">

									</div>

								</div>

							</div>
							<div class="col">
								<div class="row mb-3">
									<div class="col-md-12">
										<label :for="app.activeProject.doc?.client" class="form-label">Client</label>
										<input v-model="app.activeProject.doc.client" type="text" class="form-control"
											:id="app.activeProject.doc.client" />

									</div>

								</div>
								<div class="row">
									<div class="col-md-12">

										<label :for="app.activeProject.doc?.contact_person_name" class="form-label">Contact Name</label>
										<input v-model="app.activeProject.doc.contact_person_name" type="text" class="form-control"
											:id="app.activeProject.doc.contact_person_name">

									</div>

								</div>
								<div class="row">
									<div class="col-md-12">

										<label :for="app.activeProject.doc?.contact_email" class="form-label">Contact Email</label>
										<input v-model="app.activeProject.doc.contact_email" type="text" class="form-control"
											:id="app.activeProject.doc.contact_email">

									</div>

								</div>

							</div>


						</div>
						<div class="row position-relative">

							<div class="col-md-7">



								<div class="mb-3 quill-container">
									<label class="form-label">Stream Board Description</label>

									<QuillEditor class="quill-or" @update:content="quillUpdated()" @ready="quillReady()" ref="quill"
										v-model:content="app.activeProject.doc.description" theme="snow" />

								</div>

							</div>



							<div class="col-md-5">
								<div class="row">
									<div class="col">


										<label class="form-label">Cover Image</label>
										<div role="button" class="project-icon-wrapper img-thumbnail"
											:style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.doc.cover_image_url + '\')'"
											@click="selectProjectIcon({ isCover: true, isFooter: false })">
											<Transition name="slide-fade" mode="out-in">

												<div v-if="!app.activeProject.doc.cover_image_url" class="icon-placeholder">

												</div>
											</Transition>


										</div>

									</div>

								</div>
								<div class="row">

									<div class="col">
										<label class="form-label">Footer Image</label>
										<div role="button" class="project-icon-wrapper img-thumbnail"
											:style="'background-image:url(\'' + app.staticHostUrl + app.activeProject.doc.footer_image_url + '\')'"
											@click="selectProjectIcon({ isCover: false, isFooter: true })">
											<Transition name="slide-fade" mode="out-in">

												<div v-if="!app.activeProject.doc.footer_image_url" class="icon-placeholder">

												</div>
											</Transition>


										</div>

									</div>

								</div>


							</div>
							<Transition name="slide-fade">


								<div v-if="app.activeProject.showProjectIcons" class="cover-footer-icon-selector">
									<ProjectIconSelector :isCover="updateCover" :isFooter="updateFooter"></ProjectIconSelector>

								</div>
							</Transition>

						</div>

					</div>
					<!-- Start Theme Editor -->
					<div v-else-if="app.activeProject.activeEditor == 'Theme'">
						<div class="row">
							<div class="col-6">

								<ul class="list-group" id="palette">

									<li v-for="palette in app.colorPalettes" :key="palette.name" class="list-group-item palette-button"
										@click="theme.setPalette(palette, true)">
										<div class="container-fluid">


											<div class="row justify-content-center p-0">
												<div class="col palette-sample" :style="{ backgroundColor: palette.background }">

												</div>
												<div class="col palette-sample" :style="{ backgroundColor: palette.step_background }">

												</div>
												<div class="col palette-sample" :style="{ backgroundColor: palette.primary }">

												</div>
												<div class="col palette-sample" :style="{ backgroundColor: palette.secondary }">

												</div>
												<div class="col palette-sample" :style="{ backgroundColor: palette.text }">

												</div>
												<div class="col palette-sample" :style="{ backgroundColor: palette.info }">

												</div>
												<div class="col palette-sample" :style="{ backgroundColor: palette.contact }">

												</div>

											</div>

										</div>
									</li>

								</ul>

							</div>
							<div class="col">


								<div class="row">
									<div class="col icon-box" v-for="icon in app.activeProject.icons" :key="icon.name">
										<img class="img-fluid img-thumbnail" :src="app.staticHostUrl + icon.icon" />

									</div>

								</div>





							</div>

						</div>

					</div>
				</Transition>

			</div>


		</div>
		<!-- End Edit Card -->



	</div>
</template>


<style lang="scss" scoped>
.cover-footer-icon-selector {
	position: absolute;
	top: 0;
	left: 0;
	transition: all 0.15s ease;
}

.edit-icon-wrapper {
	width: 160px;
	height: 160px;
	background-repeat: no-repeat;
	background-size: contain;
	background-position: 50%;
	transition: all 0.15s ease;
}

.project-icon-wrapper {
	width: 100%;
	height: 160px;
	background-repeat: no-repeat;
	background-size: contain;
	background-position: 50%;
	transition: all 0.15s ease;
}

.btn-danger {
	color: white !important;
}

.btn-dark {
	background-color: #292140;
}

.toolbar-buttons .btn {

	margin: 0 0.2rem;
	transition: all 0.1s ease-out;
}

.sw-bg-gray {
	border: none;
	color: white !important;
	background-color: #9EAEBC !important;
}

.toolbar-buttons .btn:hover {
	border-color: transparent !important;

	transform: scale(1.1);
}

.toolbar-buttons .btn.sw-bg-gray:active {
	background-color: #7b838a !important;
}

.toolbar-buttons .btn:active {

	transform: scale(1);
}

.edit-icon-wrapper.img-thumbnail {
	height: 160px;
}

.edit-icon-wrapper:hover,
.project-icon-wrapper:hover {
	transform: scale(1.1);
}



.icon-box {
	transition: all 0.2s ease;
}

.icon-box:hover {
	transform: scale(1.2);
	cursor: pointer;
}

.nav-tabs .nav-link {
	background-color: transparent;
	color: var(--bs-text-muted);
	transition: all 0.3s ease;

}

.edit-container {
	height: calc(100vh - var(--header-height) - (var(--main-container-padding)*2));
	overflow: hidden;
}

.btn-circle {
	border-radius: 50% !important;
}

.edit-icon-wrapper {
	width: 160px;
	height: 120px;
}

.icon-placeholder {
	width: 100%;
	height: 90%;
	border-radius: var(--bs-border-radius);
	background-color: var(--bs-light);
}

.edit-row label {
	font-size: small;
	font-weight: bold;
	color: var(--bs-primary);

}


.edit-card .card-body {
	min-height: calc(100% + 50px)
}

.edit-card {
	min-height: calc(100vh - var(--header-height) - (var(--main-container-padding)*2) - var(--edit-toolbar-height));
}


.palette-button:hover {
	cursor: pointer;
	background-color: var(--bs-dark)
}

.palette-button {
	padding: 0.2rem;
	margin-bottom: 0.5rem;
	;
}

.palette-sample {
	width: 20px;
	height: 20px;
	padding: 0;
}

.edit-btn {
	color: white;
	//position: absolute;
	width: 50px;
	border-radius: 10px 0 0 10px;
	//left: -10px
}

.quill-container {
	height: 250px !important;
}

.ql-toolbar.ql-snow {
	border-radius: var(--bs-border-radius);
}

.ql-editor {
	box-shadow: inset 0 0 5px rgba(107, 164, 150, 0.22);
	background-color: var(--bs-light);
}

.save-btn {
	transition: all 0.2s ease-in-out;
}

.empty-step-container {
	position: absolute;
	top: 50%;
	width: 100%;

}

.empty-bg {
	background-color: #f2f2f2;
	box-shadow: inset 0 0 4px 1px #9a9ea28c;
}
</style>