<template>
	<div class="main-element elv-6 bg-white px-3 py-2 position-absolute">

		<div class="col-6">
			<FileUploader :allowReplace="true"
										stylePanelLayout="integrate"
										stylePanelAspectRatio="null"
										:instantUpload="false"
										:uploadFunction="app.createProjectStepFile"
										:uploadFunctionArgs="{
											project: app.activeProject.doc.name,
											stepName: app.activeProject.activeStep.name,
											title: uploadStore.fileTitle,
											fileUrl: uploadStore.fileUrl
										
										}">

			</FileUploader>

		</div>
		<div class="col-6 ps-3">
			<div class="row">

				<div class="col">
					<input v-model="uploadStore.fileTitle"
								 type="text"
								 class="form-control border-none"
								 placeholder="Display Title" />

				</div>




			</div>
			<div class="row">
				<div class="col py-2">

					<!-- <div>
															{{ uploadStore.fileType }}

													</div> -->
					<div class="text-xs fw-bold text-primary">
						{{ uploadStore.fileName }}

					</div>
					<!-- <div>
														{{ uploadStore.fileExtension }}

													</div> -->

				</div>

			</div>
			<div class="row justify-content-center">
				<div class="col-auto">
					<div class="btn-circle bg-primary text-center text-white"
							 @click="uploadStore.uploadFile()"
							 :disabled="!uploadStore.ready">
						<font-awesome-icon icon="fa-solid fa-upload"></font-awesome-icon>

					</div>

				</div>
				<div class="col-auto">
					<div class="btn-circle bg-secondary text-center text-white"
							 @click="closeUploadingFile">
						<font-awesome-icon icon="fa-solid fa-xmark"></font-awesome-icon>

					</div>

				</div>

			</div>

		</div>




	</div>
</template>

<script setup lang="ts">
import { useFileUploader, useStore } from '@/stores/stores';
import type { ProjectLink } from '@/types/docTypes';
import { storeToRefs } from 'pinia';
import FileUploader from '../FileUploader.vue';
import InputField from './InputField.vue';

const app = useStore()
const { activeProject } = storeToRefs(app)
const uploadStore = useFileUploader()

function cancelLink() {
	app.activeProject.newLink = {} as ProjectLink
	app.activeProject.showNewLink = false
	app.activeProject.activeButtons = true

}
</script>

<style lang="scss" scoped>
.main-element {
	z-index: 100;
	border-radius: var(--bs-border-radius);
}
</style>