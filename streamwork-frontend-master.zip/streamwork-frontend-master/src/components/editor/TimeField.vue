<template>


	<div class="row my-2 justify-content-center">
		<div class="col">
			<input v-model="step.duration"
						 type="number"
						 class="form-control number-input" />

		</div>
		<div class="col-auto g-0">
			<div class="input-group mb-3">



				<div class="btn-group"
						 role="group"
						 aria-label="Basic radio toggle button group">

					<input type="radio"
								 class="btn-check"
								 id="days"
								 value="Days"
								 v-model="step.duration_type" />
					<label class="btn  btn-outline-time"
								 for="days">Days</label>

					<input type="radio"
								 class="btn-check"
								 id="weeks"
								 value="Weeks"
								 v-model="step.duration_type" />
					<label class="btn btn-outline-time"
								 for="weeks">Weeks</label>

					<input type="radio"
								 class="btn-check"
								 id="months"
								 value="Months"
								 v-model="step.duration_type" />
					<label class="btn  btn-outline-time"
								 for="months">Months</label>

				</div>

			</div>

		</div>

	</div>
	<div class="row">

		<div class="col-auto">
			<div class="form-check form-switch">
				<input v-model="show_dates"
							 class="form-check-input"
							 type="checkbox"
							 role="switch"
							 id="flexSwitchCheckChecked"
							 checked>
				<label class="form-check-label"
							 for="flexSwitchCheckChecked">Use Dates</label>

			</div>

		</div>

	</div>
	<Transition name="fade">


		<div v-if="show_dates"
				 class="row">

			<div v-if="app.activeProject.activeStep.date_type == 'Milestone'"
					 class="col">
				<Datepicker v-model="step.start_date"
										autoApply
										:enableTimePicker="false"
										:format="format"
										@update:modelValue="handleDate"></Datepicker>

			</div>
			<div v-else-if="app.activeProject.activeStep.date_type == 'Range'"
					 class="col">
				<Datepicker v-model="rangeDate"
										autoApply
										:enableTimePicker="false"
										@update:modelValue="handleRangeDate"
										range
										:format="formatRangeDate"></Datepicker>

			</div>
			<div class="col-auto">


				<div class="form-check">
					<input v-model="dateType"
								 value="Milestone"
								 class="form-check-input"
								 type="radio"
								 id="milestone">
					<label class="form-check-label"
								 for="milestone">
						Milestone
					</label>

				</div>
				<div class="form-check">
					<input v-model="dateType"
								 value="Range"
								 class="form-check-input"
								 type="radio"
								 id="range">
					<label class="form-check-label"
								 for="range">
						Range
					</label>

				</div>

			</div>

		</div>

	</Transition>


</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
import { onMounted, ref, watch } from 'vue';
import Datepicker from '@vuepic/vue-datepicker';
import type { MM, DD } from '@/types/docTypes';
import '@vuepic/vue-datepicker/dist/main.css'
import { computed } from '@vue/reactivity';
const app = useStore()
const step = ref(app.activeProject.activeStep)
const rangeDate = ref()

const dateType = ref()

const initialDuration = step.value.duration
const durationInput = ref(initialDuration)
const show_dates = ref()
/* this computes the input duration number into the baseline days based on the selected duration type */
const duration = computed(() => {
	const multiplier = {
		Days: 1,
		Weeks: 7,
		Months: 30
	}
	let multiplyByThis = multiplier[step.value.duration_type]
	return durationInput.value * multiplyByThis;
})

const format = (date: Date) => {


	return formatDate(date)
}
const formatRangeDate = (date: Date[]) => {

	return formatDate(date[0]) + formatDate(date[1])
}

function formatDate(date: Date) {
	const stringDate = date.toDateString();
	console.info(stringDate);
	const day = stringDate.substring(8, 10)
	const month = stringDate.substring(4, 8)
	const year = date.getFullYear()
	let formatted = `${month}${day}, ${year}`
	return formatted
}

const handleDate = (modelData: Date) => {

	app.activeProject.activeStep.start_date = modelData.toISOString().substring(0, 10)
	// do something else with the data
}
const handleRangeDate = (modelData: Date[]) => {
	app.activeProject.activeStep.start_date = modelData[0].toISOString().substring(0, 10)
	app.activeProject.activeStep.due_date = modelData[1].toISOString().substring(0, 10)
	console.info(app.activeProject.activeStep.start_date, app.activeProject.activeStep.due_date)

	// do something else with the data
}

function saveDate(inputDate: Date) {
	console.info('json', inputDate.toISOString().substring(0, 10))
	const stringDate = inputDate.toDateString();
	console.info(stringDate);
	const day = stringDate.substring(8, 10)
	const month = stringDate.substring(4, 8)
	const year = inputDate.getFullYear()
	let formatted = `${year}-${month}-${day}`
	return formatted
}
function fillZero(input: number): string {

	if (input.toString().length == 1) {

		return `0${input.toString()}`;
	} else {
		return input.toString();
	}
}

onMounted(() => {
	refreshStep()
})

watch(show_dates, (newValue) => {

	step.value.show_date = show_dates.value ? 1 : 0

})

watch(dateType, (newValue) => {
	// console.info({ dateType, newValue })
	app.activeProject.activeStep.date_type = newValue
})

watch(() => app.activeProject.isSaving, (newValue) => {
	console.info({ name: newValue })
	refreshStep()
})

watch(() => app.activeProject.activeStep.name, (newValue) => {
	// console.info({ name: newValue })
	refreshStep()
})

watch(durationInput, (newValue) => {
	app.activeProject.activeStep.duration = newValue
})
function refreshStep() {
	durationInput.value = app.activeProject.activeStep.duration
	step.value = app.activeProject.activeStep
	show_dates.value = app.activeProject.activeStep.show_date ? true : false;
	dateType.value = app.activeProject.activeStep.date_type
	rangeDate.value = [app.activeProject.activeStep.start_date, app.activeProject.activeStep.due_date]
}
</script>

<style land="scss" scoped>
.btn-outline-primary {
	--bs-btn-active-color: #FFF;
}

.btn-outline-primary:checked {
	color: white;

}

.btn-check:checked+.btn {
	color: var(--bs-primary);
}

.btn:hover {
	color: white;
}

.btn:active {
	color: white;
}

.btn:focus {
	color: white;
}

.form-control.number-input {
	box-shadow: none !important;
}

.number-input {
	height: 49px !important;

}

.dp__theme_light {
	--dp-background-color: #ffffff;
	--dp-text-color: #212121;
	--dp-hover-color: #f3f3f3;
	--dp-hover-text-color: #212121;
	--dp-hover-icon-color: #959595;
	--dp-primary-color: #1976d2;
	--dp-primary-text-color: #f8f5f5;
	--dp-secondary-color: #c0c4cc;
	--dp-border-color: #ddd;
	--dp-menu-border-color: #ddd;
	--dp-border-color-hover: #aaaeb7;
	--dp-disabled-color: #f6f6f6;
	--dp-scroll-bar-background: #f3f3f3;
	--dp-scroll-bar-color: #959595;
	--dp-success-color: #76d275;
	--dp-success-color-disabled: #a3d9b1;
	--dp-icon-color: #959595;
	--dp-danger-color: #ff6f60;
	--dp-highlight-color: rgba(25, 118, 210, 0.1);
}

.btn-outline-time.active {
	color: var(--bs-primary) !important;
}

.btn.btn-outline-time {
	min-width: unset;
}

.btn-outline-time {
	height: 49px;
	vertical-align: center;
	text-align: center;
	--bs-btn-color: #26274F80;
	--bs-btn-border-color: #D4D3D8;
	--bs-btn-hover-color: #000;
	--bs-btn-hover-bg: var(--bs-success);
	--bs-btn-hover-border-color: var(--bs-success);
	--bs-btn-focus-shadow-rgb: 235, 237, 245;
	--bs-btn-active-color: var(--bs-primary);
	--bs-btn-active-bg: var(--bs-success);
	--bs-btn-active-border-color: #EBEDF5;
	--bs-btn-active-shadow: none;
	--bs-btn-disabled-color: #EBEDF5;
	--bs-btn-disabled-bg: transparent;
	--bs-btn-disabled-border-color: #EBEDF5;
	--bs-gradient: none;
}

.label-title {
	font-size: small;
	font-weight: bold;
	color: var(--bs-primary);
}

.btn-group {
	width: 1;
}

.btn {
	padding-left: 1rem !important;
	padding-right: 1rem !important;
}

.form-control {
	border: 1px solid rgba(82, 78, 97, 0.25);
	border-radius: 10px;
}

input.form-control {
	height: 38px;


}
</style>