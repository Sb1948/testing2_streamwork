<template>
	<div class="form-floating mb-3">
		<input @input="onInput"
					 type="text"
					 class="form-control"
					 :name="text.replace(' ','')"
					 :id="text.replace(' ','')"
					 v-model="inputValue"
					 :placeholder="text">
		<label :for="'floating' + text.replace(' ', '')">{{ text }}</label>

	</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';


const emit = defineEmits(['updateInput'])


const props = defineProps<{
	text: string,
	initValue?: string
}>()
const inputValue = ref(props.initValue)
function onInput() {
	emit('updateInput', inputValue)
}



</script>

<style lang="scss" scoped>
.form-floating>.form-control:focus~label,
.form-floating>.form-control:not(:placeholder-shown)~label,
.form-floating>.form-control-plaintext~label,
.form-floating>.form-select~label {
	opacity: 1;
	transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
}

.form-floating>label {
	font-weight: 700;
	font-size: 0.85rem;
	color: #26274F80;
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	padding: 0.75rem 0.75rem;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
	pointer-events: none;
	border: 1px solid transparent;
	transform-origin: 0 0;
	transition: opacity 0.1s ease-in-out, transform 0.1s ease-in-out;
}

.form-floating>.form-control,
.form-floating>.form-control-plaintext,
.form-floating>.form-select {
	height: 49px;
	line-height: 1.25;
}

.form-control {
	background-color: white;
	border-radius: 6px;
	border: 1px solid #D4D3D8;
}

.form-control:focus {
	border-color: #D4D3D8;
	box-shadow: none;
	background-color: white;

}
</style>