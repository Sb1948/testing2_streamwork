<template>
	<li class="list-group-item mb-2">
		<div class="row justify-content-between">
			<div class="col-auto">
				<div class="fw-bold text-gray type">
					{{ link.type }}

				</div>
				<div v-if="link.type == 'File'"
						 class="text-truncate">
					<a :href="app.staticHostUrl + link.file"
						 target="_blank"><small>
							{{ link.title || link.file?.replace('/files/', '') }}</small></a>

				</div>
				<div v-else
						 class="text-truncate">
					<a :href="link.url"
						 target="_blank"><small>{{ link.title||link.url }}</small>
					</a>

				</div>

			</div>
			<div class="col-auto d-flex align-items-center">
				<div class="edit-icon me-2">

					<svg width="24"
							 height="24"
							 viewBox="0 0 24 24"
							 fill="none"
							 xmlns="http://www.w3.org/2000/svg">
						<g clip-path="url(#clip0_185_1080)">
							<path d="M22.1511 15.0766C21.8209 15.0766 21.5533 15.3442 21.5533 15.6743V20.9815C21.5522 21.9714 20.7501 22.7737 19.7602 22.7746H2.98862C1.99864 22.7737 1.19662 21.9714 1.19545 20.9815V5.40537C1.19662 4.41562 1.99864 3.61336 2.98862 3.6122H8.29576C8.62591 3.6122 8.89348 3.34462 8.89348 3.01447C8.89348 2.68456 8.62591 2.41675 8.29576 2.41675H2.98862C1.33881 2.41862 0.00186789 3.75556 0 5.40537V20.9817C0.00186789 22.6315 1.33881 23.9684 2.98862 23.9703H19.7602C21.41 23.9684 22.7469 22.6315 22.7488 20.9817V15.6743C22.7488 15.3442 22.4812 15.0766 22.1511 15.0766Z"
										fill="#26274F" />
							<path d="M22.5121 0.878783C21.4616 -0.171671 19.7586 -0.171671 18.7081 0.878783L8.04433 11.5426C7.97124 11.6156 7.91848 11.7062 7.89093 11.8057L6.48861 16.8684C6.43094 17.0759 6.48954 17.2982 6.64178 17.4507C6.79424 17.6029 7.01652 17.6615 7.22409 17.6041L12.2868 16.2015C12.3862 16.174 12.4768 16.1212 12.5499 16.0481L23.2134 5.38413C24.2623 4.33298 24.2623 2.63133 23.2134 1.58017L22.5121 0.878783ZM9.34671 11.9311L18.0742 3.20337L20.8889 6.01804L12.1612 14.7458L9.34671 11.9311ZM8.78448 13.0593L11.0332 15.3082L7.92268 16.17L8.78448 13.0593ZM22.3682 4.53891L21.7343 5.17283L18.9194 2.35792L19.5536 1.724C20.137 1.14052 21.0831 1.14052 21.6666 1.724L22.3682 2.42539C22.9508 3.00958 22.9508 3.95496 22.3682 4.53891Z"
										fill="#26274F" />
						</g>
						<defs>
							<clipPath id="clip0_185_1080">
								<rect width="24"
											height="24"
											fill="white" />
							</clipPath>
						</defs>
					</svg>

				</div>

				<div class="delete-button text-center"
						 @click="app.deleteLink(link, index)">
					<font-awesome-icon icon="fa-solid fa-xmark"
														 class="xmark"></font-awesome-icon>


				</div>

			</div>


		</div>

	</li>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
import type { ProjectLink } from '@/types/docTypes';

const app = useStore()

defineProps<{
	link: ProjectLink
	index: number
}>()

</script>

<style lang="scss" scoped>
a {
	color: var(--bs-success);
}

.edit-icon {
	display: inline-block;
	cursor: pointer;
}

.delete-button {
	width: 17px;
	height: 17px;
	display: inline-block;
	font-size: 10px;
	line-height: 17px;

	cursor: pointer;
	background-color: var(--bs-primary);
	border-radius: 50%;
	color: white;
}

.list-group-item {
	border: 1px solid #D4D3D8 !important;
	border-radius: var(--bs-border-radius) !important;
	padding: 5px 16px;
}

.type {
	font-size: 0.8rem;
}
</style>