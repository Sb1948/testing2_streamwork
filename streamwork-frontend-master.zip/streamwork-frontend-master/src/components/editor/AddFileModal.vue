<template>
	<div class="overlay-bg"
			 @click.self="closeUploadingFile()">


		<div class="main-element elv-6 bg-white px-3 py-2 position-absolute">

			<div class="row justify-content-between mb-2">
				<div class="col-auto">
					<div class="fw-bold d-flex flex-shrink">
						Add File

					</div>

				</div>

				<div class="col-auto text-xs fw-bold text-primary">
					{{ uploadStore.fileName }}

				</div>

				<div role="button"
						 class="col-auto align-items-start"
						 @click="closeUploadingFile()">
					<svg width="12"
							 height="12"
							 viewBox="0 0 12 12"
							 fill="none"
							 xmlns="http://www.w3.org/2000/svg">
						<g clip-path="url(#clip0_119_3402)">
							<path d="M0.586047 0.000288963C0.470144 0.000267029 0.356837 0.0346203 0.26046 0.0990019C0.164083 0.163384 0.0889654 0.254904 0.0446082 0.361983C0.000250996 0.469063 -0.0113527 0.586892 0.0112649 0.700567C0.0338824 0.814242 0.0897052 0.918656 0.171672 1.0006L10.9998 11.8287C11.1097 11.9386 11.2588 12.0004 11.4142 12.0004C11.5696 12.0004 11.7186 11.9386 11.8285 11.8287C11.9384 11.7188 12.0002 11.5698 12.0002 11.4144C12.0002 11.2589 11.9384 11.1099 11.8285 11L1.00042 0.171852C0.946056 0.117373 0.881462 0.074172 0.810351 0.0447302C0.739239 0.0152884 0.663012 0.000185013 0.586047 0.000288963Z"
										fill="#26274F" />
							<path d="M11.4141 0.000288963C11.3372 0.000185013 11.2609 0.0152884 11.1898 0.0447302C11.1187 0.074172 11.0541 0.117373 10.9998 0.171852L0.17164 11C0.0617407 11.1099 0 11.2589 0 11.4144C0 11.5698 0.0617407 11.7188 0.17164 11.8287C0.281539 11.9386 0.430594 12.0004 0.586015 12.0004C0.741436 12.0004 0.890491 11.9386 1.00039 11.8287L11.8285 1.0006C11.9105 0.918656 11.9663 0.814242 11.9889 0.700567C12.0115 0.586892 11.9999 0.469063 11.9556 0.361983C11.9112 0.254904 11.8361 0.163384 11.7397 0.0990019C11.6433 0.0346203 11.53 0.000267029 11.4141 0.000288963Z"
										fill="#26274F" />
						</g>
						<defs>
							<clipPath id="clip0_119_3402">
								<rect width="12"
											height="12"
											fill="white"
											transform="matrix(1 0 0 -1 0 12)" />
							</clipPath>
						</defs>
					</svg>


				</div>

			</div>

			<div class="d-flex flex-row flex-grow-1 mx-2 align-items-center">

				<div class="form-floating mb-3">
					<input type="text"
								 class="form-control"
								 name="Label"
								 id="Label"
								 v-model="uploadStore.fileTitle"
								 placeholder="File Title">
					<label for="floatingLabel">File Title</label>

				</div>
				<div class="btn-square btn-square-success ms-2 mb-3 text-center text-white"
						 @click="uploadStore.uploadFile()"
						 :class="!uploadStore.ready || uploadStore.fileTitle == '' ? 'disabled' : ''">
					<font-awesome-icon icon="fa-solid fa-upload"></font-awesome-icon>

				</div>



			</div>
			<!-- 
			<FileUploader :allowReplace="true"
										stylePanelLayout="integrate"
										stylePanelAspectRatio="null"
										:instantUpload="false"
										:uploadFunction="app.createProjectStepFile"
										:uploadFunctionArgs="{
											project: app.activeProject.doc.name,
											stepName: app.activeProject.activeStep.name,
											title: uploadStore.fileTitle,
											fileUrl: uploadStore.fileUrl
										
										}">

			</FileUploader> -->

			<div class="pond-wrapper">

				<file-pond :instantUpload="false"
									 ref="pond"
									 :allowReplace="true"
									 :allow-multiple="false"
									 :server="server"
									 :allowPaste="true"
									 labelIdle='Drop Files Here<br /> or <span class="browse">Browse your Computer</span>'
									 @init="handleFilePondInit"
									 @initfile="handleLoaded"
									 key="addfile" />

			</div>


		</div>

	</div>

</template>

<script setup lang="ts">
import { useFileUploader, useStore } from '@/stores/stores';
import { storeToRefs } from 'pinia';
import { ref } from 'vue';

import vueFilePond from 'vue-filepond'

// Import plugins
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type'
import FilePondPluginImagePreview from 'filepond-plugin-image-preview'

// Import styles
import 'filepond/dist/filepond.min.css'
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css'
import type { FilePondBaseProps, FilePondFile, FilePondOptions } from 'filepond';

import { serverApi } from '@/composables/frappe'


const app = useStore()
const { activeProject } = storeToRefs(app)
const uploadStore = useFileUploader()
const title = ref('')
const pond = ref()


function closeUploadingFile() {
	// uploadStore.active = false
	title.value = ''
	uploadStore.$reset()
	pond.value.removeFiles()
	app.activeProject.activeButtons = true
}
const FilePond = vueFilePond(FilePondPluginFileValidateType, FilePondPluginImagePreview)

const server = {
	process: (fieldName: any, file: File, metadata: any, load: Function, error: any, progress: any, abort: any, transfer: any, options: any) => {
		// fieldName is the name of the input field
		// file is the actual file object to send



		const formData = new FormData();

		formData.append('file', file, file.name);
		formData.append('folder', 'Home/CustomerUploads/' + app.customerAccount?.name);
		formData.append('is_private', '0')
		formData.append('file_name', file.name);

		const request = new XMLHttpRequest();
		request.open('POST', serverApi.baseURL + '/method/upload_file')
		request.withCredentials = true
		request.upload.onprogress = (e) => {
			progress(e.lengthComputable, e.loaded, e.total)
		};

		request.onload = function () {
			if (request.status >= 200 && request.status < 300) {
				const fileObject = JSON.parse(request.responseText).message
				// the load method accepts either a string (id) or an object

				uploadStore.fileUrl = fileObject.file_url
				app.createProjectStepFile({
					project: app.activeProject.doc.name,
					stepName: app.activeProject.activeStep.name,
					title: uploadStore.fileTitle,
					fileUrl: uploadStore.fileUrl
				}).then(() => {
					pond.value.removeFiles()

					uploadStore.$reset()

				})
				// serverApi.frappeRest('put', 'User', app.userDoc.name, {}, [], { user_image: fileObject.file_url }).then((res) => {
				//    app.userDoc = res
				//  })
				console.info(JSON.parse(request.responseText).message)
				load(JSON.parse(request.responseText).message);
			} else {
				// Can call the error method if something is wrong, should exit after
				error('oh no');
			}
			console.info('onload')
		};


		request.send(formData)


		// Should expose an abort method so the request can be cancelled
		return {
			abort: () => {
				// This function is entered if the user has tapped the cancel button
				request.abort();

				// Let FilePond know the request has been cancelled
				abort();
			},
		};
	},
}

function handleFilePondInit(e: any) {
	uploadStore.pond = pond.value
	console.log('FilePond has initialized', uploadStore.pond);

	// example of instance method call on pond reference

}
function handleLoaded(file: FilePondFile) {
	console.info('Loaded', file)

	uploadStore.setFileDetails(file)
	uploadStore.ready = true

}
</script>

<style lang="scss" scoped>
.overlay-bg {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: transparent;
	z-index: 100;
}

.btn-square.disabled {
	background-color: var(--bs-secondary);
}

.main-element {
	z-index: 101;
	top: 45%;
	left: 5%;
	border-radius: var(--bs-border-radius);
}

.form-floating>.form-control:focus~label,
.form-floating>.form-control:not(:placeholder-shown)~label,
.form-floating>.form-control-plaintext~label,
.form-floating>.form-select~label {
	opacity: 1;
	transform: scale(0.85) translateY(-0.5rem) translateX(0.15rem);
}

.form-floating>label {
	font-weight: 700;
	font-size: 0.85rem;
	color: #26274F80;
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	padding: 0.75rem 0.75rem;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
	pointer-events: none;
	border: 1px solid transparent;
	transform-origin: 0 0;
	transition: opacity 0.1s ease-in-out, transform 0.1s ease-in-out;
}

.form-floating>.form-control,
.form-floating>.form-control-plaintext,
.form-floating>.form-select {
	height: 49px;
	line-height: 1.25;
}

.form-control {
	background-color: white;
	border-radius: 6px;
	border: 1px solid #D4D3D8;
}

.form-control:focus {
	border-color: #D4D3D8;
	box-shadow: none;
	background-color: white;

}
</style>
<style>
.filepond--root {
	margin: unset;
}

/* use a hand cursor intead of arrow for the action buttons */
.filepond--file-action-button {
	cursor: pointer;
}

/* the text color of the drop label*/
.filepond--drop-label {
	color: var(--bs-text-color);
}

/* underline color for "Browse" button */
.filepond--label-action {
	text-decoration-color: #aaa;
}

/* the background color of the filepond drop area */
.filepond--panel-root {
	background-color: #eee;
}

/* the border radius of the drop area */
.filepond--panel-root {
	border-radius: var(--bs-border-radius);
}

/* the border radius of the file item */
.filepond--item-panel {
	border-radius: 0.5em;
}

/* the background color of the file and file panel (used when dropping an image) */
.filepond--item-panel {
	background-color: #555;
}

/* the background color of the drop circle */
.filepond--drip-blob {
	background-color: #999;
}

/* the background color of the black action buttons */
.filepond--file-action-button {
	background-color: rgba(0, 0, 0, 0.5);
}

/* the icon color of the black action buttons */
.filepond--file-action-button {
	color: white;
}

/* the color of the focus ring */
.filepond--file-action-button:hover,
.filepond--file-action-button:focus {
	box-shadow: 0 0 0 0.125em rgba(255, 255, 255, 0.9);
}

.filepond--action-process-item {
	display: none;
}

/* the text color of the file status and info labels */
.filepond--file {
	color: white;
}

/* error state color */
[data-filepond-item-state*='error'] .filepond--item-panel,
[data-filepond-item-state*='invalid'] .filepond--item-panel {
	background-color: red;
}

[data-filepond-item-state='processing-complete'] .filepond--item-panel {
	background-color: green;
}

/* bordered drop area */
.filepond--panel-root {
	/*background-color: transparent;*/
	/*border: 2px solid #2c3340;*/
}

.browse {
	cursor: pointer;
	color: var(--bs-primary);
}

.browse:hover {
	color: var(--bs-primary-hover)
}
</style>