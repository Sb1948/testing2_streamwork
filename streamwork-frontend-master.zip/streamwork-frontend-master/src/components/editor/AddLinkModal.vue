<template>
	<div class="overlay-bg"
			 @click.self="cancelLink()">


		<div class="main-element elv-6 bg-white px-3 py-2 position-absolute">

			<div class="row justify-content-between mb-2">
				<div class="col-auto">
					<div class="fw-bold d-flex flex-shrink">
						Add Link

					</div>

				</div>
				<div role="button"
						 class="col-auto align-items-start"
						 @click="cancelLink()">
					<svg width="12"
							 height="12"
							 viewBox="0 0 12 12"
							 fill="none"
							 xmlns="http://www.w3.org/2000/svg">
						<g clip-path="url(#clip0_119_3402)">
							<path d="M0.586047 0.000288963C0.470144 0.000267029 0.356837 0.0346203 0.26046 0.0990019C0.164083 0.163384 0.0889654 0.254904 0.0446082 0.361983C0.000250996 0.469063 -0.0113527 0.586892 0.0112649 0.700567C0.0338824 0.814242 0.0897052 0.918656 0.171672 1.0006L10.9998 11.8287C11.1097 11.9386 11.2588 12.0004 11.4142 12.0004C11.5696 12.0004 11.7186 11.9386 11.8285 11.8287C11.9384 11.7188 12.0002 11.5698 12.0002 11.4144C12.0002 11.2589 11.9384 11.1099 11.8285 11L1.00042 0.171852C0.946056 0.117373 0.881462 0.074172 0.810351 0.0447302C0.739239 0.0152884 0.663012 0.000185013 0.586047 0.000288963Z"
										fill="#26274F" />
							<path d="M11.4141 0.000288963C11.3372 0.000185013 11.2609 0.0152884 11.1898 0.0447302C11.1187 0.074172 11.0541 0.117373 10.9998 0.171852L0.17164 11C0.0617407 11.1099 0 11.2589 0 11.4144C0 11.5698 0.0617407 11.7188 0.17164 11.8287C0.281539 11.9386 0.430594 12.0004 0.586015 12.0004C0.741436 12.0004 0.890491 11.9386 1.00039 11.8287L11.8285 1.0006C11.9105 0.918656 11.9663 0.814242 11.9889 0.700567C12.0115 0.586892 11.9999 0.469063 11.9556 0.361983C11.9112 0.254904 11.8361 0.163384 11.7397 0.0990019C11.6433 0.0346203 11.53 0.000267029 11.4141 0.000288963Z"
										fill="#26274F" />
						</g>
						<defs>
							<clipPath id="clip0_119_3402">
								<rect width="12"
											height="12"
											fill="white"
											transform="matrix(1 0 0 -1 0 12)" />
							</clipPath>
						</defs>
					</svg>


				</div>

			</div>

			<div class="d-flex flex-column flex-grow-1 mx-2">
				<InputField @updateInput="(inputValue)=>{activeProject.newLink.title=inputValue.value}"
										text="Title"></InputField>
				<InputField @updateInput="(inputValue)=>{activeProject.newLink.url=inputValue.value}"
										text="URL"></InputField>


			</div>



			<div class="d-flex align-items-center  justify-content-end">
				<div class="d-flex flex-column">

					<div class="btn-square btn-square-success"
							 @click="addLink()">
						<font-awesome-icon icon="fa-solid fa-check"></font-awesome-icon>

					</div>


				</div>

			</div>




		</div>

	</div>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
import type { ProjectLink } from '@/types/docTypes';
import { storeToRefs } from 'pinia';
import InputField from './InputField.vue';

const app = useStore()
const { activeProject } = storeToRefs(app)


function addLink() {
	// app.activeProject.isDirty = true
	app.activeProject.newLink.isNew = false
	app.activeProject.showNewLink = false
	app.activeProject.stepLinks[app.activeProject.activeStep.name].push(app.activeProject.newLink)
	app.activeProject.doc.links.push(app.activeProject.newLink)
	app.updateProject(false)
	app.activeProject.activeButtons = true
}


function cancelLink() {
	app.activeProject.newLink = {} as ProjectLink
	app.activeProject.showNewLink = false
	app.activeProject.activeButtons = true

}
</script>

<style lang="scss" scoped>
.overlay-bg {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: transparent;
	z-index: 100;
}

.main-element {
	z-index: 101;
	top: 45%;
	left: 5%;
	border-radius: var(--bs-border-radius);
}
</style>