<template>
    <Modal id="new-project" title="New Project">



        <template v-slot:main>


            <div class="row text-center">
                <div class="col">
                    <div :class="{ active: app.newProject.step == 1 }" class="step">
                        <button type="button" class="btn btn-sm rounded-pill"
                            :class="{ 'btn-warning': app.newProject.step == 1, 'btn-secondary': app.newProject.step < 1, 'btn-primary': app.newProject.step > 1, }"
                            @mousedown="setStep(1)">
                            <font-awesome-icon icon="fa-solid fa-hand-pointer"></font-awesome-icon>
                        </button>
                        <div
                            :class="{ 'text-primary': app.newProject.step > 1, 'fw-bold': app.newProject.step > 1 }">
                            Select Project

                        </div>

                    </div>

                </div>
                <div class="col">
                    <div :class="{ active: app.newProject.step == 2 }" class="step">
                        <button type="button"
                            :class="{ 'btn-warning': app.newProject.step == 2, 'btn-secondary': app.newProject.step < 2, 'btn-primary': app.newProject.step > 2, }"
                            class="btn btn-sm rounded-pill" :disabled="app.newProject.step < 2" @mousedown="setStep(2)">
                            <font-awesome-icon icon="fa-solid fa-palette"></font-awesome-icon>
                        </button>
                        <div>Choose Template

                        </div>

                    </div>

                </div>
                <div class="col">
                    <div :class="{ active: app.newProject.step == 3 }" class="step">
                        <button type="button" class="btn btn-sm btn-primary rounded-pill"
                            :class="{ 'btn-warning': app.newProject.step == 3, 'btn-secondary': app.newProject.step < 3, 'btn-primary': app.newProject.step > 3, }"
                            :disabled="app.newProject.step < 3" @mousedown="setStep(3)">
                            <font-awesome-icon icon="fa-solid fa-plane-departure"></font-awesome-icon>
                        </button>
                        <div>Get to Work

                        </div>

                    </div>

                </div>

            </div>

            <div class="progress mb-5" style="height: 5px;">
                <div class="progress-bar" role="progressbar" :style="'width:' + app.newProject.progress + '%'">


                </div>

            </div>
            <Transition name="slide-fade" mode="out-in">

                <div v-if="app.newProject.step == 1" class="category-wrapper mx-auto">


                    <div class="row row-cols-lg-3 row-cols-xl-4 justify-content-center">
                        <div v-for="(category) in app.categories" class="col mb-4 sw-width" :key="category.name">
                            <div class="card category-card border-secondary" :id="category.name"
                                @mousedown="chooseCategory(category)">
                                <div class="container h-100">

                                    <div class="row h-100 align-items-center">
                                        <div class="col">
                                            <h4 class="text-center text-primary ">{{ category.category_name }}</h4>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>
                <div v-else-if="app.newProject.step == 2" class="row">


                    <div v-for="template in app.newProject.category.templates" class="col-3" :key="template.name">
                        <div class="img-thumbnail template-wrapper" @mousedown="chooseTemplate(template)">
                            <div class="template"
                                :style="'background-image: url(\'' + fileUrl + template.preview_image + '\')'">

                            </div>

                        </div>



                    </div>

                </div>
                <div v-else-if="app.newProject.step == 3" class="row justify-content-around">
                    <div class="col-lg-4 col-md-5 col-sm-10 order-2 order-md-2 order-sm-2">
                        <div class="card border-secondary">


                            <div class="row align-items-center">

                                <div class="col p-3 text-center">
                                    <h5>Category:</h5>
                                    <h3 class="text-center text-primary ">
                                        <span class="badge bg-primary">{{ app.newProject.category.category_name}}</span>
                                    </h3>

                                </div>


                            </div>

                            <div class="row">
                                <div class="col p-4 text-center">
                                    <h5>Template Style:</h5>
                                    <div class="img-thumbnail template-wrapper">
                                        <div class="template"
                                            :style="'background-image: url(\'' + fileUrl  + app.newProject.template.preview_image + '\')'">

                                        </div>

                                    </div>

                                </div>

                            </div>


                        </div>



                    </div>
                    <div class="col-md-5 col-sm-10 order-1 order-sm-1 order-md-2">

                        <div class="card project-name-card mb-4">
                            <div class="card-header bg-dark">
                                <div class="card-title text-white">
                                    <h5 class="text-center mb-0 fw-bold">Project Name</h5>

                                </div>

                            </div>

                            <div class="card-body">
                                <div class="container-fluid my-3 px-4 text-center">
                                    <h6 class="fw-bold text-secondary mb-4">Now just name your project and get to work!
                                    </h6>

                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control form-control-lg px-4" id="project-name"
                                            placeholder="Project Name" v-model="app.newProject.projectName"
                                            required>
                                        <label for="project-name">Project Name</label>

                                    </div>


                                </div>


                                <div class="row justify-content-end mt-4">
                                    <div class="col-auto">

                                        <button @mousedown="createProject()"
                                            class="btn btn-primary btn-lg align fw-bold">Let's Go!
                                            <font-awesome-icon icon="fa-solid fa-angle-right" size="lg">
                                            </font-awesome-icon>
                                        </button>

                                    </div>

                                </div>

                            </div>


                        </div>

                    </div>




                </div>
            </Transition>
        </template>
        <template v-slot:footer>
            <div class="row">
                <div class="col-auto">
                    <button v-if="app.newProject.step > 1" @mousedown="stepBack()"
                        class="btn btn-sm btn-primary">Back</button>

                </div>

            </div>

        </template>

    </Modal>
</template>

<script setup lang="ts">
import { serverApi } from "@/composables/frappe";
import type { StreamWorkCategory, StreamWorkTemplate } from "@/types/docTypes";
import type { Category } from "@/types/localTypes";
import { watch } from "vue"
import { useRouter } from "vue-router"
import { useStore, useModal } from "../stores/stores"
import Modal from './Modal.vue'

const fileUrl = import.meta.env.VITE_STATIC_HOST_URL
const router = useRouter()
const app = useStore()
const modal = useModal()

function closeWizard() {

    modal.close()
    app.newProject.step = 1
}
function setStep(step:number) {
    app.newProject.step = step
    if (step == 1) {
        app.newProject.progress = 18
    } else {
        app.newProject.progress = (step - 1) * 50 - 18
    }

}

async function createProject() {

    app.isProjectCreating = true
    serverApi.createProject(app.newProject.projectName, app.customerAccount?.name, app.newProject.template.name).then((response) => {
        if (response.message.status == 'success') {
            modal.close()
             router.push('/edit/' + response.message.project)
        }
       
    })

    
}

function stepBack() {
    app.newProject.step--;
    app.newProject.progress -= 50 - 18
}

function chooseCategory(category:StreamWorkCategory) {
    app.newProject.category = category
    app.newProject.step += 1
    app.newProject.progress = 50
    console.info(app.newProject)

}

function chooseTemplate(template: StreamWorkTemplate) {
    app.newProject.template = template
    app.newProject.step += 1
    app.newProject.progress = 85
    console.info(app.newProject)

}

watch(modal, () => {
    if (!modal.modalShown) {
        app.newProject.step = 1
    }
})

</script>

<style lang="scss" scoped>
.category-wrapper {
    max-width: 1000px;

}

.category-card {
    height: 200px;
    width: 200px;
}

.category-card:hover {
    border: var(--bs-border-width) var(--bs-border-style) var(--bs-secondary);
    cursor: pointer;

}

.step {
    color: var(--bs-secondary)
}

.step.active {
    font-weight: 700 !important;

}

.template {
    height: 440px;
    background-size: cover;
    background-repeat: no-repeat;

}

.template-wrapper {
    transition: all 0.1s ease-in-out;
}

.template-wrapper:hover {
    cursor: pointer;
    transform: scale(1.01);

}

.img-thumbnail:hover {
    box-shadow: 0.1rem 0.2rem 0.3rem rgb(0 0 0 / 8%);
    transition: all 0.1s ease-in-out;
}

@media only screen and (min-width: 992px) {
    .project-name-card {
        position: absolute;
        top: 30%;
    }

}
</style>