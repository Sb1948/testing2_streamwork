<template>
    <div class="d-flex justify-content-center align-items-center h-100">
        <div class="spinner-grow text-primary" role="status">
            <span class="visually-hidden">Loading...</span>

        </div>
        <slot></slot>

    </div>
</template>
