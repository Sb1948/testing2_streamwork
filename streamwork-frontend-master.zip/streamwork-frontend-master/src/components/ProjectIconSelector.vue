<template>
    <div class="card border">
        <div class="card-body">
            <div class="row">
                <div class="col-auto icon-box" v-for="icon in app.activeProject.icons" :key="icon.name" @mousedown="app.swapIcon(icon,isCover,isFooter)">
                    <div class="icon-wrapper img-thumbnail" :style="'background-image:url(\'' + app.staticHostUrl + icon.icon + '\')'" />

                </div>

            </div>

        </div>

    </div>

</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
const app = useStore()
const props = defineProps(['isCover', 'isFooter'])
</script>
<style lang="scss" scoped>
.card {
    position: absolute;
    // width: 90%;
    left: 5%;
    z-index: 1000;
}
.icon-wrapper {
  width: 100px;
  max-height: 100px;
  background-repeat: no-repeat;
  background-size: contain;
  background-position: 50%;
  transition: all 0.2s ease;
}
.icon-wrapper.img-thumbnail{
  height:160px;
}
.icon-box {
    transition: all 0.2s ease;
}

.icon-box:hover {
    transform: scale(1.5);
    cursor: pointer;
}
</style>