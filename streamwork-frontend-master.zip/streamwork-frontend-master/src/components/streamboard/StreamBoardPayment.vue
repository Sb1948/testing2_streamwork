<template>


	<div class="row justify-content-center text-center">
		<div class="col-auto">

			<div class="badge rounded-pill elv-1"
					 :style="theme.payment">
				<div class="mb-2">Payment

				</div>
				<div class="payment-amount"
						 v-if="app.activeProject.doc.steps[stepIndex].percent == 1 && app.activeProject.doc.steps[stepIndex].percent_amount != 0">
					{{ app.activeProject.doc.steps[stepIndex].percent_amount }}%

				</div>
				<div class="payment-amount"
						 v-if="app.activeProject.doc.steps[stepIndex].percent == 0 && app.activeProject.doc.steps[stepIndex].payment_amount != 0">
					<span class="small me-1">{{ app.getCurrency(app.activeProject.doc.steps[stepIndex].currency) }}</span>
					<span class="small">{{ formatNumber(app.activeProject.doc.steps[stepIndex].payment_amount) }}</span>

				</div>

			</div>
			<div>


			</div>

		</div>


	</div>


</template>

<script setup lang="ts">
import { formatNumber } from '@/composables/utils';
import { useStore } from '@/stores/stores';
import { useTheme } from '@/stores/theme';
import { reactive, ref } from 'vue';

const theme = useTheme()
const props = defineProps(['stepIndex'])
const app = useStore()
const activeStep = ref(app.activeProject.doc.steps[props.stepIndex])

</script>

<style scoped>
.payment-amount {
	font-weight: 400;
}
</style>