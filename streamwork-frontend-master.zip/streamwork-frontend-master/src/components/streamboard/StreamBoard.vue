<template>
	<div class="container-fluid"
			 :class="{ mobile: app.isMobile }"
			 :style="{ backgroundColor: theme.colorPalette.background, fontFamily: theme.activeFont }">
		<div class="row justify-content-center pt-2"
				 id="project-header">
			<div class="col-5">
				<div class="row">


					<div class="col">
						<h1 class="p-2"
								:style="(theme.mainTitle as any)">
							{{ app.activeProject.doc.title }}
						</h1>

					</div>

				</div>
				<div class="row mb-2">

					<div class="col-12">
						<div class="text-break "
								 :style="theme.descriptionText"
								 v-html="app.activeProject.doc?.description_html">

						</div>

					</div>

				</div>
				<div class="row">
					<div class="col-auto">
						<div class="elv-1 border-radius p-2"
								 :style="theme.contactCard">

							<div class="row">
								<div class="col-auto border-end text-end">
									<div class="row">
										<div class="col">
											<small>Client</small>

										</div>

									</div>
									<div class="row">
										<div class="col ">
											<small>Contact</small>

										</div>

									</div>
									<div class="row">
										<div class="col">
											<small>Email</small>

										</div>

									</div>

								</div>
								<div class="col-auto">
									<div class="row">
										<div class="col">
											<small>{{ app.activeProject.doc.client }}</small>

										</div>


									</div>
									<div class="row">
										<div class="col">
											<small>{{ app.activeProject.doc.contact_person_name }}</small>

										</div>

									</div>
									<div class="row">
										<div class="col">
											<small>{{ app.activeProject.doc.contact_email }}</small>

										</div>


									</div>

								</div>


							</div>




						</div>

					</div>

				</div>

			</div>
			<div class="col-auto position-relative">
				<div class="svg-path">
					<svg width="100"
							 height="100">
						<polygon points="0 100,0 95, 100 0,100 15,12 100"
										 :fill="theme.colorPalette.path" />

					</svg>

				</div>


			</div>
			<div class="col-5 position-relative"
					 style="z-index: 1;">
				<img id="cover-image"
						 class="cover-image"
						 :src="app.staticHostUrl + app.activeProject.doc.cover_image_url" />

			</div>


		</div>

		<div class="row justify-content-center text-center">
			<div class="col-5">

			</div>
			<div class="col-2">
				<div class="step-path mx-auto"
						 style="width:12px;height:30px;"
						 :style="'background-color:' + theme.colorPalette.path">

				</div>

			</div>
			<div class="col-5">

			</div>

		</div>



		<draggable v-model="app.activeProject.doc.steps"
							 animation="150"
							 group="mainGroup"
							 easing="cubic-bezier(1, 0, 0, 1)"
							 sort="true"
							 forceFallback="true"
							 @change="log"
							 ghost-class="ghost"
							 :disabled="app.isViewing || !app.activeProject.enableDrag"
							 @start="dragstart"
							 @end="dragstop">


			<TransitionGroup :name="app.activeProject.enableDrag ? '' : 'list-pop'"
											 @after-leave="enableDrag">
				<div v-for="(step, index) in app.activeProject.doc.steps"
						 :key="step.name"
						 class="step-master position-relative"
						 :class="{ active: step.name == app.activeProject.activeStep.name }">
					<div v-if="step.step_type == 'Standard'"
							 class="row gx-0 justify-content-center step-row-container position-relative"
							 :style="theme.stepRow"
							 :class="{ grab: !app.isViewing, mobile: app.isMobile }"
							 :key="step.name"
							 @click="!app.isViewing ? app.setActiveStep(step) : ''"
							 :id="'step-' + step.name">



						<StreamBoardStep :stepIndex="index.toString()"
														 :step="step">

						</StreamBoardStep>


					</div>
					<div v-else-if="step.step_type == 'Payment'"
							 @click="!app.isViewing ? app.setActiveStep(step) : ''"
							 class="step-row-container"
							 :id="'step-' + step.name">
						<StreamBoardPayment :stepIndex="index.toString()">

						</StreamBoardPayment>

					</div>

					<div class="step-button bg-danger trash"
							 :class="{ static: !dragging }"
							 @click="app.deleteActiveStep(step)">

						<svg width="20"
								 height="21"
								 viewBox="0 0 20 21"
								 fill="none"
								 xmlns="http://www.w3.org/2000/svg">
							<path d="M2.68408 5.33383H4.33153H17.5111"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
							<path d="M6.80272 5.33384V3.68639C6.80272 3.24946 6.97629 2.83042 7.28524 2.52147C7.5942 2.21251 8.01324 2.03894 8.45017 2.03894H11.7451C12.182 2.03894 12.601 2.21251 12.91 2.52147C13.2189 2.83042 13.3925 3.24946 13.3925 3.68639V5.33384M15.8637 5.33384V16.866C15.8637 17.3029 15.6901 17.7219 15.3812 18.0309C15.0722 18.3399 14.6532 18.5134 14.2162 18.5134H5.97899C5.54206 18.5134 5.12303 18.3399 4.81407 18.0309C4.50511 17.7219 4.33154 17.3029 4.33154 16.866V5.33384H15.8637Z"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
						</svg>



					</div>
					<div class="step-button bg-primary"
							 :class="{ static: !dragging }">

						<svg width="21"
								 height="21"
								 viewBox="0 0 21 21"
								 fill="none"
								 xmlns="http://www.w3.org/2000/svg">
							<path d="M4.73387 7.80499L2.2627 10.2762L4.73387 12.7473"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
							<path d="M8.02881 4.51011L10.5 2.03894L12.9712 4.51011"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
							<path d="M12.9712 16.0422L10.5 18.5134L8.02881 16.0422"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
							<path d="M16.2661 7.80499L18.7373 10.2762L16.2661 12.7473"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
							<path d="M2.2627 10.2762H18.7372"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
							<path d="M10.5 2.03894V18.5134"
										stroke="white"
										stroke-width="2"
										stroke-linecap="round"
										stroke-linejoin="round" />
						</svg>


					</div>
					<div class="row justify-content-center bottom">
						<div class="col-2 step-divider">
							<div :style="(theme.path as any)">

							</div>

						</div>

					</div>


				</div>
			</TransitionGroup>

		</draggable>
		<div class="row justify-content-center position-relative">
			<div class="bottom-path"
					 style="z-index: 0;">
				<div class="insert"
						 :style="'background-color:' + theme.colorPalette.path">

				</div>

			</div>
			<div class="col-5 mb-4 position-relative">

				<img id="footer-image"
						 class="footer-image"
						 :src="app.staticHostUrl + app.activeProject.doc.footer_image_url"
						 style="z-index: 100;" />


			</div>

		</div>

	</div>

</template>

<script setup lang="ts">
import { useTheme } from '@/stores/theme';
import { useStore } from '@/stores/stores';
import StreamBoardStep from '@/components/streamboard/StreamBoardStep.vue';
import type { ProjectStep } from '@/types/docTypes';
import { ref } from 'vue';
import StreamBoardPayment from './StreamBoardPayment.vue';
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css'
import CircleButton from '../icons/CircleButton.vue'
const app = useStore()
const theme = useTheme()
const activeEditor = ref('Steps')
const dragging = ref(false)
function enableDrag(el: Element) {

	app.activeProject.enableDrag = true
	app.loadActiveProject(app.activeProject.doc?.name, true)
}
function setGrayStep(step: ProjectStep, event: Event) {

	document.querySelectorAll('.marker-gray').forEach((el) => {
		el.classList.remove('show')
	})
	//console.info(event)
	//console.info(event)
	if (event.type == 'mouseenter') {
		const el = document.querySelector('#markgray-' + step.name)

		//console.info(el)
		if (el) {
			el.classList.add('show')
		}


		//console.info(event.source)
	}


}
async function log() {
	//console.log(event)
	app.sortSteps(true)
	app.validateStepButtons(app.activeProject.activeStep)
	//await app.updateProject(false)

}

function dragstart() {
	// console.info('start')
	dragging.value = true
	document.body.style.cursor = 'grabbing'
}
function dragstop() {
	// console.info('start')
	dragging.value = false
	document.body.style.cursor = 'default';
}
</script>

<style lang="scss" scoped>
.grabbing {
	cursor: grabbing !important;
}

.step-button {
	text-align: center;
	position: absolute !important;
	z-index: 1;
	right: 20px;
	top: -10px;
	border-radius: 50%;
	cursor: grab;
	opacity: 0;
	padding-left: 0.4rem;
	padding-right: 0.4rem;
	line-height: 33px;
	width: 33px;
	height: 33px;
	transition: all 0.2s ease;
}

.step-button.static {
	opacity: 0;
	transition: all 0.2s ease;
}


.step-button.trash {
	right: 70px;
	cursor: pointer;
}

.step-button:hover {
	transform: scale(1.05);
	background-color: lighten(#0fd2af, 10) !important;
}

.step-button.trash:hover {

	background-color: lighten(#D56662, 10) !important;
}

.step-divider {
	height: 50px;
	position: relative;
}

.sortable-ghost {
	opacity: 0;
	border: 5px solid green;
}

// Class name for the drop placeholder
.sortable-chosen {}


.cover-image {
	max-height: 600px;
	z-index: 1000;
	// position: absolute;
	bottom: 0;
}

.footer-image {
	width: 100%;
	height: auto;
	max-height: 500px;
}

.bottom-path {
	position: absolute;
	width: 24px;
	height: 50%;
	padding: 0 6px;

}

.bottom-path .insert {
	width: 12px;
	height: 100%;
}

.marker-gray,
.marker {
	transition: all 0.1s ease;
}

.step-row-container {
	border: 2px solid transparent;
	transition: all 0.2s ease-out;

}


.step-master.active {
	.step-row-container {
		box-sizing: border-box;
		border: 2px dashed #63CFB1 !important;

	}
}

.step-master:hover {
	.step-button.static {
		opacity: 1;
	}

	.step-row-container {
		box-sizing: border-box;
		border: 2px dashed var(--bs-gray-400);

	}
}

// Class name for the chosen item

.sortable-drag {
	opacity: 1;
	transform: scale(1.1) rotate(-5deg);
	background-color: transparent;
	transition: border 3s ease;
	height: fit-content !important;


	.marker-gray,
	.marker {
		display: none !important;
		transition: all 0.2s ease;
	}

	.step-row-container {
		border: 2px dashed var(--bs-warning) !important;
		box-shadow: 0 0rem 2rem rgb(0 0 0 / 25%) !important;

	}

	.bottom {
		display: none;
	}
}

.ghost {

	//border: 4px solid brown;
	// opacity: 0;
	.step-row-container {
		border: 2px dashed var(--bs-warning) !important;
		box-shadow: 0 1px 1rem rgb(0 0 0 / 25%) !important;

	}

}

// Class name for the dragging item
.marker {
	border-left: 5px solid var(--bs-warning);
	height: 100%;
	width: 5px;
	position: absolute;
	left: -5px;
	top: 0;
	display: none;
	transition: all 0.3s ease;
}

.marker-gray {
	// border-left: 5px solid var(--bs-gray-400);
	height: 100%;
	width: 5px;
	position: absolute;
	left: -5px;
	top: 0;
	display: none;
	transition: all 0.3s ease;
}


// .mobile {
//   max-width: 360px;
//   width: 360px;
//   max-height: 800px;
//   overflow-y: scroll;
//   overflow-x: hidden;
//   transition: all 0.5s ease;
//   --sw-scrollbar-width: 1px;


// }

.svg-path {
	position: absolute;
	bottom: 0;
	left: calc(50% - 6px);
	height: 100px;
	width: 12px;
	z-index: 1;
}

.mobile.step-row-container {

	padding-left: 0 !important;
	padding-right: 0 !important;
	margin: 0;
}

/* webkit scrollbar*/
/* width */
::-webkit-scrollbar {
	width: var(--sw-scrollbar-width)
}

/* Track */
::-webkit-scrollbar-track {
	background: #f1f1f1;
}

/* Handle */
::-webkit-scrollbar-thumb {
	background: var(--bs-primary);
	border-radius: 1rem;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
	background: #555;
}
</style>