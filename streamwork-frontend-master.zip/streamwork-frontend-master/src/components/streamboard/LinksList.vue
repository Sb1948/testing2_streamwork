<template>
	<div class="row">
		<div class="col-auto links-list">
			<TransitionGroup name="list-pop" tag="ul" class="list-group">
				<li v-if="app.activeProject.showNewLink" class="badge rounded-pill mb-1" :style="theme.links"
					:key="app.activeProject.newLink.name">
					<a v-if="app.activeProject.newLink.type == 'File'" :href="app.staticHostUrl + app.activeProject.newLink.file"
						target="_blank">
						<font-awesome-icon icon="fa-solid fa-file">
						</font-awesome-icon>


						{{ app.activeProject.newLink.title || app.activeProject.newLink.file.replace('/files/', '') }}
					</a>
					<a v-else-if="app.activeProject.newLink.type == 'URL'" :href="app.activeProject.newLink.url" target="_blank">

						<font-awesome-icon icon="fa-solid fa-link">
						</font-awesome-icon>

						{{ app.activeProject.newLink.title || app.activeProject.newLink.url }}
					</a>
				</li>
				<li v-for="link in links" class="badge rounded-pill mb-1" :style="theme.links" :key="link.name">
					<a v-if="link.type == 'File'" :href="app.staticHostUrl + link.file" target="_blank">
						<font-awesome-icon icon="fa-solid fa-file">
						</font-awesome-icon>


						{{ link.title || link.file.replace('/files/', '') }}
					</a>
					<a v-else-if="link.type == 'URL'" :href="link.url" target="_blank">

						<font-awesome-icon icon="fa-solid fa-link">
						</font-awesome-icon>

						{{ link.title || link.url }}
					</a>
				</li>
			</TransitionGroup>

		</div>

	</div>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
import { useTheme } from '@/stores/theme';

const theme = useTheme()
const props = defineProps(['links'])
const app = useStore()
</script>

<style scoped>
.theme .links-list a {
	text-decoration: none;
	color: white;
}
</style>