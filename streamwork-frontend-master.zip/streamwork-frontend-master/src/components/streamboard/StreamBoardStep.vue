<template>
	<div v-if="!app.isMobile"
			 class="row theme"
			 :class="{ mobile: app.isMobile }">

		<Transition name="slide-fade"
								mode="out-in">

			<div v-if="app.activeProject.doc.steps[stepIndex].left"
					 :class="mobileCol">
				<div class="col-auto">
					<h3 :style="theme.stepTitle">{{ app.activeProject.doc.steps[stepIndex].title }}</h3>

				</div>
				<div class="col">

				</div>

				<div class="row">
					<div class="col-12">
						<span :style="theme.descriptionText">
							{{ app.activeProject.doc.steps[stepIndex].description }}
						</span>


					</div>


				</div>
				<div v-if="app.activeProject.doc.steps[stepIndex].duration && !app.activeProject.doc.steps[stepIndex].show_date"
						 class="row">
					<div class="col">

						<Clock class="clock"></Clock>{{ app.activeProject.doc.steps[stepIndex].duration }}
						{{ app.activeProject.doc.steps[stepIndex].duration_type }}

					</div>

				</div>
				<div v-if="app.activeProject.doc.steps[stepIndex].show_date && app.activeProject.doc.steps[stepIndex].start_date"
						 class="row">
					<div class="col">

						<Clock class="clock"></Clock>{{ app.activeProject.doc.steps[stepIndex].start_date }}

					</div>

				</div>

				<LinksList :links="app.activeProject.stepLinks[app.activeProject.doc.steps[stepIndex].name]">
				</LinksList>




			</div>
			<div v-else
					 :class="mobileCol">
				<div class="step-img"
						 v-if="app.activeProject.doc.steps[stepIndex].icon_url"
						 :style="'background-image:url(\'' + fileHost + app.activeProject.doc.steps[stepIndex].icon_url + '\');'">

				</div>


			</div>
		</Transition>
		<div class="col-2 step-number-col">
			<div class="step-path"
					 :style="theme.path">

			</div>

			<div class="row">

				<div class="col position-relative">
					<div class="horizontal-bar"
							 :class="{ 'left': app.activeProject.doc.steps[stepIndex].left }"
							 :style="theme.horizontalLine">

					</div>
					<div class="badge step-number elv-1"
							 :style="theme.stepNumber">

						{{ app.activeProject.doc.steps[stepIndex].step_number }}

					</div>

				</div>



			</div>



		</div>
		<Transition name="slide-fade"
								mode="out-in">
			<div v-if="app.activeProject.doc.steps[stepIndex].left"
					 :class="mobileCol">
				<div class="step-img"
						 v-if="app.activeProject.doc.steps[stepIndex].icon_url"
						 :style="'background-image:url(\'' + fileHost + app.activeProject.doc.steps[stepIndex].icon_url + '\');'">

				</div>


			</div>
			<div v-else
					 :class="mobileCol">
				<div class="row">
					<div class="col-auto">
						<h3 :style="theme.stepTitle">{{ app.activeProject.doc.steps[stepIndex].title }}</h3>

					</div>
					<div class="col">

					</div>


				</div>
				<div class="row">
					<div class="col-12">
						<span :style="theme.descriptionText">
							{{ app.activeProject.doc.steps[stepIndex].description }}
						</span>


					</div>


				</div>
				<div v-if="app.activeProject.doc.steps[stepIndex].duration && !app.activeProject.doc.steps[stepIndex].show_date"
						 class="row">
					<div class="col">

						<Clock class="clock"></Clock>{{ app.activeProject.doc.steps[stepIndex].duration }}
						{{ app.activeProject.doc.steps[stepIndex].duration_type }}

					</div>

				</div>
				<div v-if="app.activeProject.doc.steps[stepIndex].show_date && app.activeProject.doc.steps[stepIndex].start_date"
						 class="row">
					<div class="col">

						<Clock class="clock"></Clock>{{ app.activeProject.doc.steps[stepIndex].start_date }}

					</div>

				</div>

				<LinksList :links="app.activeProject.stepLinks[app.activeProject.doc.steps[stepIndex].name]">
				</LinksList>



			</div>
		</Transition>

	</div>
	<div v-else
			 class="row mobile justify-content-center">
		<div class="col-auto">
			<div class="row justify-content-center">
				<div class="col-12">
					<div class="step-img-mobile mx-auto"
							 v-if="app.activeProject.doc.steps[stepIndex].icon_url"
							 :style="'background-image:url(\'' + fileHost + app.activeProject.doc.steps[stepIndex].icon_url + '\');'">

					</div>


				</div>

			</div>
			<div class="row">
				<div class="col-12">

					<h3 :style="theme.stepTitle">{{ app.activeProject.doc.steps[stepIndex].title }}</h3>

				</div>

			</div>

			<div class="row">
				<div class="col-12">
					<span :style="theme.descriptionText">
						{{ app.activeProject.doc.steps[stepIndex].description }}
					</span>


				</div>

			</div>

		</div>

	</div>
</template>

<script setup lang="ts">
import { useStore } from '@/stores/stores';
import { useTheme } from '@/stores/theme';
import { onMounted, ref } from 'vue';
import LinksList from './LinksList.vue';
import Clock from '@/svg/Clock.svg?component';
import { computed } from '@vue/reactivity';
const app = useStore()
const theme = useTheme()
const fileHost = app.staticHostUrl
const props = defineProps(['stepIndex'])
const step = ref()
const mobileCol = computed(() => {
	return app.isMobile ? 'col-12' : 'col-5'
})

</script>

<style lang="scss" scoped>
.step-number {
	border-radius: 50% !important;
	--step-number-size: 50px;
	width: var(--step-number-size);
	height: var(--step-number-size);
	position: absolute;
	left: calc(50% - var(--step-number-size)/2);
	padding: 0;
	font-size: 1.6rem;
	line-height: var(--step-number-size);
}



.horizontal-bar {
	height: var(--step-path-width);
	position: absolute;
	right: unset;
	left: 50%;
	top: calc(var(--step-number-size) / 2 - 10px);
	width: 50%;
	border-radius: 5px;
}

.horizontal-bar.left {
	left: unset;
	right: 50%;


}

.theme {
	--theme-primary-color: var(--bs-primary);
	--theme-text-color: #292140;
	--theme-dark-color: #414a8d;
	--step-path-width: calc(20px * 0.8);
	--bs-info: #5b7889;
	--bs-info-rgb: 82, 175, 231;
	--step-number-size: 50px;
	--step-path-width: calc(20px * 0.8);
}

.img-fluid {
	position: absolute;
	max-width: 200px;
}





.theme #project-header {
	padding: 20px 45px;
}

.theme .dark {
	background-color: #414a8d;
}

.theme-bg-dark {
	background-color: var(--theme-dark-color);
}

.clock {
	transform: scale(0.5);
}

.step-img {
	width: 100%;
	height: 100%;
	min-height: 150px;
	max-height: 180px;
	position: relative;
	top: calc(50% - 80px);
	background-repeat: no-repeat;
	background-position: center;
	background-size: contain;
	transform: scale(1.5);
}

.mobile {
	width: 100%;

	.step-path {
		display: none;
	}

	.horizontal-bar {
		display: none;
	}

	.step-img-mobile {
		width: 100%;
		height: 200px;
		max-height: 180px;
		background-repeat: no-repeat;
		background-position: center;
		background-size: contain;

	}
}
</style>