<template>
    <div class="form-floating mb-3 has-validation">
        <input :class="{ loading: inputState.loading }" :type="type" class="form-control form-control-lg px-4" :id="info"
            :placeholder="info" v-model="inputState[info.replace('-', '_')]" required :disabled="inputState.loading">
        <label class="login-label" :for="info">{{ label }}</label>
        <div class="invalid-feedback">
            {{validationError}}

        </div>

    </div>
</template>

<script setup lang="ts">

import { useLoginForm } from '@/stores/stores';

const inputState = useLoginForm()

const props = defineProps(['type', 'value', 'info','validationError'])
const label = props.info.replace('-', ' ')
</script>

<style>
.login-label {

    text-transform: capitalize;

}

.loading {
    color: var(--bs-gray-50);
}
</style>