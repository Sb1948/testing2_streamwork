<template>
    <div class="modal-overlay" @mousedown.self="modal.close()">

        <div class="modal-dialog modal-sw modal-xl modal-fullscreen-lg-down">
            <div class="modal-content">
                <div class="modal-header bg-dark text-center text-white">
                    <div class="container-fluid">

                        <div class="row justify-content-between">
                            <div class="col-1">

                            </div>
                            <div class="col-auto">
                                <h5 class="modal-title  fw-bold" id="staticBackdropLabel">{{ title }}</h5>

                            </div>
                            <div class="col-1">

                                <div class="pointer close-btn" aria-label="Close" @mousedown="modal.close()">
                                    <font-awesome-icon icon="fa-solid fa-circle-xmark" size="2x"></font-awesome-icon>

                                </div>


                            </div>

                        </div>

                    </div>

                </div>


                <div class="modal-body bg-light">
                    <div class="container-fluid">
                        <slot name="main"></slot>

                    </div>


                </div>
                <div class="modal-footer">
                    <slot name="footer"></slot>

                </div>

            </div>

        </div>



    </div>
</template>

<script setup lang="ts">
import { defineProps } from "vue"
import { useModal } from '../stores/stores'
const props = defineProps(['id', 'title'])
const modal = useModal()
</script>

<style lang="scss" scoped>
.modal-sw {

    --bs-modal-zindex: 1055;
    --bs-modal-width: 500px;
    --bs-modal-padding: 1rem;
    --bs-modal-margin: 0.5rem;
    --bs-modal-color: ;
    --bs-modal-bg: #fff;
    --bs-modal-border-color: var(--bs-border-color-translucent);
    --bs-modal-border-width: 1px;
    --bs-modal-border-radius: 0.5rem;
    --bs-modal-box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    --bs-modal-inner-border-radius: calc(0.5rem - 1px);
    --bs-modal-header-padding-x: 1rem;
    --bs-modal-header-padding-y: 1rem;
    --bs-modal-header-padding: 1rem 1rem;
    --bs-modal-header-border-color: var(--bs-border-color);
    --bs-modal-header-border-width: 1px;
    --bs-modal-title-line-height: 1.5;
    --bs-modal-footer-gap: 0.5rem;
    --bs-modal-footer-bg: ;
    --bs-modal-footer-border-color: var(--bs-border-color);
    --bs-modal-footer-border-width: 1px;
}

.modal-overlay {
    background-color: #00000058;
    position: fixed;
    width: 100vw;
    height: 100vh;
    top: 0;
    left: 0;
}

.modal-dialog {
    pointer-events: visible;
}

.modal-body {
    min-height: 80vh;
    max-height: 80vh;
}

.modal-footer {
    justify-content: unset;
    min-height: 64px;
}

.close-btn:hover {
    transform: scale(1.1);

}

.close-btn {
    transition: all 0.1s ease-in-out;
    cursor: pointer;
}

@media (min-width: 992px) {

    .modal-lg,
    .modal-xl {
        --bs-modal-width: 90%;
    }

}
</style>