<template>
    <div>
<Icon>
    
</Icon>
    </div>
</template>

<script setup lang="ts">
import Icon from "./icons/Icon.vue";

</script>

<style scoped>

</style>