export type TagId = 'ccn' | 'cvv' | 'exp'

export type CardType = 'AMEX' | 'VISA' | 'MASTERCARD' | 'DISCOVER' | 'DINERS' | 'JCB'

export type ErrorCode = '10' | '22013' | '14040' | '14041' | '14042' | '400' | '403' | '404' | '500'

export type ErrorDescription = 'invalidCcNumber' | 'invalidExpDate' | 'invalidCvv'
export type CardData = {

}
export type CreditCardInfo = {
  billingContactInfo: {
    firstName?: string,
    lastName?: string,
  },
  processingInfo?: {
    avsResponseCodeAddress: string,
    cvvResponseCode: string,
    avsResponseCodeName: string,
    avsResponseCodeZip: string
  },
  creditCard: {
    expirationYear: string,
    cardLastFourDigits: string,
    cardSubType: string,
    cardType: 'AMEX' | 'VISA' | 'MASTERCARD' | 'DISCOVER' | 'DINERS' | 'JCB' |'',
    expirationMonth: string
  },
  dateCreated: string,
  timeCreated: string
}

export type VaultedShopper = {
  paymentSources?: {
    creditCardInfo?:CreditCardInfo[]
  }
}