import type { FilePondFile } from "filepond"
import type { VaultedShopper } from "./bluesnap"
import type {
  StreamWorkProject,
  ProjectStep,
  StreamWorkTemplate,
  StreamWorkTemplateStep,
  StreamWorkCategory,
  User,
  CustomerAccount
} from "./docTypes"


export type NewProjectStep = 1 | 2 | 3

export type Category = {
  id: string,
  name: string,
  icon: string,
  faIcon: string,
  templates: StreamWorkTemplate[]
}


export type FileUploadState = {
  filePondFile?: FilePondFile | {}
}

