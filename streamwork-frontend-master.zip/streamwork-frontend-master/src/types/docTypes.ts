export type Data = string
export type SmallText = string
export type AttachImage = string
export type Language = string
export type RoleProfile = string
export type Text = string
export type LongText = string
export type YYYY = number
export type MM = '01' | '02' | '03' | '04' | '05' | '06' | '07' | '08' | '09' | '10' | '11' | '12'
export type DD = '01' | '02' | '03' | '04' | '05' | '06' | '07' | '08' | '09' | '10' | '11' | '12' | '13' | '14' | '15' | '16' | '17' | '18' | '19' | '20' | '21' | '22' | '23' | '24' | '25' | '26' | '27' | '28' | '29' | '30' | '31'
export type SwDate = string //`${YYYY}-${MM}-${DD}`
export type Check = 1 | 0
export type FormResponse = {
	docinfo: object,
	docs: StreamWorkProject[]
}
export interface BillingAddress extends DocType {
	address_title: string,
	address_line1: string,
	address_line2: string,
	city: string,
	country: string,
	pincode: string,
	company: string,
	phone: string,
	state: string,
	address_type: 'Billing' | 'Shipping',
}
export type DocType = {
	name: string,
	creation: Date,
	modified: Date,
	modified_by: string,
	owner: string,
	doctype: string,
}

export interface TableDoc extends DocType {
	parent: string,
	parenttype: string,
	parentfield: string,
	idx: number,
	"__islocal"?: 1 | 0,
	"__unsaved"?: 1 | 0,
	"__unedited"?: boolean
}

export interface CustomerAccount extends DocType {
	vault_id: string,
	billing_address?: BillingAddress,
	account_type: 'Free Account' | 'Pro Account' | 'Enterprise Account',
}
export interface ProjectLink extends TableDoc {
	step: string,
	type: 'URL' | 'File',
	title: string,
	url: string,
	file: string,
	isNew: boolean
}
export interface User extends DocType {
	enabled: boolean,
	email: Data,
	first_name: Data,
	middle_name: Data,
	last_name: Data,
	full_name: Data,
	username: Data,
	language: Language,
	time_zone: string
	user_image: AttachImage
	role_profile_name: RoleProfile
	roles: Role[]
	birth_date: Date,
	interest: SmallText,
	banner_image: AttachImage,
	phone: Data,
	location: Data,
	bio: SmallText,
	mobile_no: Data
	last_active: Date
	last_login: string,
	last_known_versions: Text
}

export interface ColorPalette extends DocType {
	name: Data
	background: string
	step_background: string
	primary: string
	secondary: string
	text: string
	info: string
	contact: string
	path: string
}

export interface Font extends DocType {
	font_name: string
	google_font_id: string
}
export interface StreamWorkProject extends DocType {
	project_name: Data,
	client: Data,
	contact_person_name: Data,
	contact_email: Data,
	title: Data,
	description: LongText,
	description_html: LongText,
	cover_image_link: string,
	cover_image_url: string,
	footer_image_link: string,
	footer_image_url: string,
	status: 'draft' | 'active'
	project_lock: Data
	customer_account: string
	steps: ProjectStep[],
	links: ProjectLink[],
	color_palette: string,
	template: string
	font: string
	is_template: number
	template_name: string
	category: string
	preview_image: string
}

export interface ProjectStep extends TableDoc {
	/* the things */
	idx: number,
	left: boolean,
	title: Data,
	description: Text,
	icon?: string,
	icon_url: string,
	step_type?: 'Standard' | 'Payment',
	step_number: number,
	isNew: boolean,
	links: ProjectLink[],
	timeline_type: string
	duration: number, // in seconds
	duration_type: 'Days' | 'Weeks' | 'Months'
	show_date: 1 | 0,
	date_type: 'Milestone' | 'Range'
	show_amount: boolean,
	free_form_timeline: string,
	due_date: SwDate,
	start_date: SwDate,
	status: 'Approval Requested' | 'Client Approved' | ''
	approved_by_name: string,
	approved_by_email: string,
	percent_amount: number,
	payment_amount: number,
	percent: 1 | 0,
	currency: string
}

export interface StreamWorkCategory extends DocType {
	category_name: Data
	category_icon: AttachImage
	fontawesome_icon: Data
	template_count: number
	templates: StreamWorkTemplate[]
}

export interface StreamWorkTemplate extends DocType {
	template_name: Data,
	default_palette: ColorPalette['name'],
	cover_image: AttachImage,
	background_image: AttachImage,
	preview_image: AttachImage,
	bottom_image: AttachImage,
	number_image: AttachImage,
	top_background_image: AttachImage,
	category: StreamWorkCategory['category_name'],
	steps: StreamWorkTemplateStep[],

}

export type StreamWorkTemplateStep = {
	name: Data,
	title: Data,
	description: Text
}

export interface TemplateIcon extends DocType {
	icon: string
	template: string
	template_name: string
	file: string
}

export interface Role extends TableDoc {

	role: string
}

export interface FrappeFile extends DocType {
	file_name: string;
	is_private: Check;
	is_home_folder: Check;
	is_attachments_folder: Check;
	file_size: number;
	file_url: string;
	folder: string;
	is_folder: Check;
	content_hash: string;
	uploaded_to_dropbox: Check;
	uploaded_to_google_drive: Check;
}
export interface StreamBoardSettings extends DocType {
	scratch_category: string,
	default_palette: string,
	default_header_image: string,
	default_footer_image: string
}