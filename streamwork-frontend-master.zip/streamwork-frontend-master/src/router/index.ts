import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import StreamBoardView from '@/views/StreamBoardView.vue'
import EditView from '@/views/EditView.vue'
import AccountView from '@/views/AccountView.vue'
import CheckOutView from '@/views/CheckOutView.vue'
import NewProjectView from '@/views/NewProjectView.vue'
import TemplateBrowserView from '@/views/TemplateBrowserView.vue'
const router = createRouter({
	history: createWebHistory(import.meta.env.BASE_URL),
	routes: [
		{
			path: '/',
			name: 'home',
			component: HomeView,
			meta: {
				title: 'Home'
			}
		}, {
			path: '/templates',
			name: 'templates',
			component: TemplateBrowserView,
			meta: {
				title: 'Templates'
			}
		},
		{
			path: '/new-project',
			name: 'new-project',
			component: NewProjectView,
			meta: {
				title: 'New Project'
			}
		},
		{
			path: '/view/:id',
			name: 'View',
			component: StreamBoardView,
			meta: {
				title: 'View'
			}
		}
		,
		{
			path: '/edit/:id',
			name: 'Edit',
			component: EditView,
			meta: {
				title: 'Edit'
			}
		},

		{
			path: '/account',
			name: 'Account',
			component: AccountView,
			meta: {
				title: 'Account'
			}
		},

		{
			path: '/checkout',
			name: 'Checkout',
			component: CheckOutView,
			meta: {
				title: 'CheckOut'
			}
		}
	]
})


/*

Add a navigation guard that sets the page title from the route meta.

*/

const PAGE_TITLE_ROOT = import.meta.env.VITE_APP_TITLE;
router.beforeEach((to) => {
	document.title = PAGE_TITLE_ROOT + " - " + to.meta.title || PAGE_TITLE_ROOT;
});
export default router
